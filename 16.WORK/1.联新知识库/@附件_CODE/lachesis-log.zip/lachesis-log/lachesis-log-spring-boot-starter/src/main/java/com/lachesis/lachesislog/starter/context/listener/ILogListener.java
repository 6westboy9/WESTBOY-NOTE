package com.lachesis.lachesislog.starter.context.listener;


import com.lachesis.lachesislog.transport.LachesisEntryLog;
import com.lachesis.lachesislog.transport.LachesisLogMessage;
import com.lachesis.lachesislog.transport.LachesisLogVector;

public interface ILogListener {
    void finished(LachesisEntryLog entryLog);
}
