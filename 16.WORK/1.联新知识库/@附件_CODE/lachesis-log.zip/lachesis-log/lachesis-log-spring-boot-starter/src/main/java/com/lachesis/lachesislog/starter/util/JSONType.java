package com.lachesis.lachesislog.starter.util;

public enum JSONType {
    JSON_OBJECT,
    JSON_ARRAY
}
