package com.lachesis.lachesislog.starter.context.domain;

import cn.hutool.json.JSONObject;
import com.lachesis.lachesislog.transport.LachesisDataOpExitLogRecord;
import com.lachesis.lachesislog.transport.LachesisDataOpExitLogRecordField;
import com.lachesis.lachesislog.transport.OpType;
import lombok.Data;

import java.util.*;
import java.util.stream.Collectors;

@Data
public class DataOpExitLogRecord {

    private OpType opType;
    private String id;
    private String pValue;
    private Map<String, DataOpExitLogRecordField> fieldMap = new HashMap<>();
    private JSONObject beforeData = new JSONObject();
    private JSONObject afterData = new JSONObject();
    /**
     * 业务端扩展使用
     */
    private JSONObject attachments = new JSONObject();

    public LachesisDataOpExitLogRecord transform() {
        LachesisDataOpExitLogRecord record = new LachesisDataOpExitLogRecord();
        record.setOpType(opType);
        record.setId(id);
        record.setPValue(pValue);
        record.setFields(transformFields());
        record.setAttachments(attachments);
        return record;
    }

    public <T> T getFromBeforeData(String name, Class<T> tClass) {
        return beforeData.get(name, tClass);
    }

    public <T> T getFromAfterData(String name, Class<T> tClass) {
        return afterData.get(name, tClass);
    }

    public DataOpExitLogRecordField getField(String name) {
        return fieldMap.get(name);
    }

    public void addField(String name, DataOpExitLogRecordField field) {
        fieldMap.put(name, field);
    }

    public Collection<DataOpExitLogRecordField> getFields() {
        return fieldMap.values();
    }

    public DataOpExitLogRecordField retainField(String name) {
        DataOpExitLogRecordField field = fieldMap.get(name);
        fieldMap.clear();
        fieldMap.put(name, field);
        return field;
    }

    public Map<String, DataOpExitLogRecordField> retainFields(String... names) {
        Map<String, DataOpExitLogRecordField> map = new HashMap<>();
        for (String name : names) {
            DataOpExitLogRecordField field = fieldMap.get(name);
            map.put(name, field);
        }
        fieldMap.clear();
        fieldMap.putAll(map);
        return map;
    }

    public DataOpExitLogRecordField removeField(String name) {
        return fieldMap.remove(name);
    }

    public Map<String, DataOpExitLogRecordField> removeFields(String... names) {
        Map<String, DataOpExitLogRecordField> map = new HashMap<>();
        for (String name : names) {
            DataOpExitLogRecordField field = fieldMap.remove(name);
            map.put(name, field);
        }
        return map;
    }

    public boolean containsField(String name) {
        return fieldMap.containsKey(name);
    }

    public void attach(String k, Object v) {
        attachments.set(k, v);
    }

    private List<LachesisDataOpExitLogRecordField> transformFields() {
        return fieldMap.values().stream().map(DataOpExitLogRecordField::transform).collect(Collectors.toList());
    }

}
