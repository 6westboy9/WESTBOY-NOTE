package com.lachesis.lachesislog.starter.context.monitor;

import com.lachesis.lachesislog.starter.LachesisLogProperties;
import com.lachesis.lachesislog.starter.util.SpringHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StopWatch;

@Slf4j
public class SimpleMonitor {

    private final StopWatch stopWatch;
    private final boolean on;

    public SimpleMonitor(String name) {
        LachesisLogProperties properties = SpringHelper.getBeanElseNull(LachesisLogProperties.class);
        this.on = properties != null && properties.isMonitorEnable();
        this.stopWatch = new StopWatch(name);
    }

    public void start(String name) {
        if (on) {
            stopWatch.start(name);
        }
    }

    public void stop() {
        if (on) {
            stopWatch.stop();
        }
    }

    public void print() {
        if (on) {
            log.info("监控信息:\n{}", stopWatch.prettyPrint());
        }
    }
}
