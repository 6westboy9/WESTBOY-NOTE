package com.lachesis.lachesislog.starter.visitor;

import com.lachesis.lachesislog.starter.context.domain.DataOpExitLog;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;

public interface IDataOpVisitor {

    void visitRecord(DataOpExitLog entity, DataOpExitLogRecord record);

}
