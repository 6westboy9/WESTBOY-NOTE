package com.lachesis.lachesislog.starter.context;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLog;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;
import com.lachesis.lachesislog.starter.function.parser.DataOpExitLogParser;
import com.lachesis.lachesislog.starter.generator.*;
import com.lachesis.lachesislog.starter.metadata.DataOpExitLogAnnoMetadata;
import com.lachesis.lachesislog.starter.util.JSONConverter;
import com.lachesis.lachesislog.starter.util.SpringHelper;
import com.lachesis.lachesislog.starter.visitor.IDataOpVisitor;
import com.lachesis.lachesislog.transport.OpType;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
public class DataOpExitLogInvokeInterceptor extends AbstractInvokeInterceptor {

    private final DataOpExitLogAnnoMetadata annoMetadata;
    private final IDataOpVisitor visitor;

    public DataOpExitLogInvokeInterceptor(MethodInvoker methodInvoker, DataOpExitLogAnnoMetadata annoMetadata) {
        super(methodInvoker, new DataOpExitLogParser(methodInvoker, annoMetadata));
        this.annoMetadata = annoMetadata;
        this.visitor = SpringHelper.getBeanElseNull(annoMetadata.getVisitor());
    }

    @Override
    protected boolean isOpen() {
        return parser.isOpen();
    }

    @Override
    public String name() {
        return this.getClass().getSimpleName();
    }

    @Override
    public void preInvoke() {
        if (isOpen()) {
            LogContextManager.createDataOpExitLog();
            if (StrUtil.isEmpty(annoMetadata.getBefore())) {
                return;
            }
            String result = parser.parseExpression(annoMetadata.getBefore(), true);
            annoMetadata.setBefore(result);
        }
    }

    @Override
    public void postInvoke() {
        if (isOpen()) {
            DataOpExitLog exitLog = LogContextManager.getDataOpExitLog();
            if (exitLog != null) {
                exitLog.setOpName(parser.parseExpression(annoMetadata.getOpName()));
                exitLog.setOpType(annoMetadata.getOpType());
                exitLog.setId(annoMetadata.getId());
                exitLog.setThrowable(methodInvoker.getThrowable());
                exitLog.setOwner(annoMetadata.getOwner());

                // 前置处理了不用再进行解析
                String beforeStr = annoMetadata.getBefore();
                Map<String, JSONObject> beforeMap = convertToMap(beforeStr, annoMetadata.getId());
                String afterStr = parser.parseExpression(annoMetadata.getAfter(), true);
                Map<String, JSONObject> afterMap = convertToMap(afterStr, annoMetadata.getId());
                OpType opType = annoMetadata.getOpType();
                switch (opType) {
                    case CREATE:
                        afterMap.forEach((k, after) -> {
                            IDataOpExitLogRecordGenerator generator = new CreateDataOpExitLogRecordGenerator(annoMetadata.getId(), after);
                            generateAndAddRecord(exitLog, generator);
                        });
                        break;
                    case UPDATE:
                        afterMap.forEach((k, after) -> {
                            JSONObject before = beforeMap.get(k);
                            IDataOpExitLogRecordGenerator generator = new UpdateDataOpExitLogRecordGenerator(annoMetadata.getId(), before, after, annoMetadata.getExclude());
                            generateAndAddRecord(exitLog, generator);
                        });
                        break;
                    case DELETE:
                        beforeMap.forEach((k, before) -> {
                            IDataOpExitLogRecordGenerator generator = new DeleteDataOpExitLogRecordGenerator(annoMetadata.getId(), before);
                            generateAndAddRecord(exitLog, generator);
                        });
                        break;
                    case SELECT:
                        afterMap.forEach((k, after) -> {
                            IDataOpExitLogRecordGenerator generator = new SelectDataOpExitLogRecordGenerator(annoMetadata.getId(), after);
                            generateAndAddRecord(exitLog, generator);
                        });
                        break;
                    default:
                        throw new IllegalStateException("暂不支持的操作类型");
                }
            }
            LogContextManager.stopDataOpExitLog(exitLog);
        }
    }

    private void generateAndAddRecord(DataOpExitLog exitLog, IDataOpExitLogRecordGenerator generator) {
        DataOpExitLogRecord record = generator.generate();
        if (record == null) {
            return;
        }
        if (visitor != null) {
            visitor.visitRecord(exitLog, record);
        }
        exitLog.addRecord(record);
    }

    private Map<String, JSONObject> convertToMap(String str, String id) {
        Map<String, JSONObject> map = new HashMap<>();
        if (StrUtil.isEmpty(str)) {
            return map;
        }
        JSONConverter converter = JSONConverter.newInstance(str);
        converter.convert();
        if (converter.isOk()) {
            switch (converter.getJsonType()) {
                case JSON_OBJECT:
                    JSONObject object = converter.getJsonObject();
                    map.put(getValue(object, id), object);
                    break;
                case JSON_ARRAY:
                    List<JSONObject> list = JSONUtil.toList(converter.getJsonArray(), JSONObject.class);
                    Function<JSONObject, String> function = jsonObject -> getValue(jsonObject, id);
                    map = list.stream().collect(Collectors.toMap(function, v -> v, (a, b) -> a));
            }
        }
        return map;
    }

    private String getValue(JSONObject object, String id) {
        if (id.contains(StrUtil.COMMA)) {
            String[] split = id.split(StrUtil.COMMA);
            List<String> idList = Arrays.stream(split).map(object::getStr).collect(Collectors.toList());
            return CollUtil.join(idList, StrUtil.COLON);
        }
        return object.getStr(id);
    }
}