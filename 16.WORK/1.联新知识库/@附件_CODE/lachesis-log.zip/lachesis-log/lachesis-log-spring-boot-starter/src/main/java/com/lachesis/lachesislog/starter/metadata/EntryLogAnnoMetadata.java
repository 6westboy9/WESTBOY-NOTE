package com.lachesis.lachesislog.starter.metadata;

import com.lachesis.lachesislog.starter.annotation.LachesisEntryLog;
import com.lachesis.lachesislog.starter.visitor.IEntryLogVisitor;
import lombok.Data;

@Data
public class EntryLogAnnoMetadata {

    private String module;
    private String opName;
    private String operator;
    private String condition;
    private String content;
    private boolean ignoreEmptyContent;
    private Class<? extends IEntryLogVisitor> visitor;
    private String logId;

    public static EntryLogAnnoMetadata ofLog(LachesisEntryLog entryLog) {
        EntryLogAnnoMetadata metadata = new EntryLogAnnoMetadata();
        metadata.setModule(entryLog.module());
        metadata.setOpName(entryLog.opName());
        metadata.setOperator(entryLog.operator());
        metadata.setCondition(entryLog.condition());
        metadata.setContent(entryLog.content());
        metadata.setIgnoreEmptyContent(entryLog.ignoreEmptyContent());
        metadata.setVisitor(entryLog.visitor());
        metadata.setLogId(entryLog.logId());
        return metadata;
    }
}
