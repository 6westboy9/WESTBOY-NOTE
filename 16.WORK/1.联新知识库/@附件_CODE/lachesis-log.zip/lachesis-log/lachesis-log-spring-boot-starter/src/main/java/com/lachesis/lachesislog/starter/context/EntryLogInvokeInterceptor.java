package com.lachesis.lachesislog.starter.context;

import cn.hutool.core.util.StrUtil;
import com.lachesis.lachesislog.starter.util.SpringHelper;
import com.lachesis.lachesislog.starter.context.domain.EntryLog;
import com.lachesis.lachesislog.starter.function.parser.EntryLogParser;
import com.lachesis.lachesislog.starter.metadata.EntryLogAnnoMetadata;
import com.lachesis.lachesislog.starter.visitor.IEntryLogVisitor;

public class EntryLogInvokeInterceptor extends AbstractInvokeInterceptor {

    private final EntryLogAnnoMetadata annoMetadata;
    private final IEntryLogVisitor visitor;

    public EntryLogInvokeInterceptor(MethodInvoker methodInvoker, EntryLogAnnoMetadata annoMetadata) {
        super(methodInvoker, new EntryLogParser(methodInvoker, annoMetadata));
        this.annoMetadata = annoMetadata;
        this.visitor = SpringHelper.getBeanElseNull(annoMetadata.getVisitor());
    }

    @Override
    public String name() {
        return this.getClass().getSimpleName();
    }

    @Override
    public void preInvoke() {
        if (isOpen()) {
            LogContextManager.createEntryLog();
        }
    }

    @Override
    public void postInvoke() {
        if (isOpen()) {
            EntryLog entity = LogContextManager.getEntryLog();
            if (entity != null) {
                entity.setOpName(parser.parseExpression(annoMetadata.getOpName()));
                // 通过com.lachesis.lachesislog.starter.context.LogContextManager.setModule已经设置过了就不会再覆盖
                if (StrUtil.isEmpty(entity.getModule())) {
                    entity.setModule(annoMetadata.getModule());
                }
                entity.setOperator(parser.parseExpression(annoMetadata.getOperator()));
                entity.setContent(parser.parseExpression(annoMetadata.getContent()));
                entity.setIgnoreEmptyContent(annoMetadata.isIgnoreEmptyContent());
                entity.setThrowable(methodInvoker.getThrowable());
                entity.setVisitor(visitor);
                entity.setLogId(parser.parseExpression(annoMetadata.getLogId()));
            }
            LogContextManager.stopEntryLog(entity);
        }
    }

    @Override
    protected boolean isOpen() {
        return parser.isOpen();
    }
}
