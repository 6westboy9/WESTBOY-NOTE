package com.lachesis.lachesislog.starter.generator;

import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;

public interface IDataOpExitLogRecordGenerator {

    DataOpExitLogRecord generate();

}
