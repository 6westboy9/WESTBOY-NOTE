package com.lachesis.lachesislog.starter.context;

import com.lachesis.lachesislog.starter.function.parser.ILogParser;

public abstract class AbstractInvokeInterceptor implements InvokeInterceptor {

    protected final MethodInvoker methodInvoker;
    protected final ILogParser parser;

    protected AbstractInvokeInterceptor(MethodInvoker methodInvoker, ILogParser parser) {
        this.methodInvoker = methodInvoker;
        this.parser = parser;
    }

    protected abstract boolean isOpen();
}
