package com.lachesis.lachesislog.starter.visitor;

import com.lachesis.lachesislog.transport.LachesisLogVector;
import org.springframework.stereotype.Component;

@Component
public class DefaultEntryLogVisitor implements IEntryLogVisitor {

    @Override
    public void visitVector(LachesisLogVector vector) {
    }

}
