package com.lachesis.lachesislog.starter.context;

public interface InvokeInterceptor {

    String name();

    void preInvoke();

    void postInvoke();

}
