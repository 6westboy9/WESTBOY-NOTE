package com.lachesis.lachesislog.starter.context;

import com.lachesis.lachesislog.starter.context.domain.CommonExitLog;
import com.lachesis.lachesislog.starter.function.parser.CommonExitLogParser;
import com.lachesis.lachesislog.starter.metadata.CommonExitLogAnnoMetadata;

public class CommonExitLogInvokeInterceptor extends AbstractInvokeInterceptor {

    private final CommonExitLogAnnoMetadata annoMetadata;

    public CommonExitLogInvokeInterceptor(MethodInvoker methodInvoker, CommonExitLogAnnoMetadata annoMetadata) {
        super(methodInvoker, new CommonExitLogParser(methodInvoker, annoMetadata));
        this.annoMetadata = annoMetadata;
    }

    @Override
    protected boolean isOpen() {
        return parser.isOpen();
    }

    @Override
    public String name() {
        return this.getClass().getSimpleName();
    }

    @Override
    public void preInvoke() {
        if (isOpen()) {
            LogContextManager.createCommonExitLog();
        }
    }

    @Override
    public void postInvoke() {
        if (isOpen()) {
            CommonExitLog entity = LogContextManager.getCommonExitLog();
            if (entity != null) {
                entity.setOpName(parser.parseExpression(annoMetadata.getOpName()));
                entity.setContent(parser.parseExpression(annoMetadata.getContent()));
                entity.setThrowable(methodInvoker.getThrowable());
            }
            LogContextManager.stopCommonExitLot(entity);
        }
    }
}
