package com.lachesis.lachesislog.starter.generator;

import cn.hutool.json.JSONObject;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;
import com.lachesis.lachesislog.transport.OpType;

public class DeleteDataOpExitLogRecordGenerator extends AbstractDataOpExitLogRecordGenerator {

    private final JSONObject beforeData;

    public DeleteDataOpExitLogRecordGenerator(String primaryFieldName, JSONObject beforeData) {
        super(OpType.DELETE, primaryFieldName);
        this.beforeData = beforeData;
    }

    @Override
    public DataOpExitLogRecord generate() {
        return generateByBefore(beforeData);
    }

}
