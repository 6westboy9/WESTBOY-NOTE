package com.lachesis.lachesislog.starter.visitor;

import com.lachesis.lachesislog.transport.LachesisLogVector;

public interface IEntryLogVisitor {

    void visitVector(LachesisLogVector vector);

}
