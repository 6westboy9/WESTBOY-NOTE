package com.lachesis.lachesislog.starter;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Slf4j
@Setter
@Getter
@ConfigurationProperties(prefix = "lachesislog")
public class LachesisLogProperties {
    /**
     * 是否开启操作日志，默认关闭
     */
    @Value("${enable:true}")
    private boolean enable;
    /**
     * 是否开启操作日志明细，默认关闭
     */
    @Value("${log-enable:false}")
    private boolean logEnable;
    /**
     * 是否开启操作采集监控日志，默认关闭
     */
    @Value("${monitor-enable:false}")
    private boolean monitorEnable;
    /**
     * 采集日志处理监听器名称，默认default.仅在控制台输出日志，可以配置rabbitmq，在配置为rabbitmq时，需要配置其详细信息
     * <p>
     * {@link  com.lachesis.lachesislog.starter.LachesisLogRabbitProperties}
     */
    @Value("${listener-name:default}")
    private String listenerName;
}