package com.lachesis.lachesislog.starter.context.listener;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.starter.LachesisLogProperties;
import com.lachesis.lachesislog.transport.LachesisEntryLog;
import com.lachesis.lachesislog.transport.LachesisLogMessage;
import com.lachesis.lachesislog.transport.LachesisLogVector;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@AllArgsConstructor
public class LogListenerManager {

    private final List<ILogListener> listeners;

    public void notifyFinish(LachesisEntryLog entryLog) {
        if (CollUtil.isEmpty(listeners)) {
            log.warn("不存在有效LogListener");
            return;
        }
        for (ILogListener listener : listeners) {
            listener.finished(entryLog);
        }
    }
}
