package com.lachesis.lachesislog.starter.config;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LachesisLogConfigHelper {

    private static final LachesisLogConfigHelper INSTANCE = new LachesisLogConfigHelper();
    /**
     * 默认是开启的，只有业务端扩展异常时默认为false
     */
    private static final boolean DEFAULT_ENABLE = true;
    private static final boolean DEFAULT_LOG_ENABLE = false;
    private static final boolean DEFAULT_MONITOR_ENABLE = false;
    private boolean set = false;
    private ILachesisLogCustomConfig customConfig;

    private LachesisLogConfigHelper() {
    }

    public static LachesisLogConfigHelper getInstance() {
        return INSTANCE;
    }

    public synchronized void setCustomConfig(ILachesisLogCustomConfig customConfig) {
        if (!set) {
            this.customConfig = customConfig;
            set = true;
        }
    }

    public synchronized boolean isEnable() {
        // 默认LachesisLogDynamicSwitch实例不存在，意为开启
        if (customConfig == null) {
            return DEFAULT_ENABLE;
        }
        try {
            return customConfig.isEnable();
        } catch (Exception e) {
            // 防止业务端自定义操作异常未捕获，兜底策略
            log.warn("自定义动态[enable]配置获取异常", e);
            return DEFAULT_ENABLE;
        }
    }

    public synchronized boolean logEnabled() {
        // 默认LachesisLogDynamicSwitch实例不存在，意为开启
        if (customConfig == null) {
            return DEFAULT_LOG_ENABLE;
        }
        try {
            return customConfig.logEnable();
        } catch (Exception e) {
            // 防止业务端自定义操作异常未捕获，兜底策略
            log.warn("自定义动态[log-enable]配置获取异常", e);
            return DEFAULT_LOG_ENABLE;
        }
    }

    public synchronized boolean monitorEnabled() {
        // 默认LachesisLogDynamicSwitch实例不存在，意为开启
        if (customConfig == null) {
            return DEFAULT_MONITOR_ENABLE;
        }
        try {
            return customConfig.monitorEnable();
        } catch (Exception e) {
            // 防止业务端自定义操作异常未捕获，兜底策略
            log.warn("自定义动态[monitor-enable]配置获取异常", e);
            return DEFAULT_MONITOR_ENABLE;
        }
    }
}
