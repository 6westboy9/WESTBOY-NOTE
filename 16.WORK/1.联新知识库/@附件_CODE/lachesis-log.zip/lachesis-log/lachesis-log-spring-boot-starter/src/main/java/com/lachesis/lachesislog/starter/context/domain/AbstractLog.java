package com.lachesis.lachesislog.starter.context.domain;

import cn.hutool.json.JSONObject;
import com.lachesis.lachesislog.starter.context.LogContext;
import lombok.Data;

@Data
public abstract class AbstractLog {

    /**
     * 开始时间
     */
    protected long startTime;
    /**
     * 结束时间
     */
    protected long endTime;
    /**
     * 执行是否发生错误
     */
    protected boolean isError;
    /**
     * 异常信息
     */
    protected Throwable throwable;
    /**
     * 业务端扩展使用
     */
    protected JSONObject attachments = new JSONObject();

    public void start() {
        startTime = System.currentTimeMillis();
    }

    public void stop() {
        endTime = System.currentTimeMillis();
    }

    public void setThrowable(Throwable throwable) {
        if (throwable != null) {
            this.isError = true;
            this.throwable = throwable;
        }
    }

    public void attach(String k, Object v) {
        attachments.set(k, v);
    }
}
