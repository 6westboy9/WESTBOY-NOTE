package com.lachesis.lachesislog.starter.function.parser;

import com.lachesis.lachesislog.starter.context.MethodInvoker;
import com.lachesis.lachesislog.starter.metadata.DataOpExitLogAnnoMetadata;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DataOpExitLogParser extends AbstractLogParser {

    private final DataOpExitLogAnnoMetadata lLogItemAnnoMetadata;

    public DataOpExitLogParser(MethodInvoker methodWrapper, DataOpExitLogAnnoMetadata lLogItemAnnoMetadata) {
        super(methodWrapper);
        this.lLogItemAnnoMetadata = lLogItemAnnoMetadata;
    }

    @Override
    public boolean isOpen() {
        return Boolean.parseBoolean(parseExpression(lLogItemAnnoMetadata.getCondition()));
    }
}
