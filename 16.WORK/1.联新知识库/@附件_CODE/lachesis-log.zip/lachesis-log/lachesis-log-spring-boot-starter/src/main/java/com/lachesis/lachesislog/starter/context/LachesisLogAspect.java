package com.lachesis.lachesislog.starter.context;

import com.lachesis.lachesislog.starter.config.LachesisLogConfigHelper;
import lombok.AllArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Order(1)
@Component
@AllArgsConstructor
public class LachesisLogAspect {

    @Pointcut("@annotation(com.lachesis.lachesislog.starter.annotation.LachesisEntryLog)" +
        "|| @annotation(com.lachesis.lachesislog.starter.annotation.LachesisCommonExitLog) " +
        "|| @annotation(com.lachesis.lachesislog.starter.annotation.LachesisDataOpExitLog)")
    public void pointCut() {
    }

    @Around("pointCut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        // 主要是为了方便配置中心动态开关
        if (!LachesisLogConfigHelper.getInstance().isEnable()) {
            return joinPoint.proceed();
        }
        MethodInvoker invoker = MethodInvoker.newInstance(joinPoint);
        invoker.preInvoke();
        Object result = invoker.doInvoke();
        invoker.postInvoke();
        if (!invoker.isSuccess()) {
            throw invoker.getThrowable();
        }
        return result;
    }
}
