package com.lachesis.lachesislog.starter.annotation;


import com.lachesis.lachesislog.starter.visitor.DefaultDataOpVisitor;
import com.lachesis.lachesislog.starter.visitor.IDataOpVisitor;
import com.lachesis.lachesislog.transport.OpType;

import java.lang.annotation.*;

/**
 * 主要应对数据的增删改查操作的场景，比如数据库，RPC，缓存等等
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface LachesisDataOpExitLog {
    /**
     * 操作名称，当前操作的简要描述
     */
    String opName();
    /**
     * 操作类型，目前仅支持增删改，对于查询还不支持
     */
    OpType opType();
    /**
     * 当前操作数据的唯一标识，支持联合字段标识唯一性，使用英文逗号分割
     */
    String id();
    /**
     * 当前操作的数据变更前的内容，有两种方式获取：1.直接设置字符串类型的数据；2.通过SPEL表达式获取
     */
    String before() default "";
    /**
     * 当前操作的数据变更后的内容，有两种方式获取：1.直接设置字符串类型的数据；2.通过SPEL表达式获取
     */
    String after() default "";
    /**
     * 通用结果中，排除属性名称数组
     */
    String[] exclude() default {};
    /**
     * 日志记录条件，为true时才会记录，否则，不会
     */
    String condition() default "true";
    /**
     * 访问者模式，方便业务方对框架生成的通用日志生成的增删改结果进一步加工处理
     */
    Class<? extends IDataOpVisitor> visitor() default DefaultDataOpVisitor.class;
    /**
     * 所属主体，根据使用场景不同，填写的内容不一样，但是含义基本类似，表示当前操作的数据所属的主体
     *
     * <ol>
     *     <li>在MySQL操作场景下存储的是表名，即当前操作的数据所属的主体是某个表中的数据</li>
     *     <li>在MongoDB操作场景下存储的是集合名称，即当前操作的数据所属的主体是某个集合中的数据</li>
     * </ol>
     */
    String owner();
}
