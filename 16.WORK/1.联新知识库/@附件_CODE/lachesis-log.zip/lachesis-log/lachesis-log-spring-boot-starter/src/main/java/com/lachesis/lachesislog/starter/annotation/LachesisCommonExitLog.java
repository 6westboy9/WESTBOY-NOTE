package com.lachesis.lachesislog.starter.annotation;

import java.lang.annotation.*;

/**
 * 主要应对于简单的日志记录场景
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface LachesisCommonExitLog {
    /**
     * 操作名称
     */
    String opName();
    /**
     * 操作内容
     */
    String content() default "";
    /**
     * 日志记录条件，为true时才会记录，否则，不会
     */
    String condition() default "true";
}
