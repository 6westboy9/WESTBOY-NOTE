package com.lachesis.lachesislog.starter.config;

import cn.hutool.core.util.StrUtil;
import com.lachesis.lachesislog.starter.LachesisLogProperties;
import com.lachesis.lachesislog.starter.LachesisLogRabbitProperties;
import com.lachesis.lachesislog.starter.context.listener.ILogListener;
import com.lachesis.lachesislog.starter.context.listener.impl.DefaultLogListener;
import com.lachesis.lachesislog.starter.context.listener.impl.RabbitLogListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.*;
import org.springframework.core.type.AnnotatedTypeMetadata;

@Slf4j
@Configuration
@ComponentScan({"com.lachesis.lachesislog.starter", "cn.hutool.extra.spring"})
@ConditionalOnProperty(prefix = "lachesislog", name = "enable", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties({LachesisLogProperties.class, LachesisLogRabbitProperties.class})
public class LachesisLogAutoConfiguration {

    @Conditional(RabbitConditional.class)
    static class RabbitListener {
        @Bean
        public ILogListener logListener(LachesisLogRabbitProperties lachesisLogRabbitProperties) {
            RabbitLogListener listener = new RabbitLogListener(lachesisLogRabbitProperties);
            log.info("LogListener Bean: {}", listener.getClass().getSimpleName());
            return listener;
        }
    }

    @Conditional(DefaultConditional.class)
    static class DefaultListener {
        @Bean
        public ILogListener logListener() {
            DefaultLogListener listener = new DefaultLogListener();
            log.info("LogListener Bean: {}", listener.getClass().getSimpleName());
            return listener;
        }
    }

    private static class RabbitConditional implements Condition {
        @Override
        public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
            String value = context.getEnvironment().getProperty("lachesislog.listener-name");
            return "rabbitmq".equalsIgnoreCase(value);
        }
    }

    private static class DefaultConditional implements Condition {
        @Override
        public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
            String value = context.getEnvironment().getProperty("lachesislog.listener-name");
            return "default".equalsIgnoreCase(value) || StrUtil.isEmpty(value);
        }
    }
}
