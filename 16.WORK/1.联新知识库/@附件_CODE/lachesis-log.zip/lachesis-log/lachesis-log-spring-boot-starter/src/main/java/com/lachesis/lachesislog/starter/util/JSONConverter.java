package com.lachesis.lachesislog.starter.util;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * JSON转换工具
 */
@Slf4j
@Getter
public class JSONConverter {

    private final String str;
    private boolean ok;
    private JSONObject jsonObject;
    private JSONArray jsonArray;
    private JSONType jsonType;

    private JSONConverter(String str) {
        this.str = str;
    }

    public static JSONConverter newInstance(String str) {
        return new JSONConverter(str);
    }

    public void convert() {
        if (StrUtil.isEmpty(str)) {
            this.ok = false;
            return;
        }
        JSONResult<JSONObject> pareJsonObj = pareJsonObj(str);
        if (pareJsonObj.isOk()) {
            this.ok = true;
            this.jsonObject = pareJsonObj.getJsonData();
            this.jsonType = JSONType.JSON_OBJECT;
            return;
        }
        JSONResult<JSONArray> pareJsonArray = pareJsonArray(str);
        if (pareJsonArray.isOk()) {
            this.ok = true;
            this.jsonArray = pareJsonArray.getJsonData();
            this.jsonType = JSONType.JSON_ARRAY;
        }
    }

    private JSONResult<JSONObject> pareJsonObj(String str) {
        if (!JSONUtil.isJsonObj(str)) {
            return JSONResult.fail();
        }
        try {
            // 上述JSONUtil#isJsonObj并不能判断出是JSON格式，比如{P}
            return JSONResult.success(JSONUtil.parseObj(str));
        } catch (Exception e) {
            log.warn("转换JSON对象失败:{}", str);
            return JSONResult.fail();
        }
    }

    private JSONResult<JSONArray> pareJsonArray(String str) {
        if (!JSONUtil.isJsonArray(str)) {
            return JSONResult.fail();
        }
        try {
            // 上述JSONUtil#isJsonArray并不能判断出是JSON格式，比如[P]
            return JSONResult.success(JSONUtil.parseArray(str));
        } catch (Exception e) {
            log.warn("转换JSON数组失败:{}", str);
            return JSONResult.fail();
        }
    }
}
