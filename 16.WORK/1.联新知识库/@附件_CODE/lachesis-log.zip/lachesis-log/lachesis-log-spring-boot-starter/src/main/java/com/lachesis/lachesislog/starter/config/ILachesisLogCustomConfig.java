package com.lachesis.lachesislog.starter.config;


public interface ILachesisLogCustomConfig {

    boolean isEnable();

    boolean logEnable();

    boolean monitorEnable();
}
