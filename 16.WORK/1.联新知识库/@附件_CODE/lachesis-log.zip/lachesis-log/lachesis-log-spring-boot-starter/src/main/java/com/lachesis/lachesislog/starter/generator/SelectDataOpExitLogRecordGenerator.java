package com.lachesis.lachesislog.starter.generator;

import cn.hutool.json.JSONObject;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecordField;
import com.lachesis.lachesislog.transport.OpType;

public class SelectDataOpExitLogRecordGenerator extends AbstractDataOpExitLogRecordGenerator {

    private final JSONObject afterData;

    public SelectDataOpExitLogRecordGenerator(String primaryFieldName, JSONObject afterData) {
        super(OpType.CREATE, primaryFieldName);
        this.afterData = afterData;
    }

    @Override
    public DataOpExitLogRecord generate() {
        return generateByAfter(afterData);
    }

}
