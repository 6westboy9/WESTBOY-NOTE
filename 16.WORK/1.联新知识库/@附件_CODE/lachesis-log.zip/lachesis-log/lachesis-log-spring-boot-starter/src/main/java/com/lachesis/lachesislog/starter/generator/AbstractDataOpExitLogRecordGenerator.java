package com.lachesis.lachesislog.starter.generator;


import cn.hutool.json.JSONObject;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecordField;
import com.lachesis.lachesislog.transport.OpType;

public abstract class AbstractDataOpExitLogRecordGenerator implements IDataOpExitLogRecordGenerator {

    protected final OpType opType;
    protected final String id;

    protected AbstractDataOpExitLogRecordGenerator(OpType opType, String id) {
        this.opType = opType;
        this.id = id;
    }

    protected DataOpExitLogRecord generateByAfter(JSONObject afterData) {
        DataOpExitLogRecord record = new DataOpExitLogRecord();
        afterData.forEach((k, v) -> {
            DataOpExitLogRecordField field = new DataOpExitLogRecordField();
            field.setName(k);
            field.setAfter(v);
            record.addField(k, field);
        });
        record.setOpType(opType);
        record.setId(id);
        record.setPValue(afterData.getStr(id));
        record.setAfterData(afterData);
        return record;
    }

    protected DataOpExitLogRecord generateByBefore(JSONObject beforeData) {
        DataOpExitLogRecord record = new DataOpExitLogRecord();
        beforeData.forEach((k, v) -> {
            DataOpExitLogRecordField field = new DataOpExitLogRecordField();
            field.setName(k);
            field.setBefore(v);
            record.addField(k, field);
        });
        record.setOpType(opType);
        record.setId(id);
        record.setPValue(beforeData.getStr(id));
        record.setBeforeData(beforeData);
        return record;
    }
}
