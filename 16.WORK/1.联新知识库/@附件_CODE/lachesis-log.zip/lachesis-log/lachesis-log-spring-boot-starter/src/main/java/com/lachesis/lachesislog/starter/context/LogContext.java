package com.lachesis.lachesislog.starter.context;

import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.starter.LachesisLogProperties;
import com.lachesis.lachesislog.starter.util.SpringHelper;
import com.lachesis.lachesislog.starter.context.domain.CommonExitLog;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLog;
import com.lachesis.lachesislog.starter.context.domain.EntryLog;
import com.lachesis.lachesislog.starter.context.listener.LogListenerManager;
import com.lachesis.lachesislog.transport.LachesisCommonExitLog;
import com.lachesis.lachesislog.transport.LachesisDataOpExitLog;
import com.lachesis.lachesislog.transport.LachesisEntryLog;
import com.lachesis.lachesislog.transport.LachesisLogVector;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class LogContext {

    private EntryLog entryLog;
    private final LinkedList<DataOpExitLog> dataOpExitLogs = new LinkedList<>();
    private final LinkedList<CommonExitLog> commonExitLogs = new LinkedList<>();

    public EntryLog createEntryLog() {
        EntryLog entity = new EntryLog();
        entity.start();
        entryLog = entity;
        return entity;
    }

    public EntryLog getEntryLog() {
        return entryLog;
    }

    public void stopEntryLog(EntryLog entryLog) {
        if (entryLog != null) {
            entryLog.stop();
            LachesisLogVector vector = transform();
            LachesisLogProperties properties = SpringHelper.getBeanElseNull(LachesisLogProperties.class);
            if (properties != null && properties.isLogEnable()) {
                log.info("操作明细:{}", JSONUtil.toJsonStr(vector));
            }
            entryLog.visitVector(vector);
            LachesisEntryLog lachesisEntryLog = vector.getEntryLog();
            boolean ignoreEmptyContent = entryLog.isIgnoreEmptyContent();
            if (entryLog.isIgnoreEmptyContent() && StrUtil.isEmpty(lachesisEntryLog.getContent())) {
                log.warn("操作内容为空不做处理:{}", JSONUtil.toJsonStr(lachesisEntryLog));
                return;
            }
            notifyFinish(lachesisEntryLog);
        }
    }

    public DataOpExitLog createDataOpExitLog() {
        DataOpExitLog entity = new DataOpExitLog();
        entity.start();
        dataOpExitLogs.addLast(entity);
        return entity;
    }

    public DataOpExitLog getDataOpExitLog() {
        return dataOpExitLogs.getLast();
    }

    public LinkedList<DataOpExitLog> getDataOpExitLogs() {
        return dataOpExitLogs;
    }

    public void stopDataOpExitLog(DataOpExitLog dataOpExitLog) {
        dataOpExitLog.stop();
    }

    public CommonExitLog createCommonExitLog() {
        CommonExitLog entity = new CommonExitLog();
        entity.start();
        commonExitLogs.addLast(entity);
        return entity;
    }

    public CommonExitLog getCommonExitLog() {
        return commonExitLogs.getLast();
    }

    public LinkedList<CommonExitLog> getCommonExitLogs() {
        return commonExitLogs;
    }

    public void stopCommonExitLog(CommonExitLog commonExitLog) {
        commonExitLog.stop();
    }

    public void attachToEntryLog(String k, Object v) {
        entryLog.attach(k, v);
    }

    public void setModule(String module) {
        entryLog.setModule(module);
    }

    private LachesisLogVector transform() {
        LachesisLogVector lachesisLogVector = new LachesisLogVector();
        lachesisLogVector.setEntryLog(entryLog.transform());
        lachesisLogVector.setCommonExitLogs(transformCommonExitLogs());
        lachesisLogVector.setDataOpExitLogs(transformDataOpExitLogs());
        return lachesisLogVector;
    }

    private List<LachesisDataOpExitLog> transformDataOpExitLogs() {
        if (dataOpExitLogs.isEmpty()) {
            return Collections.emptyList();
        }
        return dataOpExitLogs.stream().map(DataOpExitLog::transform).collect(Collectors.toList());
    }

    private List<LachesisCommonExitLog> transformCommonExitLogs() {
        if (commonExitLogs.isEmpty()) {
            return Collections.emptyList();
        }
        return commonExitLogs.stream().map(CommonExitLog::transform).collect(Collectors.toList());
    }

    private void notifyFinish(LachesisEntryLog entryLog) {
        LogListenerManager listenerManager = SpringUtil.getBean(LogListenerManager.class);
        listenerManager.notifyFinish(entryLog);
    }
}