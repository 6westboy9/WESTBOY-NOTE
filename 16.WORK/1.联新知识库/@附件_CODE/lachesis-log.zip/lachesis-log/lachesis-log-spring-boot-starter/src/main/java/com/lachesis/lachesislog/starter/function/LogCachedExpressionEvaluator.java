package com.lachesis.lachesislog.starter.function;

import com.lachesis.lachesislog.starter.context.MethodInvoker;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.context.expression.AnnotatedElementKey;
import org.springframework.context.expression.BeanFactoryResolver;
import org.springframework.context.expression.CachedExpressionEvaluator;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 缓存表达式求值器
 */
@Component
public class LogCachedExpressionEvaluator extends CachedExpressionEvaluator implements BeanFactoryAware {

    private static final String RESULT = "_result";
    private static final String SUCCESS = "_success";
    private static final Map<ExpressionKey, Expression> KEY_CACHE = new ConcurrentHashMap<>(64);
    private BeanFactory beanFactory;

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    public EvaluationContext createEvaluationContext(MethodInvoker methodInvoker) {
        LogEvaluationContext evaluationContext = new LogEvaluationContext(methodInvoker, super.getParameterNameDiscoverer());
        evaluationContext.setVariable(RESULT, methodInvoker.getResult());
        evaluationContext.setVariable(SUCCESS, methodInvoker.isSuccess());
        if (beanFactory != null) {
            evaluationContext.setBeanResolver(new BeanFactoryResolver(beanFactory));
        }
        return evaluationContext;
    }

    public Object parseExpression(String expression, AnnotatedElementKey methodKey, EvaluationContext evalContext) {
        return getExpression(KEY_CACHE, methodKey, expression).getValue(evalContext);
    }

    public void clear() {
        KEY_CACHE.clear();
    }

}
