package com.lachesis.lachesislog.starter.config;

import com.lachesis.lachesislog.starter.util.SpringHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class LachesisLogApplicationRunner implements ApplicationRunner {

    @Override
    public void run(ApplicationArguments args) {
        ILachesisLogCustomConfig customConfig = SpringHelper.getBeanElseNull(ILachesisLogCustomConfig.class);
        if (customConfig != null) {
            log.info("Setting LachesisLogConfigHelper customConfig is {}", customConfig.getClass().getSimpleName());
            LachesisLogConfigHelper.getInstance().setCustomConfig(customConfig);
        }
    }
}
