package com.lachesis.lachesislog.starter.function;

import com.lachesis.lachesislog.starter.context.MethodInvoker;
import org.springframework.context.expression.MethodBasedEvaluationContext;
import org.springframework.core.ParameterNameDiscoverer;

/**
 * 其主要作用是将方法参数放入到上下文中
 */
public class LogEvaluationContext extends MethodBasedEvaluationContext {

    public LogEvaluationContext(MethodInvoker methodInvoker, ParameterNameDiscoverer parameterNameDiscoverer) {
        super(methodInvoker.getTarget(), methodInvoker.getMethod(), methodInvoker.getArgs(), parameterNameDiscoverer);
    }
}
