package com.lachesis.lachesislog.starter.function.parser;

public interface ILogParser {

    boolean isOpen();

    String parseExpression(String template);

    String parseExpression(String template, boolean toJsonStr);

}
