package com.lachesis.lachesislog.starter.function.parser;

import com.lachesis.lachesislog.starter.context.MethodInvoker;
import com.lachesis.lachesislog.starter.metadata.EntryLogAnnoMetadata;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EntryLogParser extends AbstractLogParser {

    private final EntryLogAnnoMetadata entryLogAnnoMetadata;

    public EntryLogParser(MethodInvoker methodInvoker, EntryLogAnnoMetadata entryLogAnnoMetadata) {
        super(methodInvoker);
        this.entryLogAnnoMetadata = entryLogAnnoMetadata;
    }

    @Override
    public boolean isOpen() {
        return Boolean.parseBoolean(parseExpression(entryLogAnnoMetadata.getCondition()));
    }

}
