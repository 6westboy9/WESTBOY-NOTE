package com.lachesis.lachesislog.starter.metadata;

import cn.hutool.core.collection.CollUtil;
import com.lachesis.lachesislog.starter.annotation.LachesisDataOpExitLog;
import com.lachesis.lachesislog.starter.visitor.IDataOpVisitor;
import com.lachesis.lachesislog.transport.OpType;
import lombok.Data;

import java.util.List;

@Data
public class DataOpExitLogAnnoMetadata {
    /**
     * 描述
     */
    private String opName;
    /**
     * 操作类型
     */
    private OpType opType;
    /**
     * 变更前
     */
    private String before;
    /**
     * 变更后
     */
    private String after;
    /**
     * 唯一标识
     */
    private String id;
    /**
     * 排除比对字段
     */
    private List<String> exclude;
    /**
     * 日志记录条件，为true时才会记录，否则，不会
     */
    private String condition;
    private Class<? extends IDataOpVisitor> visitor;
    private String owner;

    public static DataOpExitLogAnnoMetadata ofLog(LachesisDataOpExitLog dataOpExitLog) {
        DataOpExitLogAnnoMetadata metadata = new DataOpExitLogAnnoMetadata();
        metadata.setOpName(dataOpExitLog.opName());
        metadata.setOpType(dataOpExitLog.opType());
        metadata.setBefore(dataOpExitLog.before());
        metadata.setAfter(dataOpExitLog.after());
        metadata.setId(dataOpExitLog.id());
        metadata.setExclude(CollUtil.newArrayList(dataOpExitLog.exclude()));
        metadata.setCondition(dataOpExitLog.condition());
        metadata.setVisitor(dataOpExitLog.visitor());
        metadata.setOwner(dataOpExitLog.owner());
        return metadata;
    }

}
