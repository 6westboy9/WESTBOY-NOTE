package com.lachesis.lachesislog.starter.function.parser;

import com.lachesis.lachesislog.starter.context.MethodInvoker;
import com.lachesis.lachesislog.starter.metadata.CommonExitLogAnnoMetadata;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonExitLogParser extends AbstractLogParser {

    private final CommonExitLogAnnoMetadata commonItemAnnoMetadata;

    public CommonExitLogParser(MethodInvoker methodWrapper, CommonExitLogAnnoMetadata commonItemAnnoMetadata) {
        super(methodWrapper);
        this.commonItemAnnoMetadata = commonItemAnnoMetadata;
    }

    @Override
    public boolean isOpen() {
        return Boolean.parseBoolean(parseExpression(commonItemAnnoMetadata.getCondition()));
    }

}
