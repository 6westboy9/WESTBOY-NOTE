package com.lachesis.lachesislog.starter;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Slf4j
@Setter
@Getter
@ConfigurationProperties(prefix = "lachesislog.listener.rabbitmq")
public class LachesisLogRabbitProperties {
    private String host;
    private int port;
    private String username;
    private String password;
    @Value("${virtual-host:/}")
    private String virtualHost;
    @Value("${exchange:lc.lachesislog.log}")
    private String exchange;
    @Value("${route-key-template:lc.lachesislog.log.%s}")
    private String routeKeyTemplate;
    @Value("${message-printable:false}")
    private boolean messagePrintable;
    @Value("${app:${spring.application.name}}")
    private String app;
}