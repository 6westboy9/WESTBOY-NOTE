package com.lachesis.lachesislog.starter.generator;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONObject;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecordField;
import com.lachesis.lachesislog.transport.OpType;
import org.apache.commons.lang3.builder.DiffBuilder;
import org.apache.commons.lang3.builder.DiffResult;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 如果是更新时，注意顺序要一致
 */
public class UpdateDataOpExitLogRecordGenerator extends AbstractDataOpExitLogRecordGenerator {

    private final JSONObject beforeData;
    private final JSONObject afterData;
    private final List<String> excludeFields;

    public UpdateDataOpExitLogRecordGenerator(String id, JSONObject beforeData,
                                              JSONObject afterData, List<String> excludeFields) {
        super(OpType.UPDATE, id);
        this.excludeFields = excludeFields;
        if (beforeData == null) {
            throw new NullPointerException("beforeData");
        }
        if (afterData == null) {
            throw new NullPointerException("afterData");
        }
        this.beforeData = beforeData;
        this.afterData = afterData;
    }

    @Override
    public DataOpExitLogRecord generate() {
        DiffBuilder<JSONObject> builder = new DiffBuilder<>(beforeData, afterData, ToStringStyle.SHORT_PREFIX_STYLE);
        Set<String> afterFieldNames = afterData.keySet();
        Set<String> beforeFieldNames = beforeData.keySet();
        Set<String> fieldNames = new HashSet<>();
        fieldNames.addAll(afterFieldNames);
        fieldNames.addAll(beforeFieldNames);
        if (CollUtil.isNotEmpty(excludeFields)) {
            excludeFields.forEach(fieldNames::remove);
        }
        fieldNames.forEach(fieldName -> builder.append(fieldName, beforeData.get(fieldName), afterData.get(fieldName)));
        DiffResult<JSONObject> diffResult = builder.build();
        List<org.apache.commons.lang3.builder.Diff<?>> diffs = diffResult.getDiffs();
        if (CollUtil.isEmpty(diffs)) {
            return null;
        }
        DataOpExitLogRecord record = new DataOpExitLogRecord();
        diffs.forEach(diff -> {
            DataOpExitLogRecordField field = new DataOpExitLogRecordField();
            field.setName(diff.getFieldName());
            field.setBefore(diff.getLeft());
            field.setAfter(diff.getRight());
            record.addField(diff.getFieldName(), field);
        });
        record.setOpType(opType);
        record.setId(id);
        record.setPValue(beforeData.getStr(id));
        record.setAfterData(afterData);
        record.setBeforeData(beforeData);
        return record;
    }
}
