package com.lachesis.lachesislog.starter.context.domain;

import com.lachesis.lachesislog.starter.visitor.IEntryLogVisitor;
import com.lachesis.lachesislog.transport.LachesisEntryLog;
import com.lachesis.lachesislog.transport.LachesisLogVector;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class EntryLog extends AbstractLog {

    /**
     * 业务模块
     */
    private String module;
    /**
     * 描述
     */
    private String opName;
    /**
     * 操作员
     */
    private String operator;
    /**
     * 操作内容（可选）
     */
    private String content;
    /**
     * 当操作明细为空时是否进行处理
     */
    private boolean ignoreEmptyContent;
    /**
     * 监听器
     */
    private IEntryLogVisitor visitor;
    private String logId;

    public LachesisEntryLog transform() {
        LachesisEntryLog entryLog = new LachesisEntryLog();
        entryLog.setModule(module);
        entryLog.setOpName(opName);
        entryLog.setOperator(operator);
        entryLog.setContent(content);
        entryLog.setStartTime(startTime);
        entryLog.setEndTime(endTime);
        entryLog.setError(isError);
        if (throwable != null) {
            entryLog.setErrorMsg(throwable.getMessage());
        }
        entryLog.setAttachments(attachments);
        entryLog.setLogId(logId);
        return entryLog;
    }

    public void visitVector(LachesisLogVector vector) {
        visitor.visitVector(vector);
    }
}
