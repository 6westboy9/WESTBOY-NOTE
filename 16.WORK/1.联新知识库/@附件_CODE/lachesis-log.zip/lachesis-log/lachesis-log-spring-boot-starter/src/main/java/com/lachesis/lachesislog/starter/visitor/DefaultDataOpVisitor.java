package com.lachesis.lachesislog.starter.visitor;

import com.lachesis.lachesislog.starter.context.domain.DataOpExitLog;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;
import org.springframework.stereotype.Component;

@Component
public class DefaultDataOpVisitor implements IDataOpVisitor {

    @Override
    public void visitRecord(DataOpExitLog entity, DataOpExitLogRecord record) {
    }

}
