package com.lachesis.lachesislog.starter.context.listener.impl;

import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.starter.context.listener.ILogListener;
import com.lachesis.lachesislog.transport.LachesisEntryLog;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DefaultLogListener implements ILogListener {

    @Override
    public void finished(LachesisEntryLog entryLog) {
        log.info("操作日志:{}", JSONUtil.toJsonStr(entryLog));
    }
}
