package com.lachesis.lachesislog.starter.util;

import cn.hutool.json.JSON;
import lombok.Data;

@Data
public class JSONResult<T extends JSON> {

    private boolean ok;
    private T jsonData;

    public static <T extends JSON> JSONResult<T> success(T jsonData) {
        JSONResult<T> res = new JSONResult<>();
        res.setOk(true);
        res.setJsonData(jsonData);
        return res;
    }

    public static <T extends JSON> JSONResult<T> fail() {
        JSONResult<T> res = new JSONResult<>();
        res.setOk(false);
        return res;
    }
}
