package com.lachesis.lachesislog.starter.context.listener.impl;

import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.starter.util.IdGenerator;
import com.lachesis.lachesislog.starter.LachesisLogRabbitProperties;

import com.lachesis.lachesislog.starter.context.listener.ILogListener;
import com.lachesis.lachesislog.transport.LachesisEntryLog;
import com.lachesis.lachesislog.transport.LachesisLogMessage;
import com.rabbitmq.client.*;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RabbitLogListener implements ILogListener {

    private Channel channel;
    private String exchange;
    private String routeKeyTemplate;
    private boolean messagePrintable;
    private String app;

    public RabbitLogListener(LachesisLogRabbitProperties properties) {
        init(properties);
    }

    public void init(LachesisLogRabbitProperties properties) {
        try {
            ConnectionFactory factory = new ConnectionFactory();
            factory.setHost(properties.getHost());
            factory.setPort(properties.getPort());
            factory.setUsername(properties.getUsername());
            factory.setPassword(properties.getPassword());
            factory.setVirtualHost(properties.getVirtualHost());
            Connection connection = factory.newConnection();
            channel = connection.createChannel();
            exchange = properties.getExchange();
            routeKeyTemplate = properties.getRouteKeyTemplate();
            messagePrintable = properties.isMessagePrintable();
            app = properties.getApp();
            channel.exchangeDeclare(exchange, BuiltinExchangeType.TOPIC, true);
        } catch (Exception e) {
            log.error("初始化失败:properties={}", JSONUtil.toJsonStr(properties), e);
        }
    }

    @Override
    public void finished(LachesisEntryLog entryLog) {
        String routingKey = String.format(routeKeyTemplate, app);
        LachesisLogMessage message = new LachesisLogMessage();
        try {
            message.setLogId(generateFinalLogId(entryLog.getLogId()));
            message.setSendTime(System.currentTimeMillis());
            message.setApp(app);
            message.setModule(entryLog.getModule());
            message.setOpName(entryLog.getOpName());
            message.setOperator(entryLog.getOperator());
            message.setContent(entryLog.getContent());
            message.setStartTime(entryLog.getStartTime());
            message.setEndTime(entryLog.getEndTime());
            message.setIsError(entryLog.isError());
            message.setErrorMsg(entryLog.getErrorMsg());
            message.setAttachments(entryLog.getAttachments());
            if (messagePrintable) {
                Map<String, Object> info = new HashMap<>();
                info.put("message", message);
                info.put("exchange", exchange);
                info.put("routingKey", routingKey);
                RabbitLogListener.log.info("发送操作日志消息:{}", JSONUtil.toJsonStr(info));
            }
            channel.basicPublish(exchange, routingKey, MessageProperties.PERSISTENT_TEXT_PLAIN, message.toBytes());
        } catch (Exception e) {
            RabbitLogListener.log.error("发送操作日志消息失败:properties={}", message, e);
        }
    }

    /**
     * 最好由业务端传递，方便后续日志跟踪
     */
    private String generateFinalLogId(String logId) {
        if (logId == null) {
            return IdGenerator.generate();
        }
        if (logId.trim().isEmpty()) {
            return IdGenerator.generate();
        }
        if ("{T(com.yomahub.tlog.context.TLogContext).getTraceId()}".equals(logId)) {
            return IdGenerator.generate();
        }
        return logId;
    }
}
