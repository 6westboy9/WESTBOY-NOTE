package com.lachesis.lachesislog.starter.context.domain;

import cn.hutool.core.collection.CollUtil;
import com.lachesis.lachesislog.transport.LachesisDataOpExitLog;
import com.lachesis.lachesislog.transport.LachesisDataOpExitLogRecord;
import com.lachesis.lachesislog.transport.OpType;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.*;
import java.util.stream.Collectors;

@Data
@EqualsAndHashCode(callSuper = true)
public class DataOpExitLog extends AbstractLog {

    /**
     * 描述
     */
    private String opName;
    /**
     * 操作类型
     */
    private OpType opType;
    /**
     * 唯一标识
     */
    private String id;
    /**
     * 每次操作具体记录，单条和批量
     */
    private List<DataOpExitLogRecord> records;
    private String owner;

    public void addRecord(DataOpExitLogRecord record) {
        if (records == null) {
            records = new ArrayList<>();
        }
        records.add(record);
    }

    public LachesisDataOpExitLog transform() {
        LachesisDataOpExitLog dataOpExitLog = new LachesisDataOpExitLog();
        dataOpExitLog.setOpName(opName);
        dataOpExitLog.setOpType(opType);
        dataOpExitLog.setId(id);
        dataOpExitLog.setRecords(transformRecords());
        dataOpExitLog.setStartTime(startTime);
        dataOpExitLog.setEndTime(endTime);
        dataOpExitLog.setError(isError);
        if (throwable != null) {
            dataOpExitLog.setErrorMsg(throwable.getMessage());
        }
        dataOpExitLog.setOwner(owner);
        dataOpExitLog.setAttachments(attachments);
        return dataOpExitLog;
    }

    private List<LachesisDataOpExitLogRecord> transformRecords() {
        if (CollUtil.isNotEmpty(records)) {
            return records.stream().map(DataOpExitLogRecord::transform).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
