package com.lachesis.lachesislog.starter.metadata;

import com.lachesis.lachesislog.starter.annotation.LachesisCommonExitLog;
import lombok.Data;

@Data
public class CommonExitLogAnnoMetadata {
    /**
     * 操作名称
     */
    private String opName;
    /**
     * 操作内容
     */
    private String content;
    /**
     * 日志记录条件，为true时才会记录，否则，不会
     */
    private String condition;

    public static CommonExitLogAnnoMetadata ofLog(LachesisCommonExitLog commonExitLog) {
        CommonExitLogAnnoMetadata metadata = new CommonExitLogAnnoMetadata();
        metadata.setOpName(commonExitLog.opName());
        metadata.setContent(commonExitLog.content());
        metadata.setCondition(commonExitLog.condition());
        return metadata;
    }
}
