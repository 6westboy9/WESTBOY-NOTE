package com.lachesis.lachesislog.starter.function.parser;

import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.starter.context.MethodInvoker;
import com.lachesis.lachesislog.starter.function.LogCachedExpressionEvaluator;
import org.springframework.context.expression.AnnotatedElementKey;
import org.springframework.expression.EvaluationContext;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class AbstractLogParser implements ILogParser {

    private static final Pattern PATTERN = Pattern.compile("\\{(.*?)}");
    private final LogCachedExpressionEvaluator cachedExpressionEvaluator;
    private final AnnotatedElementKey elementKey;
    private final EvaluationContext evaluationContext;

    public AbstractLogParser(MethodInvoker methodInvoker) {
        this.cachedExpressionEvaluator = SpringUtil.getBean(LogCachedExpressionEvaluator.class);
        this.elementKey = methodInvoker.getElementKey();
        this.evaluationContext = cachedExpressionEvaluator.createEvaluationContext(methodInvoker);
    }

    @Override
    public String parseExpression(String template) {
        return parseExpression(template, false);
    }

    @Override
    public String parseExpression(String template, boolean toJsonStr) {
        if (StrUtil.isEmpty(template)) {
            return "";
        }
        Matcher matcher = PATTERN.matcher(template);
        while (matcher.find()) {
            String expTemplate = matcher.group(0);
            String exp = matcher.group(1);
            Object value = cachedExpressionEvaluator.parseExpression(exp, elementKey, evaluationContext);
            if (value != null) {
                String str = toJsonStr ? JSONUtil.toJsonStr(value) : String.valueOf(value);
                template = template.replace(expTemplate, str);
            } else {
                template = "";
            }
        }
        return template;
    }
}
