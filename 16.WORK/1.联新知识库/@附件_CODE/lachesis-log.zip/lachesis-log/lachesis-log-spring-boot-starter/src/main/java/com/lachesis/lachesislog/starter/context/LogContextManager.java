package com.lachesis.lachesislog.starter.context;

import com.alibaba.ttl.TransmittableThreadLocal;
import com.lachesis.lachesislog.starter.context.domain.CommonExitLog;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLog;
import com.lachesis.lachesislog.starter.context.domain.EntryLog;
import lombok.extern.slf4j.Slf4j;

import java.util.LinkedList;

@Slf4j
public class LogContextManager {

    private static final TransmittableThreadLocal<LogContext> CONTEXT = new TransmittableThreadLocal<>();

    /**
     * 面向业务方提供的设置module的工具方法，module的来源有两个：
     * <ol>
     *     <li>1.@LachesisEntryLog注解上</li>
     *     <li>1.业务代码中通过此方法设置（优先级最高）</li>
     * </ol>
     */
    public static void setModule(String module) {
        try {
            LogContext context = get();
            if (context != null) {
                context.setModule(module);
            }
        } catch (Exception e) {
            log.error("未知异常:module={}", module, e);
        }
    }

    /**
     * 向EntryLog附着数据
     * <p>
     * 面向业务方提供的附着数据的工具方法（附着数据内容以键值对的方式进行设置），其作用主要用于某些场景下框架处理的结果，不能满足业务需求时，业务端扩展使用
     *
     * @param k 附件标识
     * @param v 附件内容
     */
    public static void attachToEntryLog(String k, Object v) {
        try {
            EntryLog entryLog = getEntryLog();
            if (entryLog != null) {
                entryLog.attach(k, v);
            }
        } catch (Exception e) {
            log.error("未知异常:k={},v={}", k, v, e);
        }
    }

    /**
     * 向DataOpExitLog附着数据
     * <p>
     * 面向业务方提供的附着数据的工具方法（附着数据内容以键值对的方式进行设置），其作用主要用于某些场景下框架处理的结果，不能满足业务需求时，业务端扩展使用
     *
     * @param k 附件标识
     * @param v 附件内容
     */
    public static void attachToDataOpExitLog(String k, Object v) {
        try {
            DataOpExitLog dataOpExitLog = getDataOpExitLog();
            if (dataOpExitLog != null) {
                dataOpExitLog.attach(k, v);
            }
        } catch (Exception e) {
            log.error("未知异常:k={},v={}", k, v, e);
        }
    }

    /**
     * 向CommonExitLog附着数据
     * <p>
     * 面向业务方提供的附着数据的工具方法（附着数据内容以键值对的方式进行设置），其作用主要用于某些场景下框架处理的结果，不能满足业务需求时，业务端扩展使用
     *
     * @param k 附件标识
     * @param v 附件内容
     */
    public static void attachToCommonExitLog(String k, Object v) {
        try {
            CommonExitLog commonExitLog = getCommonExitLog();
            if (commonExitLog != null) {
                commonExitLog.attach(k, v);
            }
        } catch (Exception e) {
            log.error("未知异常:k={},v={}", k, v, e);
        }
    }

    /* ----------- 以下方法禁止框架外使用，所以访问修饰符为默认级别 ----------- */

    static EntryLog getEntryLog() {
        LogContext context = get();
        if (context == null) {
            return null;
        }
        return context.getEntryLog();
    }

    static LinkedList<DataOpExitLog> getDataOpExitLogs() {
        LogContext context = get();
        if (context != null) {
            return context.getDataOpExitLogs();
        }
        return null;
    }

    static LinkedList<CommonExitLog> getCommonExitLogs() {
        LogContext context = get();
        if (context != null) {
            return context.getCommonExitLogs();
        }
        return null;
    }

    static EntryLog createEntryLog() {
        LogContext context = getOrCreate();
        return context.createEntryLog();
    }

    static void stopEntryLog(EntryLog entity) {
        try {
            LogContext context = get();
            if (context != null) {
                context.stopEntryLog(entity);
            }
        } finally {
            remove();
        }
    }

    static DataOpExitLog createDataOpExitLog() {
        LogContext context = get();
        if (context != null) {
            return context.createDataOpExitLog();
        }
        return null;
    }

    static DataOpExitLog getDataOpExitLog() {
        LogContext context = get();
        if (context != null) {
            return context.getDataOpExitLog();
        }
        return null;
    }

    static void stopDataOpExitLog(DataOpExitLog entity) {
        LogContext context = get();
        if (context != null) {
            context.stopDataOpExitLog(entity);
        }
    }

    static CommonExitLog createCommonExitLog() {
        LogContext context = get();
        if (context != null) {
            return context.createCommonExitLog();
        }
        return null;
    }

    static CommonExitLog getCommonExitLog() {
        LogContext context = get();
        if (context != null) {
            return context.getCommonExitLog();
        }
        return null;
    }

    static void stopCommonExitLot(CommonExitLog entity) {
        LogContext context = get();
        if (context != null) {
            context.stopCommonExitLog(entity);
        }
    }

    private static LogContext getOrCreate() {
        LogContext context = CONTEXT.get();
        if (context == null) {
            context = new LogContext();
            CONTEXT.set(context);
        }
        return context;
    }

    private static LogContext get() {
        return CONTEXT.get();
    }

    private static void remove() {
        CONTEXT.remove();
    }
}
