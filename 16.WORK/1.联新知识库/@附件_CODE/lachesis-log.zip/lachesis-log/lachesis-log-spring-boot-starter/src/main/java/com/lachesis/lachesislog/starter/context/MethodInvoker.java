package com.lachesis.lachesislog.starter.context;

import com.lachesis.lachesislog.starter.annotation.LachesisCommonExitLog;
import com.lachesis.lachesislog.starter.annotation.LachesisDataOpExitLog;
import com.lachesis.lachesislog.starter.annotation.LachesisEntryLog;
import com.lachesis.lachesislog.starter.context.monitor.SimpleMonitor;
import com.lachesis.lachesislog.starter.metadata.CommonExitLogAnnoMetadata;
import com.lachesis.lachesislog.starter.metadata.DataOpExitLogAnnoMetadata;
import com.lachesis.lachesislog.starter.metadata.EntryLogAnnoMetadata;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.context.expression.AnnotatedElementKey;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

@Data
@Slf4j
public class MethodInvoker {

    private ProceedingJoinPoint joinPoint;
    private Object target;
    private Class<?> targetClass;
    private Method method;
    private Method targetMethod;
    private Object[] args;
    private Object result;
    private Throwable throwable;
    private InvokeInterceptor interceptor;
    private boolean success;
    private SimpleMonitor monitor;

    public static MethodInvoker newInstance(ProceedingJoinPoint joinPoint) {
        MethodInvoker methodInvoker = new MethodInvoker();
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();
        Object[] args = joinPoint.getArgs();
        Object target = joinPoint.getTarget();
        Class<?> targetClass = AopProxyUtils.ultimateTargetClass(target);
        Method targetMethod = Proxy.isProxyClass(targetClass) ? method : AopUtils.getMostSpecificMethod(method, targetClass);
        methodInvoker.setJoinPoint(joinPoint);
        methodInvoker.setTarget(target);
        methodInvoker.setArgs(args);
        methodInvoker.setTargetClass(targetClass);
        methodInvoker.setMethod(method);
        methodInvoker.setTargetMethod(targetMethod);
        methodInvoker.setSuccess(true);
        methodInvoker.setMonitor(new SimpleMonitor("性能指标简单统计"));
        methodInvoker.initInvokeInterceptor();
        return methodInvoker;
    }

    public AnnotatedElementKey getElementKey() {
        return new AnnotatedElementKey(method, targetClass);
    }

    public void preInvoke() {
        try {
            monitor.start(String.format("前置处理(%s)", interceptor.name()));
            interceptor.preInvoke();
        } catch (Exception exception) {
            log.error("操作日志前置处理未知异常", exception);
        } finally {
            monitor.stop();
        }
    }

    public Object doInvoke() {
        Object result = null;
        try {
            monitor.start(String.format("业务处理(%s)", interceptor.name()));
            result = joinPoint.proceed(args);
        } catch (Throwable e) {
            this.success = false;
            this.throwable = e;
        } finally {
            monitor.stop();
        }
        return result;
    }

    public void postInvoke() {
        try {
            monitor.start(String.format("后置处理(%s)", interceptor.name()));
            interceptor.postInvoke();
        } catch (Exception exception) {
            log.error("操作日志后置处理未知异常", exception);
        } finally {
            monitor.stop();
            monitor.print();
        }
    }

    private void initInvokeInterceptor() {
        LachesisEntryLog entryLog = getAnnotationsByType(LachesisEntryLog.class);
        if (entryLog != null) {
            interceptor = new EntryLogInvokeInterceptor(this, EntryLogAnnoMetadata.ofLog(entryLog));
        }
        LachesisCommonExitLog commonExitLog = getAnnotationsByType(LachesisCommonExitLog.class);
        if (commonExitLog != null) {
            interceptor = new CommonExitLogInvokeInterceptor(this, CommonExitLogAnnoMetadata.ofLog(commonExitLog));
        }
        LachesisDataOpExitLog dataOpExitLog = getAnnotationsByType(LachesisDataOpExitLog.class);
        if (dataOpExitLog != null) {
            interceptor = new DataOpExitLogInvokeInterceptor(this, DataOpExitLogAnnoMetadata.ofLog(dataOpExitLog));
        }
    }

    /**
     * 当前仅支持单个注解
     */
    private <T extends Annotation> T getAnnotationsByType(Class<T> annotationClass) {
        T[] annotations = method.getAnnotationsByType(annotationClass);
        if (annotations.length > 0) {
            return annotations[0];
        }
        return null;
    }
}
