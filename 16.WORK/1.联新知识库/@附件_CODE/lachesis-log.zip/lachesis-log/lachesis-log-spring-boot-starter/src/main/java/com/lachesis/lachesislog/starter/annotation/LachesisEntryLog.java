package com.lachesis.lachesislog.starter.annotation;

import com.lachesis.lachesislog.starter.visitor.DefaultEntryLogVisitor;
import com.lachesis.lachesislog.starter.visitor.IEntryLogVisitor;

import java.lang.annotation.*;

/**
 * 主要作用是操作日志采集的入口，日志的采集可以没有ExitLog，但是必须存在EntryLog
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface LachesisEntryLog {

    /**
     * 业务模块
     */
    String module() default "";
    /**
     * 操作名称，当前操作的简要描述
     */
    String opName();
    /**
     * 操作员
     */
    String operator() default "";
    /**
     * 操作内容
     */
    String content() default "";
    /**
     * 日志记录条件，为true时才会记录，否则，不会
     */
    String condition() default "true";
    /**
     * 当操作明细为空时是否进行处理，默认不做处理
     */
    boolean ignoreEmptyContent() default true;
    /**
     * 访问者模式，方便业务方对框架生成的最终输出前的结果进行加工处理
     */
    Class<? extends IEntryLogVisitor> visitor() default DefaultEntryLogVisitor.class;
    /**
     * 日志ID，用于串通一次操作的所有日志记录
     */
    String logId() default "";

}