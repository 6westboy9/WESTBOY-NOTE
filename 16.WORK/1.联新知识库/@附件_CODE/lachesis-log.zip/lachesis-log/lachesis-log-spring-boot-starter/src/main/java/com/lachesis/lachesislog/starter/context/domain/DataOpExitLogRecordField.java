package com.lachesis.lachesislog.starter.context.domain;

import com.lachesis.lachesislog.transport.LachesisDataOpExitLogRecordField;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class DataOpExitLogRecordField {
    /**
     * 属性名
     */
    private String name;
    /**
     * 旧的属性值
     */
    private Object before;
    /**
     * 新的属性值
     */
    private Object after;

    public LachesisDataOpExitLogRecordField transform() {
        LachesisDataOpExitLogRecordField field = new LachesisDataOpExitLogRecordField();
        field.setName(name);
        field.setBefore(before);
        field.setAfter(after);
        return field;
    }
}
