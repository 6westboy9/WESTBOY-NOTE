package com.lachesis.lachesislog.starter.util;

import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SpringHelper {

    public static <T> T getBeanElseNull(Class<T> clazz) {
        try {
            return SpringUtil.getBean(clazz);
        } catch (Exception e) {
            return null;
        }
    }

    public static <T> T getBeanElseNull(String name, Class<T> clazz) {
        if (StrUtil.isEmpty(name)) {
            return null;
        }
        try {
            return SpringUtil.getBean(name, clazz);
        } catch (Exception e) {
            return null;
        }
    }
}
