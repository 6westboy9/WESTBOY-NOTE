package com.lachesis.lachesislog.starter.context.domain;

import com.lachesis.lachesislog.transport.LachesisCommonExitLog;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CommonExitLog extends AbstractLog {

    /**
     * 操作名称
     */
    private String opName;
    /**
     * 操作内容
     */
    private String content;

    public LachesisCommonExitLog transform() {
        LachesisCommonExitLog commonExitLog = new LachesisCommonExitLog();
        commonExitLog.setOpName(opName);
        commonExitLog.setContent(content);
        commonExitLog.setStartTime(startTime);
        commonExitLog.setEndTime(endTime);
        commonExitLog.setError(isError);
        commonExitLog.setAttachments(attachments);
        if (throwable != null) {
            commonExitLog.setErrorMsg(throwable.getMessage());
        }
        return commonExitLog;
    }
}
