package com.lachesis.lachesislog.starter;

import org.apache.commons.lang3.builder.Diff;
import org.apache.commons.lang3.builder.DiffBuilder;
import org.apache.commons.lang3.builder.DiffResult;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class ObjectDiffTest {

    private Person person1;
    private Person person2;

    @Before
    public void before() {
        person1 = new Person("xw", 18, false);
        person2 = new Person("xh", 18, true);
    }

    @Test
    public void test() {
        DiffResult<?> diffResult = new DiffBuilder<>(person1, person2, ToStringStyle.SHORT_PREFIX_STYLE)
            .append("name", person1.getName(), person2.getName())
            .append("age", person1.getAge(), person2.getAge())
            .append("smoker", person1.isSmoker(), person2.isSmoker())
            .build();
        List<Diff<?>> diffs = diffResult.getDiffs();
        diffs.forEach(diff -> {
            String fieldName = diff.getFieldName();
            System.out.println(fieldName);
            String typeName = diff.getType().getTypeName();
            System.out.println(typeName);
            Object left = diff.getLeft();
            System.out.println(left);
            Object key = diff.getKey();
            System.out.println(key);
            Object value = diff.getValue();
            System.out.println(value);
            Object right = diff.getRight();
            System.out.println(right);
            System.out.println("-------");
        });
    }
}
