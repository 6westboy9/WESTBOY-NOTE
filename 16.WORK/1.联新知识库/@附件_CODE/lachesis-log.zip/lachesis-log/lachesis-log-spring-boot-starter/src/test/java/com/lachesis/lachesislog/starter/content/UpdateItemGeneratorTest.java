package com.lachesis.lachesislog.starter.content;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;
import com.lachesis.lachesislog.starter.generator.UpdateDataOpExitLogRecordGenerator;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class UpdateItemGeneratorTest {

    @Test
    public void getDiffField() {
        JSONObject oldData = mockOldData();
        JSONObject newData = mockNewData();
        List<String> excludeFields = new ArrayList<>();
        excludeFields.add("updateTime");
        UpdateDataOpExitLogRecordGenerator generator = new UpdateDataOpExitLogRecordGenerator("seqId", oldData, newData, excludeFields);
        DataOpExitLogRecord item = generator.generate();
        System.out.println(JSONUtil.toJsonPrettyStr(item));
    }

    private JSONObject mockOldData() {
        return JSONUtil.parseObj("{\n" +
            "    \"seqId\": 72,\n" +
            "    \"inhosCode\": \"22410518\",\n" +
            "    \"patCode\": \"1186512\",\n" +
            "    \"wardCode\": \"310\",\n" +
            "    \"headerCode\": \"H00709274\",\n" +
            "    \"documentCode\": \"D00757946\",\n" +
            "    \"templateCode\": \"T111115\",\n" +
            "    \"templateName\": \"护理记录单\",\n" +
            "    \"recordCode\": \"1720329489751347200-599086\",\n" +
            "    \"recordDate\": \"2023-11-03 14:35:00\",\n" +
            "    \"inoutCount\": null,\n" +
            "    \"countType\": null,\n" +
            "    \"crownSign\": null,\n" +
            "    \"crownSignTime\": null,\n" +
            "    \"createPerson\": \"123\",\n" +
            "    \"createTime\": \"2023-11-30 21:32:54\",\n" +
            "    \"updatePerson\": null,\n" +
            "    \"updateTime\": null,\n" +
            "    \"day\": null\n" +
            "}");

    }

    private JSONObject mockNewData() {
        return JSONUtil.parseObj("{\n" +
            "    \"seqId\": 72,\n" +
            "    \"inhosCode\": \"22410518\",\n" +
            "    \"patCode\": \"1186512\",\n" +
            "    \"wardCode\": \"310\",\n" +
            "    \"headerCode\": \"H00709275\",\n" +
            "    \"documentCode\": \"D00757946\",\n" +
            "    \"templateCode\": \"T111115\",\n" +
            "    \"templateName\": \"护理记录单\",\n" +
            "    \"recordCode\": \"1720329489751347200-599086\",\n" +
            "    \"recordDate\": \"2023-11-03 14:35:00\",\n" +
            "    \"inoutCount\": null,\n" +
            "    \"countType\": null,\n" +
            "    \"crownSign\": null,\n" +
            "    \"crownSignTime\": null,\n" +
            "    \"createPerson\": \"123\",\n" +
            "    \"createTime\": \"2023-11-30 21:32:54\",\n" +
            "    \"updatePerson\": null,\n" +
            "    \"updateTime\": null,\n" +
            "    \"day\": null\n" +
            "}");
    }
}