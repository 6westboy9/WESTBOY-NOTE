package com.lachesis.lachesislog.starter;

public class GenericTest {
    public static void main(String[] args) {
    }

}
