package com.lachesis.lachesislog.starter;

public class Person {

    private String name;
    private int age;
    private boolean smoker;

    public Person(String name, int age, boolean smoker) {
        this.name = name;
        this.age = age;
        this.smoker = smoker;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public boolean isSmoker() {
        return smoker;
    }
}
