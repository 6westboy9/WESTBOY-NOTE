
# 工作原理

## 日志采集流程图

![](doc/img/lachesislog操作日志存储过程.png)

[详细文档说明](http://10.2.3.159:8090/pages/viewpage.action?pageId=131760511)