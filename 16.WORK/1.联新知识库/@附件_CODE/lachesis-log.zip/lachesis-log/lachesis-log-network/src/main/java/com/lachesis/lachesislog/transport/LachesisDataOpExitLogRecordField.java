package com.lachesis.lachesislog.transport;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class LachesisDataOpExitLogRecordField {
    /**
     * 属性名
     */
    private String name;
    /**
     * 旧的属性值
     */
    private Object before;
    /**
     * 新的属性值
     */
    private Object after;

    public String convert2PrintableStr(OpType opType) {
        switch (opType) {
            case DELETE:
                return String.format("%s:%s", name, before);
            case UPDATE:
                return String.format("%s:%s->%s", name, before, after);
            case CREATE:
            case SELECT:
                return String.format("%s:%s", name, after);
            default:
                throw new IllegalStateException("暂不支持的操作类型");
        }
    }
}
