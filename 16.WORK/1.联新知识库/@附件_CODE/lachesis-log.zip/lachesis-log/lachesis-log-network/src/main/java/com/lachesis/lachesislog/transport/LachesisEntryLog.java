package com.lachesis.lachesislog.transport;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
public class LachesisEntryLog implements Serializable  {

    /**
     * 业务模块
     */
    private String module;
    /**
     * 描述
     */
    private String opName;
    /**
     * 操作员
     */
    private String operator;
    /**
     * 操作内容（可选）
     */
    private String content;
    /**
     * 开始时间
     */
    protected long startTime;
    /**
     * 结束时间
     */
    protected long endTime;
    /**
     * 执行是否发生错误
     */
    protected boolean isError;
    /**
     * 异常信息
     */
    protected String errorMsg;
    /**
     * 业务扩展字段
     */
    private JSONObject attachments;
    private String logId;

    public List<String> printableStrList() {
        ArrayList<String> list = CollUtil.newArrayList(
            String.format("%s [操作日志] module:%s | opName:%s | operator:%s | startTime:%s | endTime:%s | consume:%sms | isError:%s",
                LachesisLogConstant.LOG_PREF, module, opName, operator, startTime, endTime, (endTime - startTime), isError));
        if (StrUtil.isNotEmpty(content)) {
            list.add(String.format("%s [操作日志] content:%s", LachesisLogConstant.LOG_PREF, content));
        }
        return list;
    }

}
