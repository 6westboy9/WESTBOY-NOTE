package com.lachesis.lachesislog.transport;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import lombok.Data;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;

@Data
public class LachesisLogMessage implements Serializable {

    private String logId;
    private Long sendTime;
    private String app;
    /**
     * 业务模块
     */
    private String module;
    /**
     * 描述
     */
    private String opName;
    /**
     * 操作员
     */
    private String operator;
    /**
     * 操作内容（可选）
     */
    private String content;
    /**
     * 开始时间
     */
    private Long startTime;
    /**
     * 结束时间
     */
    private Long endTime;
    /**
     * 执行是否发生错误
     */
    private Boolean isError;
    /**
     * 异常信息
     */
    private String errorMsg;
    /**
     * 业务扩展字段
     */
    private JSONObject attachments;

    public static LachesisLogMessage parse(String messageStr) {
        return JSONUtil.toBean(messageStr, LachesisLogMessage.class);
    }

    public String toJSONStr() {
        return JSONUtil.toJsonStr(this);
    }

    public byte[] toBytes() {
        return toJSONStr().getBytes(StandardCharsets.UTF_8);
    }

}
