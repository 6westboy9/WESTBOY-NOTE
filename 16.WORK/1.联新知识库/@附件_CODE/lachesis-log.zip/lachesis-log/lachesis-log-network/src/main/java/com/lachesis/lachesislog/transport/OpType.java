package com.lachesis.lachesislog.transport;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum OpType {

    CREATE(1, "新增"),
    DELETE(2, "删除"),
    UPDATE(3, "更新"),
    SELECT(4, "查询"),
    ;

    private final int id;
    private final String desc;

    public String toStr() {
        return String.format("%s[%s]", name(), desc);
    }
}
