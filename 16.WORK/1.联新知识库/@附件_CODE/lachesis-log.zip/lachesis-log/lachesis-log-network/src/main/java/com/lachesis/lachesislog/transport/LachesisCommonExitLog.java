package com.lachesis.lachesislog.transport;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class LachesisCommonExitLog implements Serializable {
    /**
     * 操作名称
     */
    private String opName;
    /**
     * 操作内容
     */
    private String content;
    /**
     * 开始时间
     */
    protected long startTime;
    /**
     * 结束时间
     */
    protected long endTime;
    /**
     * 执行是否发生错误
     */
    protected boolean isError;
    /**
     * 异常信息
     */
    protected String errorMsg;
    /**
     * 业务扩展字段
     */
    private JSONObject attachments;

    public List<String> printableStrList() {
        return CollUtil.newArrayList(
            String.format("opName:%s | startTime:%s | endTime:%s | consume:%sms | isError:%s",
                opName, startTime, endTime, (endTime - startTime), isError),
            String.format("content:%s", content)
        );
    }
}
