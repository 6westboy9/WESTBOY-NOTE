package com.lachesis.lachesislog.transport;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class LachesisLogVector implements Serializable {
    private LachesisEntryLog entryLog;
    private List<LachesisDataOpExitLog> dataOpExitLogs;
    private List<LachesisCommonExitLog> commonExitLogs;
}
