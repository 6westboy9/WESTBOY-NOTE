package com.lachesis.lachesislog.transport;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONObject;
import lombok.Data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Data
public class LachesisDataOpExitLogRecord {

    private OpType opType;
    private String id;
    private String pValue;
    private List<LachesisDataOpExitLogRecordField> fields;
    private JSONObject attachments;

    public List<String> printableStrList() {
        if (CollUtil.isEmpty(fields)) {
            return Collections.emptyList();
        }
        List<String> fieldPrintableStrList = new ArrayList<>();
        for (LachesisDataOpExitLogRecordField field : fields) {
            fieldPrintableStrList.add(field.convert2PrintableStr(opType));
        }
        return CollUtil.newArrayList(
            String.format("%s [%s:%s] fields:%s", LachesisLogConstant.LOG_PREF, opType.toStr(), pValue, fieldPrintableStrList)
        );
    }
}
