package com.lachesis.lachesislog.transport;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Data
public class LachesisDataOpExitLog implements Serializable {
    /**
     * 描述
     */
    private String opName;
    /**
     * 操作类型
     */
    private OpType opType;
    /**
     * 唯一标识
     */
    private String id;
    /**
     * 每次操作具体记录，单条和批量
     */
    private List<LachesisDataOpExitLogRecord> records;
    /**
     * 开始时间
     */
    protected long startTime;
    /**
     * 结束时间
     */
    protected long endTime;
    /**
     * 执行是否发生错误
     */
    protected boolean isError;
    /**
     * 异常信息
     */
    protected String errorMsg;
    private String owner;
    /**
     * 业务扩展字段
     */
    private JSONObject attachments;

    public List<String> printableStrList(int i) {
        if (CollUtil.isEmpty(records)) {
            return Collections.emptyList();
        }
        List<String> list = CollUtil.newArrayList(
            String.format("%s [操作明细[%s]] opName:%s | startTime:%s | endTime:%s | consume:%sms | isError:%s | primaryFieldName:%s",
                LachesisLogConstant.LOG_PREF, i, opName, startTime, endTime, (endTime - startTime), isError, id));
        list.addAll(printableRecords(records));
        return list;
    }

    private List<String> printableRecords(List<LachesisDataOpExitLogRecord> records) {
        List<String> printableRecords = new ArrayList<>();
        if (CollUtil.isNotEmpty(records)) {
            for (int i = 1; i <= records.size(); i++) {
                LachesisDataOpExitLogRecord record = records.get(i - 1);
                List<String> list = record.printableStrList();
                if (CollUtil.isNotEmpty(list)) {
                    printableRecords.addAll(list);
                }
            }
        }
        return printableRecords;
    }
}
