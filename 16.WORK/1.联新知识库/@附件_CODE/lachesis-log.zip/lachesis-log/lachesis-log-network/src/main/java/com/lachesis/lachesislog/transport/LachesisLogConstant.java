package com.lachesis.lachesislog.transport;

public class LachesisLogConstant {
    public static final String LOG_PREF = "===>";
}
