package com.lachesis.lachesislog.example.service;

public interface IDemoService {

    void test2();
}
