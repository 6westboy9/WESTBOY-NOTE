package com.lachesis.lachesislog.example.support;

import com.lachesis.lachesislog.starter.config.ILachesisLogCustomConfig;
import org.springframework.stereotype.Component;

@Component
public class LachesisLogCustomConfig implements ILachesisLogCustomConfig {

    @Override
    public boolean isEnable() {
        return true;
    }

    @Override
    public boolean logEnable() {
        return true;
    }

    @Override
    public boolean monitorEnable() {
        return true;
    }
}
