package com.lachesis.lachesislog.example.service;


import com.lachesis.lachesislog.example.model.DocDataNurseRecord;

import java.util.List;

public interface IDocDataNurseRecordService {

    DocDataNurseRecord get(Long seqId);

    DocDataNurseRecord add(DocDataNurseRecord record);

    List<DocDataNurseRecord> addBatch(List<DocDataNurseRecord> records);

    DocDataNurseRecord update(DocDataNurseRecord record);

    boolean delete(Long seqId);
}
