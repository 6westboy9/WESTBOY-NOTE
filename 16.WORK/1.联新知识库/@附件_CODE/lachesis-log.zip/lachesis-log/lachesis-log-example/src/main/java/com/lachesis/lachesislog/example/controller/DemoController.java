package com.lachesis.lachesislog.example.controller;

import com.lachesis.lachesislog.example.service.IDemoService;
import com.lachesis.lachesislog.starter.annotation.LachesisEntryLog;
import com.lachesis.molecule.common.request.ResultMessage;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("/demo")
public class DemoController {

    private final IDemoService demoService;

    @LachesisEntryLog(module = "测试",
        opName = "测试仅有LachesisEntryLog时",
        operator = "测试员",
        logId = "1111111111111111",
        content = "测试操作内容")
    @GetMapping("/test01")
    public ResultMessage<String> test01() {
        return ResultMessage.success("hello");
    }

    @LachesisEntryLog(module = "测试2",
        opName = "更新数据",
        operator = "测试员",
        logId = "1111111111111111",
        content = "测试更新数据")
    @GetMapping("/test02")
    public ResultMessage<String> test02() {
        demoService.test2();
        return ResultMessage.success("hello");
    }

}
