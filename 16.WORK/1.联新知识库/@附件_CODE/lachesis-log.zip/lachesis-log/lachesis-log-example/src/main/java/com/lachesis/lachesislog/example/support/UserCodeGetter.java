package com.lachesis.lachesislog.example.support;

import org.springframework.stereotype.Component;

@Component
public class UserCodeGetter {

    public String getUserCode() {
        return "uid";
    }
}
