package com.lachesis.lachesislog.example.support;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.starter.visitor.IEntryLogVisitor;
import com.lachesis.lachesislog.starter.context.domain.DataOpExitLogRecord;
import com.lachesis.lachesislog.transport.LachesisLogVector;
import com.lachesis.lachesislog.transport.OpType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class AttachPatInfoEntryLogVisitor implements IEntryLogVisitor {

    public JSONObject getPatInfo(String inhosCode) {
        JSONObject object = new JSONObject();
        object.set("inhosCode", inhosCode);
        object.set("patName", "庞小萍");
        object.set("bedCode", "21201");
        log.info("查询患者信息:{}", JSONUtil.toJsonStr(object));
        return object;
    }

    public List<JSONObject> getPatInfos(List<String> inhosCodes) {
        List<JSONObject> list = new ArrayList<>();
        inhosCodes.forEach(inhosCode -> {
            JSONObject object = new JSONObject();
            object.set("inhosCode", inhosCode);
            object.set("patName", "庞小萍");
            object.set("bedCode", "21201");
            String jsonStr = JSONUtil.toJsonStr(object);
            log.info("查询患者信息:{}", jsonStr);
            list.add(object);
        });
        return list;
    }

    @Override
    public void visitVector(LachesisLogVector vector) {

    }
}
