package com.lachesis.lachesislog.example;

import com.baomidou.mybatisplus.autoconfigure.MybatisPlusAutoConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;

@MapperScan(basePackages = {"com.lachesis.lachesislog.example.dao"})
@SpringBootApplication(exclude = {MybatisPlusAutoConfiguration.class, MongoAutoConfiguration.class,
    MongoDataAutoConfiguration.class, FlywayAutoConfiguration.class})
public class LachesisLogExampleApplication {
    public static void main(String[] args) {
        SpringApplication.run(LachesisLogExampleApplication.class);
    }
}
