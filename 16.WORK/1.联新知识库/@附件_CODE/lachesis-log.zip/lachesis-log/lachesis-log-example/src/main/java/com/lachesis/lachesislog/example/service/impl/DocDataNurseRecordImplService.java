package com.lachesis.lachesislog.example.service.impl;

import com.lachesis.lachesislog.example.dao.DocDataNurseRecordMapper;
import com.lachesis.lachesislog.example.model.DocDataNurseRecord;
import com.lachesis.lachesislog.example.service.IDocDataNurseRecordService;
import com.lachesis.lachesislog.starter.context.LogContextManager;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@AllArgsConstructor
public class DocDataNurseRecordImplService implements IDocDataNurseRecordService {

    private final DocDataNurseRecordMapper docDataNurseRecordMapper;

    @Override
    public DocDataNurseRecord get(Long seqId) {
        return docDataNurseRecordMapper.selectByPrimaryKey(seqId);
    }

    @Override
    public DocDataNurseRecord add(DocDataNurseRecord record) {
        record.setCreateTime(new Date());
        record.setCreatePerson("123");
        LogContextManager.attachToEntryLog("patName", "哈哈哈");
        docDataNurseRecordMapper.insertAndReturnKey(record);
        return record;
    }

    @Override
    public List<DocDataNurseRecord> addBatch(List<DocDataNurseRecord> records) {
        records.forEach(record -> {
            record.setCreateTime(new Date());
            record.setCreatePerson("123");
        });
        LogContextManager.attachToEntryLog("patName", "哈哈哈");
        docDataNurseRecordMapper.insertBatchAndReturnKey(records);
        return records;
    }

    @Override
    public DocDataNurseRecord update(DocDataNurseRecord record) {
        LogContextManager.attachToEntryLog("patName", "哈哈哈");
        docDataNurseRecordMapper.updateByPrimaryKey(record);
        return record;
    }

    @Override
    public boolean delete(Long seqId) {
        LogContextManager.attachToEntryLog("patName", "哈哈哈");
        return docDataNurseRecordMapper.deleteByPrimaryKey(seqId) > 0;
    }
}
