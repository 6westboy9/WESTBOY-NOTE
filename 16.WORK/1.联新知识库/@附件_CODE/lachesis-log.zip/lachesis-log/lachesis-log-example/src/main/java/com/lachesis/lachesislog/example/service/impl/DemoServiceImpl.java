package com.lachesis.lachesislog.example.service.impl;

import com.lachesis.lachesislog.example.service.IDemoService;
import com.lachesis.lachesislog.starter.annotation.LachesisDataOpExitLog;
import com.lachesis.lachesislog.transport.OpType;
import org.springframework.stereotype.Service;

@Service
public class DemoServiceImpl implements IDemoService {

    @LachesisDataOpExitLog(opName = "更新数据",
        opType = OpType.UPDATE,
        id = "id",
        before = "更新前的测试数据",
        after = "更新后的测试数据",
        owner = "table_demo")
    @Override
    public void test2() {
        System.out.println("test2");
    }
}
