package com.lachesis.lachesislog.example.dao;

import com.lachesis.lachesislog.example.model.DocDataNurseRecord;
import com.lachesis.lachesislog.transport.OpType;
import com.lachesis.molecule.common.model.ICrudGenericDAO;
import com.lachesis.lachesislog.starter.annotation.LachesisDataOpExitLog;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public interface DocDataNurseRecordMapper extends ICrudGenericDAO<Long, DocDataNurseRecord> {

    List<DocDataNurseRecord> selectBySeqIds(Collection<Long> seqIds);

    default List<DocDataNurseRecord> select(List<? extends DocDataNurseRecord> list) {
        List<Long> seqIds = list.stream().map(DocDataNurseRecord::getSeqId).collect(Collectors.toList());
        return selectBySeqIds(seqIds);
    }

    /**
     * 注意使用接口时不好根据参数名称获取参数信息，可以直接通过参数顺序获取具体参数信息
     */
    @LachesisDataOpExitLog(opName = "新增护理计划单主表信息",
        opType = OpType.CREATE,
        id = "seqId",
        after = "{#a0}",
        owner = "doc_data_nurse_record")
    Long insertAndReturnKey(DocDataNurseRecord record);

    @LachesisDataOpExitLog(opName = "批量新增护理计划单主表信息",
        opType = OpType.CREATE,
        id = "seqId",
        after = "{#a0}",
        owner = "doc_data_nurse_record")
    void insertBatchAndReturnKey(@Param("list") List<? extends DocDataNurseRecord> list);

    @LachesisDataOpExitLog(opName = "修改护理计划单主表信息",
        opType = OpType.UPDATE,
        id = "seqId",
        condition = "{(#a0 != null && #a0.seqId != null)}",
        before = "{selectByPrimaryKey(#a0.seqId)}",
        after = "{#a0}",
        owner = "doc_data_nurse_record")
    int updateByPrimaryKey(DocDataNurseRecord record);

    @LachesisDataOpExitLog(opName = "删除护理计划单主表信息",
        opType = OpType.DELETE,
        id = "seqId",
        before = "{selectByPrimaryKey(#a0)}",
        owner = "doc_data_nurse_record")
    int deleteByPrimaryKey(Long seqId);

}