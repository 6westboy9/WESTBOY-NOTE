package com.lachesis.lachesislog.example.model;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.lachesis.molecule.common.model.ValuedBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

public class DocDataNurseRecord extends ValuedBean<Long> {
    @ApiModelProperty(name = "seqId", value = "自增长流水号")
    private Long seqId;

    @ApiModelProperty(name = "inhosCode", value = "患者住院流水号")
    private String inhosCode;

    @ApiModelProperty(name = "patCode", value = "患者住院号")
    private String patCode;

    @ApiModelProperty(name = "wardCode", value = "病区编号")
    private String wardCode;

    @ApiModelProperty(name = "headerCode", value = "表头编号")
    private String headerCode;

    @ApiModelProperty(name = "documentCode", value = "单据编号")
    private String documentCode;

    @ApiModelProperty(name = "templateCode", value = "模板编号")
    private String templateCode;

    @ApiModelProperty(name = "templateName", value = "模板名称")
    private String templateName;

    @ApiModelProperty(name = "recordCode", value = "数据编号")
    private String recordCode;

    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @ApiModelProperty(name = "recordDate", value = "记录时间", example = "2017-01-16 15:30:19")
    private Date recordDate;

    @ApiModelProperty(name = "inoutCount", value = "是否为出入量统计 0 否  1 是")
    private Integer inoutCount;

    @ApiModelProperty(name = "countType", value = "出入量统计类型")
    private String countType;

    @ApiModelProperty(name = "crownSign", value = "冠签")
    private String crownSign;

    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @ApiModelProperty(name = "crownSignTime", value = "冠签时间", example = "2017-01-16 15:30:19")
    private Date crownSignTime;

    @ApiModelProperty(name = "createPerson", value = "创建人")
    private String createPerson;

    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    @ApiModelProperty(name = "createTime", value = "创建时间", example = "2017-01-16T15:30:19.000+0800")
    private Date createTime;

    @ApiModelProperty(name = "updatePerson", value = "修改人")
    private String updatePerson;

    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    @ApiModelProperty(name = "updateTime", value = "修改时间", example = "2017-01-16T15:30:19.000+0800")
    private Date updateTime;

    @ApiModelProperty(name = "day", value = "")
    private String day;

    public Long getSeqId() {
        return seqId;
    }

    public void setSeqId(Long seqId) {
        this.seqId = seqId;
    }

    public String getInhosCode() {
        return inhosCode;
    }

    public void setInhosCode(String inhosCode) {
        this.inhosCode = inhosCode == null ? null : inhosCode.trim();
    }

    public String getPatCode() {
        return patCode;
    }

    public void setPatCode(String patCode) {
        this.patCode = patCode == null ? null : patCode.trim();
    }

    public String getWardCode() {
        return wardCode;
    }

    public void setWardCode(String wardCode) {
        this.wardCode = wardCode == null ? null : wardCode.trim();
    }

    public String getHeaderCode() {
        return headerCode;
    }

    public void setHeaderCode(String headerCode) {
        this.headerCode = headerCode == null ? null : headerCode.trim();
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode == null ? null : documentCode.trim();
    }

    public String getTemplateCode() {
        return templateCode;
    }

    public void setTemplateCode(String templateCode) {
        this.templateCode = templateCode == null ? null : templateCode.trim();
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName == null ? null : templateName.trim();
    }

    public String getRecordCode() {
        return recordCode;
    }

    public void setRecordCode(String recordCode) {
        this.recordCode = recordCode == null ? null : recordCode.trim();
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    public Integer getInoutCount() {
        return inoutCount;
    }

    public void setInoutCount(Integer inoutCount) {
        this.inoutCount = inoutCount;
    }

    public String getCountType() {
        return countType;
    }

    public void setCountType(String countType) {
        this.countType = countType == null ? null : countType.trim();
    }

    public String getCrownSign() {
        return crownSign;
    }

    public void setCrownSign(String crownSign) {
        this.crownSign = crownSign == null ? null : crownSign.trim();
    }

    public Date getCrownSignTime() {
        return crownSignTime;
    }

    public void setCrownSignTime(Date crownSignTime) {
        this.crownSignTime = crownSignTime;
    }

    public String getCreatePerson() {
        return createPerson;
    }

    public void setCreatePerson(String createPerson) {
        this.createPerson = createPerson == null ? null : createPerson.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdatePerson() {
        return updatePerson;
    }

    public void setUpdatePerson(String updatePerson) {
        this.updatePerson = updatePerson == null ? null : updatePerson.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day == null ? null : day.trim();
    }

    @Override
    public Long getPrimaryKey() {
        return this.getSeqId();
    }

    @Override
    public void setPrimaryKey(Long primaryKey) {
        this.setSeqId(primaryKey);
    }
}