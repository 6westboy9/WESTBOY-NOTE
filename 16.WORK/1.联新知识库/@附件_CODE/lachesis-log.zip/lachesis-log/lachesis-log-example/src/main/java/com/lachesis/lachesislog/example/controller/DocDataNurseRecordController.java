package com.lachesis.lachesislog.example.controller;

import com.lachesis.lachesislog.example.model.DocDataNurseRecord;
import com.lachesis.lachesislog.example.service.IDocDataNurseRecordService;
import com.lachesis.lachesislog.starter.annotation.LachesisEntryLog;
import com.lachesis.molecule.common.request.ResultMessage;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/docDataNurseRecord")
public class DocDataNurseRecordController {

    private final IDocDataNurseRecordService docDataNurseRecordService;

    @GetMapping("/get/{seqId}")
    public ResultMessage<DocDataNurseRecord> get(@PathVariable("seqId") Long seqId) {
        DocDataNurseRecord result = docDataNurseRecordService.get(seqId);
        return ResultMessage.success(result);
    }

    @LachesisEntryLog(module = "护理计划单",
        opName = "新增护理计划单",
        operator = "{@userCodeGetter.getUserCode()}",
        logId = "{T(com.yomahub.tlog.context.TLogContext).getTraceId()}")
    @PostMapping("/add")
    public ResultMessage<DocDataNurseRecord> add(@RequestBody DocDataNurseRecord record) {
        DocDataNurseRecord result = docDataNurseRecordService.add(record);
        return ResultMessage.success(result);
    }

    @LachesisEntryLog(module = "护理计划单",
        opName = "批量新增护理计划单",
        operator = "{@userCodeGetter.getUserCode()}")
    @PostMapping("/addBatch")
    public ResultMessage<List<DocDataNurseRecord>> addBatch(@RequestBody List<DocDataNurseRecord> records) {
        List<DocDataNurseRecord> result = docDataNurseRecordService.addBatch(records);
        return ResultMessage.success(result);
    }

    @LachesisEntryLog(module = "护理计划单",
        opName = "更新护理计划单",
        operator = "{@userCodeGetter.getUserCode()}",
        logId = "{T(com.yomahub.tlog.context.TLogContext).getTraceId()}",
        content = "{T(cn.hutool.json.JSONUtil).toJsonStr(#a0)}")
    @PutMapping("/update")
    public ResultMessage<DocDataNurseRecord> update(@RequestBody DocDataNurseRecord record) {
        DocDataNurseRecord result = docDataNurseRecordService.update(record);
        return ResultMessage.success(result);
    }

    @LachesisEntryLog(module = "护理计划单",
        opName = "删除护理计划单",
        operator = "{@userCodeGetter.getUserCode()}")
    @DeleteMapping("/delete/{seqId}")
    public ResultMessage<Boolean> delete(@PathVariable("seqId") Long seqId) {
        boolean result = docDataNurseRecordService.delete(seqId);
        return ResultMessage.success(result);
    }
}
