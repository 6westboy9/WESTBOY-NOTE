package com.lachesis.lachesislog.example.dao;

import cn.hutool.core.date.DateUtil;
import com.lachesis.lachesislog.example.LachesisLogExampleApplication;
import com.lachesis.lachesislog.example.model.DocDataNurseRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = LachesisLogExampleApplication.class)
public class DocDataNurseRecordMapperTest {

    @Autowired
    private DocDataNurseRecordMapper docDataNurseRecordMapper;

    @Test
    public void testInsert() {
        DocDataNurseRecord record = new DocDataNurseRecord();
        record.setInhosCode("22410518");
        record.setPatCode("1186512");
        record.setWardCode("310");
        record.setHeaderCode("H00709274");
        record.setDocumentCode("D00757946");
        record.setTemplateCode("T111115");
        record.setTemplateName("护理记录单");
        record.setRecordCode("1720329489751347200-599086");
        record.setRecordDate(DateUtil.parse("2023-11-03 14:35:00"));
        record.setInoutCount(null);
        record.setCountType(null);
        record.setCrownSign(null);
        record.setCrownSignTime(null);
        record.setCreatePerson("123");
        record.setCreateTime(DateUtil.parse("2023-11-03 14:38:07"));
        record.setUpdatePerson(null);
        record.setUpdateTime(null);
        // docDataNurseRecordMapper.insert(record);
    }

}