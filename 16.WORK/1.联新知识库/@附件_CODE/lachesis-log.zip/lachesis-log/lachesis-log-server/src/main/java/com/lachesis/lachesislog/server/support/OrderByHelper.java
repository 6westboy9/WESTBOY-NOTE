package com.lachesis.lachesislog.server.support;


import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

/**
 * 排序工具类
 *
 * @param <T>
 */
public class OrderByHelper<T> {

    private final String orderBy;

    private OrderByHelper(String str) {
        this.orderBy = str;
    }

    public static <T> OrderByHelper<T> newInstance(String str) {
        return new OrderByHelper<>(str);
    }

    /**
     * 该方法作用是将原有框架中的排序字符串，例如："name.desc,start.asc"，经过分隔拆分处理，按照MyBatisPlus的规则设置到wrapper对象中去
     *
     * @param wrapper 设置
     */
    public void appendOrderBy(QueryWrapper<T> wrapper) {
        if (StrUtil.isBlank(orderBy)) {
            return;
        }
        String[] split = orderBy.split(",");
        if (ArrayUtil.isNotEmpty(split)) {
            for (String kv : split) {
                String[] pair = kv.split("\\.");
                if (ArrayUtil.isEmpty(pair) || pair.length != 2) {
                    throw new IllegalArgumentException("排序规则参数错误:" + orderBy);
                }
                String column = pair[0];
                String type = pair[1];
                if (StrUtil.isBlank(column)) {
                    throw new IllegalArgumentException("排序规则参数错误[字段名为空]:" + orderBy);
                }
                if (StrUtil.isBlank(type)) {
                    throw new IllegalArgumentException("排序规则参数错误[排序为空]:" + orderBy);
                }

                if (type.equalsIgnoreCase("desc")) {
                    // 需要转成下划线
                    wrapper.orderByDesc(StrUtil.toUnderlineCase(column));
                } else if (type.equalsIgnoreCase("asc")) {
                    // 需要转成下划线
                    wrapper.orderByAsc(StrUtil.toUnderlineCase(column));
                }
            }
        }
    }
}
