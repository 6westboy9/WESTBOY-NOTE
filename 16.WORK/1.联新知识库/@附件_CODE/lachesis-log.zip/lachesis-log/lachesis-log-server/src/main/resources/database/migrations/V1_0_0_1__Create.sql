/*
  20231208 王鹏博  操作日志服务脚本
*/

USE lachesis_log;

CREATE TABLE IF NOT EXISTS `entry_log` (
  `seq_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `log_id` varchar(100)  NOT NULL COMMENT '日志ID',
  `app` varchar(10)  NOT NULL DEFAULT '' COMMENT '应用',
  `module` varchar(50)  NOT NULL DEFAULT '' COMMENT '业务模块',
  `op_name` varchar(20)  NOT NULL COMMENT '操作名称',
  `operator` varchar(50)  NOT NULL COMMENT '操作员',
  `content` text  NOT NULL COMMENT '操作内容',
  `start_time` datetime NOT NULL COMMENT '操作开始时间',
  `end_time` datetime NOT NULL COMMENT '操作结束时间',
  `attachments` varchar(200)  NOT NULL DEFAULT '' COMMENT '附加信息',
  `is_error` tinyint(4) NOT NULL DEFAULT '0' COMMENT '操作是否报错 0.未报错 1.报错',
  `error_msg` varchar(200)  NOT NULL DEFAULT '' COMMENT '错误信息',
  `is_deleted` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除 0.未删除 1.已删除',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`seq_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作日志表';


