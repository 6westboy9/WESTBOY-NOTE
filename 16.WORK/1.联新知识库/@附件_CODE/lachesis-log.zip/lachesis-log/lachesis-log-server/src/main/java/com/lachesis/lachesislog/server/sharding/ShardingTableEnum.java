package com.lachesis.lachesislog.server.sharding;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;


/**
 * 分片表缓存枚举
 */
@Getter
@AllArgsConstructor
public enum ShardingTableEnum {

    ENTRY_LOG("entry_log", new HashSet<>());

    /**
     * 逻辑表名
     */
    private final String logicTableName;
    /**
     * 实际表名
     */
    private final Set<String> resultTableNames;

    private static final Map<String, ShardingTableEnum> MAP = new ConcurrentHashMap<>();

    static {
        Arrays.stream(ShardingTableEnum.values()).forEach(o -> MAP.put(o.logicTableName, o));
    }

    public static Set<String> logicTableNames() {
        return MAP.keySet();
    }

    public static ShardingTableEnum of(String value) {
        return MAP.get(value);
    }

    public synchronized void  refreshResultTableNames(List<String> tableNames) {
        resultTableNames.clear();
        resultTableNames.addAll(tableNames);
    }

    public synchronized void addResultTableName(String resultTableName) {
        resultTableNames.add(resultTableName);    
    }
}
