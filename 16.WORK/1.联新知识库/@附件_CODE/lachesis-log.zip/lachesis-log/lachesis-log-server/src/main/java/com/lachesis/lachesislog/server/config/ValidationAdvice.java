package com.lachesis.lachesislog.server.config;

import cn.hutool.core.collection.CollUtil;
import com.lachesis.lachesislog.common.Result;
import com.lachesis.lachesislog.common.ResultBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@RestControllerAdvice
public class ValidationAdvice {

    @ExceptionHandler(Exception.class)
    public Result<Void> handler(Exception e) {
        return ResultBuilder.fail("未知异常:" + e.getMessage());
    }

    @ExceptionHandler(value = {BindException.class})
    public Result<Void> handler(BindException e) {
        BindingResult bindingResult = e.getBindingResult();
        List<ObjectError> oel = bindingResult.getAllErrors();
        List<String> list = oel.stream()
            .map(DefaultMessageSourceResolvable::getDefaultMessage)
            .collect(Collectors.toList());
        String message = String.format("参数异常:%s", CollUtil.join(list, ";"));
        log.error("{}", message, e);
        return ResultBuilder.fail(message);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public Result<Void> handler(ConstraintViolationException e) {
        Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
        List<String> list = violations.stream()
            .map(ConstraintViolation::getMessage)
            .collect(Collectors.toList());
        String message = String.format("参数异常:%s", CollUtil.join(list, ";"));
        log.error("{}", message, e);
        return ResultBuilder.fail(message);
    }
}
