package com.lachesis.lachesislog.server.sharding;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.lachesis.lachesislog.server.dao.EntryLogMapper;
import com.lachesis.lachesislog.server.dao.entity.EntryLog;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 项目启动后，读取已有分表，进行缓存
 */
@Slf4j
@Order(value = 1) // 数字越小，越先执行
@Component
@Setter(onMethod = @__(@Autowired))
public class ShardingTablesLoadRunner implements CommandLineRunner {

    private EntryLogMapper entryLogMapper;

    @Override
    public void run(String... args) {
        // 读取已有分表进行缓存
        QueryWrapper<EntryLog> wrapper = new QueryWrapper<>();
        // 需要使用分片键
        wrapper.eq("create_time", LocalDateTime.now());
        wrapper.last("limit 1");
        entryLogMapper.selectOne(wrapper);

        for (ShardingTableEnum shardingTableEnum : ShardingTableEnum.values()) {
            List<String> allTableNames = ShardingUtil.getAllTableNames(shardingTableEnum.getLogicTableName());
            shardingTableEnum.refreshResultTableNames(allTableNames);
            log.info("缓存已有分表成功:logicTableName={}|resultTableNames={}",
                shardingTableEnum.getLogicTableName(),
                shardingTableEnum.getResultTableNames());
        }
    }
}
