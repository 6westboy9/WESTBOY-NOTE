package com.lachesis.lachesislog.server.mq;

import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.server.constant.RabbitConstant;
import com.lachesis.lachesislog.server.dto.EntryLogSaveDTO;
import com.lachesis.lachesislog.server.service.ILogService;
import com.lachesis.lachesislog.transport.LachesisLogMessage;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Setter(onMethod = @__(@Autowired))
public class LachesisLogConsumer {

    private ILogService logService;

    // 先写死，后续优化
    @RabbitHandler
    @RabbitListener(queues = {RabbitConstant.QUEUE})
    public void onMessage(@Payload String messageStr) {
        log.info("日志消息内容:{}", JSONUtil.toJsonStr(messageStr));
        LachesisLogMessage message = LachesisLogMessage.parse(messageStr);
        EntryLogSaveDTO saveDTO = newLogSaveDTO(message);
        boolean ok = logService.save(saveDTO);
        if (!ok) {
            log.error("保存日志消息失败:{}", JSONUtil.toJsonStr(saveDTO));
        }
    }

    private EntryLogSaveDTO newLogSaveDTO(LachesisLogMessage message) {
        EntryLogSaveDTO saveDTO = new EntryLogSaveDTO();
        saveDTO.setLogId(message.getLogId());
        saveDTO.setApp(message.getApp());
        saveDTO.setModule(message.getModule());
        saveDTO.setOpName(message.getOpName());
        saveDTO.setOperator(message.getOperator());
        saveDTO.setContent(message.getContent());
        saveDTO.setStartTime(LocalDateTimeUtil.of(message.getStartTime()));
        saveDTO.setEndTime(LocalDateTimeUtil.of(message.getEndTime()));
        saveDTO.setIsError(message.getIsError());
        saveDTO.setErrorMsg(message.getErrorMsg());
        saveDTO.setCreateTime(LocalDateTimeUtil.now());
        saveDTO.setUpdateTime(saveDTO.getCreateTime());
        saveDTO.setAttachments(JSONUtil.toJsonStr(message.getAttachments()));
        return saveDTO;
    }
}
