package com.lachesis.lachesislog.server.sharding;

import cn.hutool.extra.spring.SpringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 按月分片算法工具
 */
@Slf4j
public class ShardingUtil {

    /**
     * 表分片符号，例：entry_log_202401中，分片符号为 "_"
     */
    private static final String TABLE_SPLIT_SYMBOL = "_";

    /**
     * 数据库配置
     */
    private static final Environment ENV;
    private static final String DATASOURCE_URL;
    private static final String DATASOURCE_USERNAME;
    private static final String DATASOURCE_PASSWORD;

    static {
        ENV = SpringUtil.getApplicationContext().getEnvironment();
        DATASOURCE_URL = ENV.getProperty("my.sharding.create-table.url");
        DATASOURCE_USERNAME = ENV.getProperty("my.sharding.create-table.username");
        DATASOURCE_PASSWORD = ENV.getProperty("my.sharding.create-table.password");
    }

    /**
     * 创建分表
     *
     * @param logicTableName  逻辑表
     * @param resultTableName 真实表名，例：entry_log_202401
     */
    public static synchronized void createShardingTable(String logicTableName, String resultTableName) {
        log.info("创建表开始:{}", resultTableName);
        executeSql(Collections.singletonList("CREATE TABLE IF NOT EXISTS `" + resultTableName + "` LIKE `" + logicTableName + "`;"));
        log.info("创建表完成");
    }

    /**
     * 获取所有表名
     */
    public static synchronized List<String> getAllTableNames(String logicTableName) {
        List<String> tableNames = new ArrayList<>();
        if (StringUtils.isEmpty(DATASOURCE_URL) || StringUtils.isEmpty(DATASOURCE_USERNAME) || StringUtils.isEmpty(DATASOURCE_PASSWORD)) {
            log.error("数据库连接配置有误:URL={}|username={}|password={}", DATASOURCE_URL, DATASOURCE_USERNAME, DATASOURCE_PASSWORD);
            throw new IllegalArgumentException("数据库连接配置有误");
        }
        try (Connection conn = DriverManager.getConnection(DATASOURCE_URL, DATASOURCE_USERNAME, DATASOURCE_PASSWORD);
             Statement st = conn.createStatement()) {
            try (ResultSet rs = st.executeQuery("SHOW TABLES LIKE '" + logicTableName + TABLE_SPLIT_SYMBOL + "%'")) {
                while (rs.next()) {
                    String tableName = rs.getString(1);
                    // 匹配分表格式 例：^(entry\_log_\d{6})$
                    if (tableName != null && tableName.matches(String.format("^(%s\\d{6})$", logicTableName + TABLE_SPLIT_SYMBOL))) {
                        tableNames.add(rs.getString(1));
                    }
                }
            }
        } catch (SQLException e) {
            log.error("数据库连接失败", e);
            throw new IllegalArgumentException("数据库连接失败");
        }
        return tableNames;
    }

    /**
     * 执行SQL
     */
    private static void executeSql(List<String> sqlList) {
        if (StringUtils.isEmpty(DATASOURCE_URL) || StringUtils.isEmpty(DATASOURCE_USERNAME) || StringUtils.isEmpty(DATASOURCE_PASSWORD)) {
            log.error("数据库连接配置有误:URL={}|username={}|password={}", DATASOURCE_URL, DATASOURCE_USERNAME, DATASOURCE_PASSWORD);
            throw new IllegalArgumentException("数据库连接配置有误");
        }

        try (Connection conn = DriverManager.getConnection(DATASOURCE_URL, DATASOURCE_USERNAME, DATASOURCE_PASSWORD)) {
            try (Statement st = conn.createStatement()) {
                conn.setAutoCommit(false);
                for (String sql : sqlList) {
                    st.execute(sql);
                }
            } catch (Exception e) {
                conn.rollback();
                log.error("数据表创建执行失败", e);
                throw new IllegalArgumentException("数据库连接失败");
            }
        } catch (SQLException e) {
            log.error("数据库连接失败", e);
            throw new IllegalArgumentException("数据库连接失败");
        }
    }
}
