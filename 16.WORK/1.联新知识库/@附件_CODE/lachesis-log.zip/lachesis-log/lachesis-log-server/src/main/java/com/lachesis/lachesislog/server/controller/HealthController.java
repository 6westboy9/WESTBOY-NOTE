package com.lachesis.lachesislog.server.controller;

import com.lachesis.lachesislog.common.Result;
import com.lachesis.lachesislog.common.ResultBuilder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@Api(tags = "基础模块")
@RestController
@RequestMapping("/health")
public class HealthController {

    @ApiOperation(value = "健康检查")
    @GetMapping("")
    public Result<Boolean> health() {
        return ResultBuilder.success(true);
    }
}
