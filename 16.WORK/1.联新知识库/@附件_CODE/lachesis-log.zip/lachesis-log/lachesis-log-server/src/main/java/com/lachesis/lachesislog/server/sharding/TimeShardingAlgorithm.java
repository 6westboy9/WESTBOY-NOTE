/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lachesis.lachesislog.server.sharding;

import com.google.common.collect.Range;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.shardingsphere.sharding.api.sharding.ShardingAutoTableAlgorithm;
import org.apache.shardingsphere.sharding.api.sharding.standard.PreciseShardingValue;
import org.apache.shardingsphere.sharding.api.sharding.standard.RangeShardingValue;
import org.apache.shardingsphere.sharding.api.sharding.standard.StandardShardingAlgorithm;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;

/**
 * 分片算法，按月分片
 */
@Slf4j
public final class TimeShardingAlgorithm implements StandardShardingAlgorithm<LocalDateTime>, ShardingAutoTableAlgorithm {

    /**
     * 分片时间格式
     */
    private static final DateTimeFormatter TABLE_SHARD_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMM");
    /**
     * 完整时间格式
     */
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss");
    /**
     * 表分片符号，例：entry_log_20231201 中，分片符号为 "_"
     */
    private final String TABLE_SPLIT_SYMBOL = "_";

    @Getter
    private Properties props;
    @Getter
    private int autoTablesAmount;

    @Override
    public void init(Properties props) {
        this.props = props;
    }

    @Override
    public String doSharding(Collection<String> availableTargetNames, PreciseShardingValue<LocalDateTime> preciseShardingValue) {
        String logicTableName = preciseShardingValue.getLogicTableName();
        ShardingTableEnum shardingTableEnum = ShardingTableEnum.of(logicTableName);
        LocalDateTime dateTime = preciseShardingValue.getValue();
        String resultTableName = logicTableName + "_" + dateTime.format(TABLE_SHARD_TIME_FORMATTER);

        // 没有测试分库，时间有限，优先保证分表正确
        Set<String> tableNames = shardingTableEnum.getResultTableNames();
        availableTargetNames.clear();
        availableTargetNames.addAll(tableNames);
        autoTablesAmount = tableNames.size();

        if (!availableTargetNames.contains(resultTableName)) {
            ShardingUtil.createShardingTable(logicTableName, resultTableName);
            availableTargetNames.add(resultTableName);
            shardingTableEnum.addResultTableName(resultTableName);
            autoTablesAmount++;
        }
        log.info("精确分片表名:{}", resultTableName);
        return resultTableName;
    }

    @Override
    public Collection<String> doSharding(Collection<String> availableTargetNames, RangeShardingValue<LocalDateTime> rangeShardingValue) {
        String logicTableName = rangeShardingValue.getLogicTableName();
        ShardingTableEnum shardingTableEnum = ShardingTableEnum.of(logicTableName);
        // 起始值
        Range<LocalDateTime> valueRange = rangeShardingValue.getValueRange();
        boolean hasLowerBound = valueRange.hasLowerBound();
        boolean hasUpperBound = valueRange.hasUpperBound();
        // 获取最大值和最小值
        LocalDateTime min = hasLowerBound ? valueRange.lowerEndpoint() : getLowerEndpoint(availableTargetNames);
        LocalDateTime max = hasUpperBound ? valueRange.upperEndpoint() : getUpperEndpoint(availableTargetNames);

        // 循环计算分表范围
        Set<String> resultTableNames = new LinkedHashSet<>();
        while (min.isBefore(max) || min.equals(max)) {
            String tableName = logicTableName + TABLE_SPLIT_SYMBOL + min.format(TABLE_SHARD_TIME_FORMATTER);
            resultTableNames.add(tableName);
            min = min.plusMinutes(1);
        }

        Set<String> tableNames = shardingTableEnum.getResultTableNames();
        availableTargetNames.clear();
        availableTargetNames.addAll(tableNames);
        autoTablesAmount = tableNames.size();

        resultTableNames.forEach(resultTableName -> {
            if (availableTargetNames.contains(resultTableName)) {
                return;
            }
            ShardingUtil.createShardingTable(logicTableName, resultTableName);
            availableTargetNames.add(resultTableName);
            shardingTableEnum.addResultTableName(resultTableName);
            autoTablesAmount++;
        });

        log.info("范围分片表名:{}", resultTableNames);
        return resultTableNames;
    }

    @Override
    public String getType() {
        return "AUTO_CUSTOM";
    }

    /**
     * 获取最小分片值
     *
     * @param tableNames 表名集合
     * @return 最小分片值
     */
    private LocalDateTime getLowerEndpoint(Collection<String> tableNames) {
        Optional<LocalDateTime> optional = tableNames.stream()
            .map(tableName -> LocalDateTime.parse(tableName.replace(TABLE_SPLIT_SYMBOL, "") + "01 00:00:00", DATE_TIME_FORMATTER))
            .min(Comparator.comparing(Function.identity()));
        if (optional.isPresent()) {
            return optional.get();
        } else {
            log.error("获取数据最小分表失败:tableNames={}", tableNames);
            throw new IllegalArgumentException("获取数据最小分表失败");
        }
    }

    /**
     * 获取 最大分片值
     *
     * @param tableNames 表名集合
     * @return 最大分片值
     */
    private LocalDateTime getUpperEndpoint(Collection<String> tableNames) {
        Optional<LocalDateTime> optional = tableNames.stream()
            .map(tableName -> LocalDateTime.parse(tableName.replace(TABLE_SPLIT_SYMBOL, "") + "01 00:00:00", DATE_TIME_FORMATTER))
            .max(Comparator.comparing(Function.identity()));
        if (optional.isPresent()) {
            return optional.get();
        } else {
            log.error("获取数据最大分表失败:tableNames={}", tableNames);
            throw new IllegalArgumentException("获取数据最大分表失败");
        }
    }
}
