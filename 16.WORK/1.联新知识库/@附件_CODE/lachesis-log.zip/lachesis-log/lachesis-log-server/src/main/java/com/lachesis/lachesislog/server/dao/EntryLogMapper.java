package com.lachesis.lachesislog.server.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lachesis.lachesislog.server.dao.entity.EntryLog;

public interface EntryLogMapper extends BaseMapper<EntryLog> {
}
