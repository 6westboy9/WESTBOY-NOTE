package com.lachesis.lachesislog.server.controller;

import com.lachesis.lachesislog.api.domain.EntryLogDTO;
import com.lachesis.lachesislog.api.domain.LogPageQuery;
import com.lachesis.lachesislog.common.PageEntity;
import com.lachesis.lachesislog.common.Result;
import com.lachesis.lachesislog.common.ResultBuilder;
import com.lachesis.lachesislog.server.service.ILogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@Api(tags = "日志模块")
@RestController
@RequestMapping("/logs")
@Setter(onMethod = @__(@Autowired))
public class LogController {

    private ILogService logService;

    @ApiOperation(value = "分页获取日志列表")
    @PostMapping("/getPage")
    public Result<PageEntity<EntryLogDTO>> getPage(@RequestBody LogPageQuery query) {
        return ResultBuilder.success(logService.getPage(query));
    }
}
