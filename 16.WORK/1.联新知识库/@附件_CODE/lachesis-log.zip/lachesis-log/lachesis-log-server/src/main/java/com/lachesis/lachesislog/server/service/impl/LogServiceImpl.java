package com.lachesis.lachesislog.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lachesis.lachesislog.api.domain.EntryLogDTO;
import com.lachesis.lachesislog.api.domain.LogAttachment;
import com.lachesis.lachesislog.api.domain.LogAttachmentPair;
import com.lachesis.lachesislog.api.domain.LogPageQuery;
import com.lachesis.lachesislog.common.PageEntity;
import com.lachesis.lachesislog.server.convertor.EntryLogConvertor;
import com.lachesis.lachesislog.server.dao.EntryLogMapper;
import com.lachesis.lachesislog.server.dao.entity.EntryLog;
import com.lachesis.lachesislog.server.dto.EntryLogSaveDTO;
import com.lachesis.lachesislog.server.service.ILogService;
import com.lachesis.lachesislog.server.support.OrderByHelper;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Slf4j
@Service
@Setter(onMethod = @__(@Autowired))
public class LogServiceImpl implements ILogService {

    private EntryLogMapper entryLogMapper;
    private EntryLogConvertor entryLogConvertor;

    @Override
    public PageEntity<EntryLogDTO> getPage(LogPageQuery query) {
        Page<EntryLog> pageRes = entryLogMapper.selectPage(newPage(query), newWrapper(query));
        List<EntryLogDTO> entryLogDTOs = entryLogConvertor.convertToDTO(pageRes.getRecords());
        return PageEntity.newInstance(pageRes.getTotal(), query.getPageSize(), query.getPageNo(), entryLogDTOs);
    }

    @Override
    public boolean save(EntryLogSaveDTO entryLogSaveDTO) {
        try {
            EntryLog entryLog = entryLogConvertor.convertFromSaveDTO(entryLogSaveDTO);
            return entryLogMapper.insert(entryLog) > 0;
        } catch (Exception e) {
            log.error("保存日志消息异常", e);
            return false;
        }
    }

    private Page<EntryLog> newPage(LogPageQuery query) {
        return new Page<>(query.getPageNo(), query.getPageSize());
    }

    private QueryWrapper<EntryLog> newWrapper(LogPageQuery query) {
        QueryWrapper<EntryLog> wrapper = new QueryWrapper<>();
        wrapper.and(queryWrapper -> {
            queryWrapper.ge(StrUtil.isNotBlank(query.getMinStartTime()), "start_time", query.getMinStartTime());
            queryWrapper.le(StrUtil.isNotBlank(query.getMaxStartTime()), "start_time", query.getMaxStartTime());
        });

        // 扯淡的多个查询，时间紧急，有问题后续再优化~
        Collection<String> operatorList = query.getOperatorList();
        if (CollUtil.isNotEmpty(operatorList)) {
            wrapper.and(queryWrapper -> {
                int i = 0;
                for (String operator : operatorList) {
                    if (i == 0) {
                        queryWrapper.like(StrUtil.isNotBlank(operator), "operator", operator);
                    } else {
                        queryWrapper.or().like(StrUtil.isNotBlank(operator), "operator", operator);
                    }
                    i++;
                }
            });
        }

        Collection<String> moduleList = query.getModuleList();
        if (CollUtil.isNotEmpty(moduleList)) {
            wrapper.and(queryWrapper -> {
                int i = 0;
                for (String module : moduleList) {
                    if (i == 0) {
                        queryWrapper.like(StrUtil.isNotBlank(module), "module", module);
                    } else {
                        queryWrapper.or().like(StrUtil.isNotBlank(module), "module", module);
                    }
                    i++;
                }
            });
        }

        List<LogAttachment> attachments = query.getAttachments();
        if (CollUtil.isNotEmpty(attachments)) {
            wrapper.and(queryWrapper -> {
                for (LogAttachment attachment : attachments) {
                    List<LogAttachmentPair> attachmentPairs = attachment.getAttachmentPairs();
                    queryWrapper.or(likeWrapper -> {
                        for (LogAttachmentPair attachmentPair : attachmentPairs) {
                            likeWrapper.like("attachments", attachmentPair.getSearchKey());
                        }
                    });
                }
            });
        }

        // 处理排序
        OrderByHelper<EntryLog> orderByHelper = OrderByHelper.newInstance(query.getOrderBy());
        orderByHelper.appendOrderBy(wrapper);
        return wrapper;
    }
}