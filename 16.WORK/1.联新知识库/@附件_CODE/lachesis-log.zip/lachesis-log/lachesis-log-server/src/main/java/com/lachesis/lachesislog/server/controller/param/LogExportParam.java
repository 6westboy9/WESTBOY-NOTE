package com.lachesis.lachesislog.server.controller.param;

import cn.hutool.core.date.DatePattern;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
@ApiModel("日志导出参数信息")
public class LogExportParam {
    @ApiModelProperty(name = "module", value = "文书模板名称")
    private String module;
    @NotNull(message = "日期不能为空")
    @ApiModelProperty(name = "date", value = "日期", example = "2023-12-06")
    @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN)
    private LocalDateTime date;
    @ApiModelProperty(name = "operator", value = "操作人")
    private String operator;
}
