package com.lachesis.lachesislog.server.constant;

public class RabbitConstant {
    public static final String EXCHANGE = "lc.lachesislog.log";
    public static final String QUEUE = "lc.lachesislog.log";
    public static final String ROUTING_KEY = "lc.lachesislog.log.*";
}
