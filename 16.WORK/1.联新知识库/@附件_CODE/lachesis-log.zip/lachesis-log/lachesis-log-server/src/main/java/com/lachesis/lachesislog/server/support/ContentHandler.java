package com.lachesis.lachesislog.server.support;

import cn.hutool.json.JSONUtil;
import com.lachesis.lachesislog.transport.LachesisLogVector;

public class ContentHandler {

    /**
     * 转换成数据库存储信息
     */
    public static String toJSONInfo(LachesisLogVector vector) {
        return JSONUtil.toJsonStr(vector);
    }

    public static LachesisLogVector toVector(String jsonStr) {
        return JSONUtil.toBean(jsonStr, LachesisLogVector.class);
    }
}
