package com.lachesis.lachesislog.server.support;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum OrderByType {
    DESC("desc"),
    ASC("asc");
    private final String name;
}
