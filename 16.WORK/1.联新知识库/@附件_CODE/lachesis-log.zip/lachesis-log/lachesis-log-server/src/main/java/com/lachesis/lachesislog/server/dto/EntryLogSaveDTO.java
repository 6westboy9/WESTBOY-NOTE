package com.lachesis.lachesislog.server.dto;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class EntryLogSaveDTO implements Serializable {
    private Long seqId;
    private String logId;
    private String app;
    private String module;
    private String opName;
    private String operator;
    private String content;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Boolean isError;
    private String errorMsg;
    private String attachments;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
