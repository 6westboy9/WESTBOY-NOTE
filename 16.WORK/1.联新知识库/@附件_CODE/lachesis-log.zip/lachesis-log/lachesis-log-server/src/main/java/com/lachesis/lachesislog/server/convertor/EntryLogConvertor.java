package com.lachesis.lachesislog.server.convertor;

import com.lachesis.lachesislog.api.domain.EntryLogDTO;
import com.lachesis.lachesislog.server.dao.entity.EntryLog;
import com.lachesis.lachesislog.server.dto.EntryLogSaveDTO;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface EntryLogConvertor {

    EntryLogSaveDTO convertToSaveDTO(EntryLog entryLog);

    EntryLog convertFromSaveDTO(EntryLogSaveDTO entryLogSaveDTO);

    EntryLogDTO convertToDTO(EntryLog entryLog);

    List<EntryLogDTO> convertToDTO(List<EntryLog> entryLog);

}
