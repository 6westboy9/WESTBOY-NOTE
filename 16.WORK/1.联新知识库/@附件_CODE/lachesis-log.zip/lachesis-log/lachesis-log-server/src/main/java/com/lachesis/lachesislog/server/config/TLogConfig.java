package com.lachesis.lachesislog.server.config;

import com.yomahub.tlog.core.aop.AspectLogAop;
import com.yomahub.tlog.web.TLogWebConfig;
import com.yomahub.tlog.web.interceptor.TLogWebInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

@Configuration
public class TLogConfig extends WebMvcConfig {

    @Bean(name = "tLogWebConfig")
    public TLogWebConfig getTLogWebConfig() {
        return new TLogWebConfig();
    }

    @Bean(name = "aspectLogAop")
    public AspectLogAop getAspectLogAop() {
        return new AspectLogAop();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        TLogWebInterceptor tLogWebInterceptor = new TLogWebInterceptor();
        registry.addInterceptor(tLogWebInterceptor);
        super.addInterceptors(registry);
    }
}