package com.lachesis.lachesislog.server.service;

import com.lachesis.lachesislog.api.IEntryLogApi;
import com.lachesis.lachesislog.server.dto.EntryLogSaveDTO;

public interface ILogService extends IEntryLogApi {

    boolean save(EntryLogSaveDTO entryLogSaveDTO);

}
