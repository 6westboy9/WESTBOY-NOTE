package com.lachesis.lachesislog.server;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

@PropertySource(value = {"classpath:config/dubbo.properties", "file:./config/dubbo.properties"}, ignoreResourceNotFound = true)
@ImportResource(locations = {"classpath:dubbo/dubbo-config.xml"})
@SpringBootApplication(exclude = {MongoAutoConfiguration.class, MongoDataAutoConfiguration.class})
@ComponentScan(basePackages = {"com.lachesis.lachesislog.server", "cn.hutool.extra.spring"})
@MapperScan(basePackages = {"com.lachesis.lachesislog.server.dao"})
public class LachesisLogServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(LachesisLogServerApplication.class);
    }
}
