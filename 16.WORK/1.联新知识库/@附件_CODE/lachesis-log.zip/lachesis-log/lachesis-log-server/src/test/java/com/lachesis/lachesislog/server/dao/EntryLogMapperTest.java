package com.lachesis.lachesislog.server.dao;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lachesis.lachesislog.server.dao.entity.EntryLog;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EntryLogMapperTest {

    private final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern(DatePattern.NORM_DATETIME_PATTERN);

    @Autowired
    private EntryLogMapper entryLogMapper;

    @Test
    public void saveTest() {
        EntryLog entryLog = new EntryLog();
        entryLog.setLogId("11111");
        entryLog.setApp("app");
        entryLog.setModule("1");
        entryLog.setOpName("1");
        entryLog.setOperator("1");
        entryLog.setContent("1");
        entryLog.setStartTime(LocalDateTime.parse("2023-12-01 00:00:00", DATE_TIME_FORMATTER));
        entryLog.setEndTime(LocalDateTime.parse("2023-12-01 00:00:00", DATE_TIME_FORMATTER));
        entryLog.setIsError(false);
        entryLog.setErrorMsg("");
        entryLog.setIsDeleted(false);
        entryLog.setCreateTime(LocalDateTime.parse("2024-03-01 00:00:00", DATE_TIME_FORMATTER));
        entryLog.setUpdateTime(LocalDateTime.parse("2024-01-01 00:00:00", DATE_TIME_FORMATTER));
        // 防止不必要的表创建，仅限在开发环境使用
        // entryLogMapper.insert(entryLog);
    }

    @Test
    public void selectByRangeTest() {
        Page<EntryLog> page = new Page<>();
        page.setCurrent(0);
        page.setSize(10);
        QueryWrapper<EntryLog> wrapper = new QueryWrapper<>();
        wrapper.eq("module", "1");
        wrapper.between("create_time", LocalDateTime.parse("2024-01-01 00:00:00", DATE_TIME_FORMATTER),
            LocalDateTime.parse("2024-02-01 00:00:00", DATE_TIME_FORMATTER));
        wrapper.like("operator", "1");
        // 防止不必要的表创建，仅限在开发环境使用
        // OrderByWorker<EntryLog> worker = OrderByWorker.newInstance(wrapper);
        // worker.fill(wrapper);
        // Page<EntryLog> contentPage = entryLogMapper.selectPage(page, wrapper);
        // PageQueryResult<EntryLog> result = new PageQueryResult<>();
        // result.setTotalCnt(contentPage.getTotal());
        // result.setQueryResult(contentPage.getRecords());
        // System.out.println(JSONUtil.toJsonStr(result));
    }
}