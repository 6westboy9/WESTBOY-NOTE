package com.lachesis.lachesislog.common;

import lombok.Data;

import java.io.Serializable;

@Data
public class PageQuery implements Serializable {
    private int pageSize = 10;
    private int pageNo = 1;
    private String orderBy;
}
