package com.lachesis.lachesislog.common;

public class ResultBuilder {

    /**
     * 后续再细化错误码
     */
    private static final int SUCCESS_CODE = 0;
    private static final int FAIL_CODE = -1;

    public static <T> Result<T> success(T data) {
        Result<T> result = new Result<>();
        result.setCode(SUCCESS_CODE);
        result.setMsg("成功");
        result.setData(data);
        return result;
    }

    public static <T> Result<T> fail(String msg) {
        Result<T> result = new Result<>();
        result.setCode(FAIL_CODE);
        result.setMsg(msg);
        return result;
    }
}
