package com.lachesis.lachesislog.common;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class PageEntity<T> implements Serializable {
    /**
     * 总条目数
     */
    private long totalCount;
    /**
     * 每页长度
     */
    private int pageSize;
    /**
     * 总页数
     */
    private int totalPage;
    /**
     * 当前页码
     */
    private int pageNo;
    /**
     * 当前页数据
     */
    private List<T> list;

    public static <T> PageEntity<T> newInstance(long totalCount, int pageSize, int pageNo, List<T> list) {
        PageEntity<T> page = new PageEntity<>();
        page.setTotalCount(totalCount);
        page.setPageSize(pageSize);
        page.setTotalPage(totalPage(totalCount, pageSize));
        page.setPageNo(pageNo);
        page.setList(list);
        return page;
    }

    public static int totalPage(long totalCount, int pageSize) {
        if (pageSize == 0) {
            return 0;
        }
        return Math.toIntExact(totalCount % pageSize == 0 ? (totalCount / pageSize) : (totalCount / pageSize + 1));
    }
}
