package com.lachesis.lachesislog.api.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 日志附件内容查询参数
 */
@Data
public class LogAttachment implements Serializable {
    private List<LogAttachmentPair> attachmentPairs;
}
