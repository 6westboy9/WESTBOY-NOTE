package com.lachesis.lachesislog.api.domain;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class EntryLogDTO implements Serializable {
    private Long seqId;
    private String logId;
    private String app;
    private String module;
    private String opName;
    private String operator;
    private String content;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Boolean isError;
    private String errorMsg;
    private Boolean isDeleted;
    private String attachments;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
