package com.lachesis.lachesislog.api;

import com.lachesis.lachesislog.api.domain.EntryLogDTO;
import com.lachesis.lachesislog.api.domain.LogPageQuery;
import com.lachesis.lachesislog.common.PageEntity;

public interface IEntryLogApi {

    PageEntity<EntryLogDTO> getPage(LogPageQuery query);

}
