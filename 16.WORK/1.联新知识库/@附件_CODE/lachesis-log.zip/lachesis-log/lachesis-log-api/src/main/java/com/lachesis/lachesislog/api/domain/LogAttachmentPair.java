package com.lachesis.lachesislog.api.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LogAttachmentPair implements Serializable {

    private String key;
    private String value;

    public String getSearchKey() {
        // 存储内容均为JSON字符串，且value也是string类型
        // 样例:{"patName":"陆周浊","docCode":"D00332876","headerCode":"H00321052","docOpType":"删除文书","bedNo":"111免1"}
        // 生成搜索关键词,比如key=patName,value=陆周浊,那么生成的搜索关键词为:"patName":"陆周浊"
        return String.format("\"%s\":\"%s\"", key, value);
    }
}
