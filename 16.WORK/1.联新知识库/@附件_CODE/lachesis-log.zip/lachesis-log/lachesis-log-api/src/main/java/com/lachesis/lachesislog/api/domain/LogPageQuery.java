package com.lachesis.lachesislog.api.domain;

import com.lachesis.lachesislog.common.PageQuery;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
public class LogPageQuery extends PageQuery {
    private List<String> moduleList;
    private List<LogAttachment> attachments;
    private String minStartTime;
    private String maxStartTime;
    private List<String> operatorList;
}
