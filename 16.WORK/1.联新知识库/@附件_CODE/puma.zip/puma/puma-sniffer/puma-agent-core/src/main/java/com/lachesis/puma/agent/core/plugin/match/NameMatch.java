package com.lachesis.puma.agent.core.plugin.match;

/**
 * 全限定名称匹配
 */
public class NameMatch implements ClassMatch {

    private final String className;

    private NameMatch(String className) {
        this.className = className;
    }

    public String getClassName() {
        return className;
    }

    public static NameMatch byNameMatch(String className) {
        return new NameMatch(className);
    }

}
