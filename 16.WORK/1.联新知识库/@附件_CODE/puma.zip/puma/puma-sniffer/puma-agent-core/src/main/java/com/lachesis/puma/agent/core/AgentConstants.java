package com.lachesis.puma.agent.core;

public class AgentConstants {
    public static final String AGENT_NAME = "puma-agent";
    public static final String AGENT_JAR = "puma-agent.jar";
    public static final String PLUGIN_DFE_NAME = "puma-plugin.def";
    public static final String PLUGIN_PACKAGE_NAME = "plugins";
}
