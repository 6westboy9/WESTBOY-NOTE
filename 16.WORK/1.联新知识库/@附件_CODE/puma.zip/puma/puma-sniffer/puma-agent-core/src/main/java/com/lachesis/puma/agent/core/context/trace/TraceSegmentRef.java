package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.context.ContextSnapshot;
import com.lachesis.puma.protocol.network.SegmentRefType;
import com.lachesis.puma.protocol.network.SegmentRefData;

public class TraceSegmentRef {

    private SegmentRefType type;
    private String traceId;
    private String traceSegmentId;
    private int spanId;
    private String parentService;
    private String parentServiceInstance;
    private String parentEndpoint;
    private String addressUsedAtClient;

    public TraceSegmentRef(ContextSnapshot snapshot) {
        this.type = SegmentRefType.CROSS_THREAD;
        this.traceId = snapshot.getDistributedTraceId().getId();
        this.traceSegmentId = snapshot.getTraceSegmentId();
        this.spanId = snapshot.getSpanId();
        this.parentService = "";
        this.parentServiceInstance = "";
        this.parentEndpoint = snapshot.getParentEndpoint();
    }

    public SegmentRefData transform() {
        SegmentRefData segmentRefData = new SegmentRefData();
        segmentRefData.setRefType(type);
        segmentRefData.setTraceId(traceId);
        segmentRefData.setParentTraceSegmentId(traceSegmentId);
        segmentRefData.setParentSpanId(spanId);
        segmentRefData.setParentServiceInstance(parentServiceInstance);
        segmentRefData.setParentEndpoint(parentEndpoint);
        if (addressUsedAtClient != null) {
            segmentRefData.setNetworkAddressUsedAtPeer(addressUsedAtClient);
        }
        return segmentRefData;
    }

    public SegmentRefType getType() {
        return type;
    }

    public String getTraceId() {
        return traceId;
    }

    public String getTraceSegmentId() {
        return traceSegmentId;
    }

    public int getSpanId() {
        return spanId;
    }

    public String getParentService() {
        return parentService;
    }

    public String getParentServiceInstance() {
        return parentServiceInstance;
    }

    public String getParentEndpoint() {
        return parentEndpoint;
    }

    public String getAddressUsedAtClient() {
        return addressUsedAtClient;
    }
}
