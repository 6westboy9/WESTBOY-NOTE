package com.lachesis.puma.agent.core.context.ids;

public abstract class DistributedTraceId {

    private final String id;

    protected DistributedTraceId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
}
