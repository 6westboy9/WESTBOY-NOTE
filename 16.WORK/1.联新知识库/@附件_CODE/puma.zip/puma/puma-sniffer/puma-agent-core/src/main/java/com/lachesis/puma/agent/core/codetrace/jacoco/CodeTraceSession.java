/*
76ce8b保密声明：当前项目源码仅授权王*博本人学习，请勿发给第三方，已添加隐形追踪水印*/
package com.lachesis.puma.agent.core.codetrace.jacoco;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class CodeTraceSession {

    // static final int MAX_SIZE = 5000;
    static final ThreadLocal<CodeTraceSession> sessions = new ThreadLocal<>();
    private final CodeTraceNode rootNode;
    private CodeTraceNode hotNode;
    private int invokeCount = 0;
    private int nodeSize = 0;
    private final int errorSize = 0;

    /**
     * 一个线程只能开启一次
     */
    public CodeTraceSession(String className, String methodName) {
        if (sessions.get() != null) {
            throw new RuntimeException();
        }

        CodeTraceNode rootNode = new CodeTraceNode(-1L, className, methodName);
        rootNode.setId("0");
        rootNode.setBeginTime(System.nanoTime());

        invokeCount = 1;
        this.rootNode = rootNode;
        hotNode = rootNode;
        sessions.set(this);
    }

    public void close() {
        if (sessions.get() == this) {
            sessions.remove();
        } else {
            throw new RuntimeException();
        }
    }

    public static Object $begin(long classId, String className, String methodName) {
        CodeTraceSession session = sessions.get();
        if (session == null) {
            return new Object();
        } else {
            CodeTraceNode node = session.addNode(new CodeTraceNode(classId, className, methodName));
            return node == null ? new Object() : node;
        }
    }

    public static void $end(Object stackNode) {
        CodeTraceSession codeTraceSession = sessions.get();
        if (codeTraceSession != null && stackNode instanceof CodeTraceNode) {
            // 结束调用回退至上一级
            codeTraceSession.doneNode((CodeTraceNode) stackNode);
        }
    }

    public CodeTraceNode addNode(CodeTraceNode node) {
        invokeCount++;
        // if (nodeSize >= MAX_SIZE) {
        //     return null;
        // }
        boolean existiod = false;
        for (CodeTraceNode child : hotNode.getChildren()) {
            if (child.getClassName().equals(node.getClassName()) &&
                child.getMethodName().equals(node.getMethodName())) {
                node = child;
                existiod = true;
                break;
            }
        }
        if (!existiod) {
            nodeSize++;
            hotNode.getChildren().add(node);
            node.setStackSession(this);
            node.setId(hotNode.getId() + "." + hotNode.getChildren().size());
            node.setSize(1);
        } else {
            node.incrSize();
        }

        node.setParent(hotNode);
        hotNode = node;
        node.setBeginTime(System.nanoTime());
        return node;
    }

    public static CodeTraceSession get() {
        return sessions.get();
    }

    public void doneNode(CodeTraceNode node) {
        node.done();
        // node.setDone(true);
        // node.setFinishTime(System.nanoTime());
        // node.setUseTime(node.getFinishTime() - node.getBeginTime());
        hotNode = node.getParent();
    }

    public void doneSession() {
        rootNode.done();
    }

    public CodeTraceNode getHotStack() {
        return hotNode;
    }

    protected void setHotStack(CodeTraceNode hot) {
        hotNode = hot;
    }

    public void printStack(PrintStream out) {
        print(rootNode, out);
    }

    private void print(CodeTraceNode node, PrintStream out) {
        out.println(node.toString());
        for (CodeTraceNode n : node.getChildren()) {
            print(n, out);
        }
    }

    public List<CodeTraceNode> getAllNodes() {
        List<CodeTraceNode> result = new ArrayList<>(nodeSize);
        result.add(rootNode);
        putNodes(rootNode, result);
        return result;
    }

    private void putNodes(CodeTraceNode parent, List<CodeTraceNode> list) {
        for (CodeTraceNode node : parent.getChildren()) {
            list.add(node);
            putNodes(node, list);
        }
    }
}
