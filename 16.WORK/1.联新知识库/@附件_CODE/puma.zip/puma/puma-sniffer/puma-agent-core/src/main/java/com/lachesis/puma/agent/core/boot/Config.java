package com.lachesis.puma.agent.core.boot;

public class Config {

    // 类的命名与配置项是强相关的
    // 比如com.lachesis.puma.agent.core.boot.Config.Agent.SERVICE_NAME
    // 在agent.config中的配置应遵循agent.service_name=xxx，agent为类名Agent的小写，service_name为字段名SERVICE_NAME的小写
    // 注意：字段不能为final类型，否则无法根据配置进行设置
    // 同理在插件中的配置也大致如此
    public static class Agent {
        public static String SERVICE_NAME = "";
        public static String INSTANCE_NAME = "";
        public static String LOG_LEVEL = "info";
    }

}


