package com.lachesis.puma.agent.core.context;

import com.lachesis.puma.agent.core.context.ids.DistributedTraceId;

public class ContextSnapshot {

    private DistributedTraceId distributedTraceId;
    private String traceSegmentId;
    private int spanId;
    private String parentEndpoint;

    public DistributedTraceId getDistributedTraceId() {
        return distributedTraceId;
    }

    public void setDistributedTraceId(DistributedTraceId distributedTraceId) {
        this.distributedTraceId = distributedTraceId;
    }

    public String getTraceSegmentId() {
        return traceSegmentId;
    }

    public void setTraceSegmentId(String traceSegmentId) {
        this.traceSegmentId = traceSegmentId;
    }

    public int getSpanId() {
        return spanId;
    }

    public void setSpanId(int spanId) {
        this.spanId = spanId;
    }

    public String getParentEndpoint() {
        return parentEndpoint;
    }

    public void setParentEndpoint(String parentEndpoint) {
        this.parentEndpoint = parentEndpoint;
    }

    public boolean isValid() {
        return traceSegmentId != null && spanId > -1 && distributedTraceId != null;
    }

    public boolean isFromCurrent() {
        return traceSegmentId != null && traceSegmentId.equals(ContextManager.capture().getTraceSegmentId());
    }
}
