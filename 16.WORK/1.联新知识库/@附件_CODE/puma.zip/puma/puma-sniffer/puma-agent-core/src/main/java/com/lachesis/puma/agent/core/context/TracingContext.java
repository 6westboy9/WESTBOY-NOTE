package com.lachesis.puma.agent.core.context;

import com.lachesis.puma.agent.core.context.trace.*;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.util.LinkedList;
import java.util.List;

public class TracingContext implements ITracerContext {

    private final TraceSegment segment;
    private final LinkedList<ISpan> activeSpanStack = new LinkedList<>();
    private ISpan firstSpan;
    private int spanIdGenerator;
    private volatile boolean running;

    public TracingContext() {
        this.segment = new TraceSegment();
        this.spanIdGenerator = 0;
        running = true;
    }

    @Override
    public ContextSnapshot capture() {
        ContextSnapshot snapshot = new ContextSnapshot();
        snapshot.setDistributedTraceId(segment.getRelatedGlobalTraceId());
        snapshot.setTraceSegmentId(segment.getTraceSegmentId());
        snapshot.setSpanId(activeSpan().getSpanId());
        snapshot.setParentEndpoint(firstSpan.getOpName());
        return snapshot;
    }

    @Override
    public void continued(ContextSnapshot snapshot) {
        if (snapshot.isValid()) {
            TraceSegmentRef segmentRef = new TraceSegmentRef(snapshot);
            segment.ref(segmentRef);
            activeSpan().ref(segmentRef);
            segment.relatedGlobalTrace(snapshot.getDistributedTraceId());
        }
    }

    @Override
    public String getSegmentId() {
        return null;
    }

    @Override
    public int getSpanId() {
        return 0;
    }

    @Override
    public ISpan createEntrySpan(String opName) {
        ISpan entrySpan;
        ISpan parentSpan = peek();
        int parentSpanId = parentSpan == null ? -1 : parentSpan.getSpanId();
        // 嵌套时复用
        if (parentSpan != null && parentSpan.isEntry()) {
            parentSpan.setOpName(opName);
            entrySpan = parentSpan;
            return entrySpan.start();
        } else {
            entrySpan = new EntrySpan(spanIdGenerator++, parentSpanId, opName, this);
            entrySpan.start();
            return push(entrySpan);
        }
    }

    @Override
    public ISpan createLocalSpan(String opName) {
        ISpan parentSpan = peek();
        int parentSpanId = parentSpan == null ? -1 : parentSpan.getSpanId();
        ISpan span = new LocalSpan(spanIdGenerator++, parentSpanId, opName, this);
        span.start();
        return push(span);
    }

    @Override
    public ISpan createExitSpan(String opName, String remotePeer) {
        ISpan exitSpan;
        ISpan parentSpan = peek();
        TracingContext owner = this;
        // 嵌套时复用
        if (parentSpan != null && parentSpan.isExit()) {
            exitSpan = parentSpan;
        } else {
            int parentSpanId = parentSpan == null ? -1 : parentSpan.getSpanId();
            exitSpan = new ExitSpan(spanIdGenerator++, parentSpanId, opName, remotePeer, owner);
            push(exitSpan);
        }
        exitSpan.start();
        return exitSpan;
    }

    @Override
    public ISpan activeSpan() {
        ISpan span = peek();
        if (span == null) {
            throw new IllegalStateException("当前活跃的Span不存在");
        }
        return span;
    }

    @Override
    public boolean stopSpan(ISpan span) {
        ISpan lastSpan = peek();
        // 当前Span必须是活跃的栈顶Span
        if (lastSpan == span) {
            if (lastSpan instanceof AbstractTracingSpan) {
                AbstractTracingSpan toFinishSpan = (AbstractTracingSpan) lastSpan;
                if (toFinishSpan.finish(segment)) {
                    // LogUtil.info("停止Span...");
                    pop();
                }
            } else {
                pop();
            }
        } else {
            throw new IllegalStateException("停止Span异常");
        }
        finish();
        return activeSpanStack.isEmpty();
    }

    private void finish() {
        boolean isFinished = activeSpanStack.isEmpty() && running;
        if (isFinished) {
            TracingContext.ListenerManager.notifyFinish(segment);
            running = false;
        }
    }

    @Override
    public ITracerContext awaitFinishAsync() {
        return null;
    }

    @Override
    public void asyncStop(ISpan span) {

    }

    @Override
    public String getReadablePrimaryTraceId() {
        return segment.getRelatedTraceId().getId();
    }

    public static class ListenerManager {

        private static final List<TracingContextListener> LISTENERS = new LinkedList<>();

        public static synchronized void add(TracingContextListener listener) {
            LISTENERS.add(listener);
        }

        public static synchronized void remove(TracingContextListener listener) {
            LISTENERS.remove(listener);
        }

        static void notifyFinish(TraceSegment finishedSegment) {
            for (TracingContextListener listener : LISTENERS) {
                listener.afterFinished(finishedSegment);
            }
        }
    }

    private ISpan peek() {
        if (activeSpanStack.isEmpty()) {
            return null;
        } else {
            return activeSpanStack.getLast();
        }
    }

    private ISpan push(ISpan span) {
        if (firstSpan == null) {
            firstSpan = span;
        }
        activeSpanStack.addLast(span);
        return span;
    }

    private void pop() {
        activeSpanStack.removeLast();
    }
}
