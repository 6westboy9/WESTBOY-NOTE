package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.context.TracingContext;
import com.lachesis.puma.agent.core.context.tag.StringTag;

public class EntrySpan extends StackBasedTracingSpan {

    private int currentMaxDepth;

    public EntrySpan(int spanId, int parentSpanId, String opName, TracingContext owner) {
        super(spanId, parentSpanId, opName, owner);
        this.currentMaxDepth = 0;
    }

    @Override
    public EntrySpan start() {
        if ((currentMaxDepth = ++stackDepth) == 1) {
            super.start();
        }
        // 不等于1时会进行复用，清空之前插件创建的EntrySpan信息
        clearWhenRestart();
        return this;
    }

    @Override
    public EntrySpan tag(StringTag tag, String value) {
        // 防止返回的时候进行Span中的信息被覆盖
        if (stackDepth == currentMaxDepth) {
            super.tag(tag, value);
        }
        return this;
    }

    @Override
    public ISpan setOpName(String opName) {
        super.setOpName(opName);
        return this;
    }

    @Override
    public boolean isEntry() {
        return true;
    }

    @Override
    public boolean isExit() {
        return false;
    }

    private void clearWhenRestart() {
        this.tags = null;
    }

}
