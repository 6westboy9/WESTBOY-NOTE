package com.lachesis.puma.agent.core.context.trace;

public interface TracingContextListener {

    void afterFinished(TraceSegment traceSegment);

}
