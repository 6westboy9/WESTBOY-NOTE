/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.lachesis.puma.agent.core.plugin.match;

import cn.hutool.core.collection.CollUtil;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;

import java.util.List;

import static net.bytebuddy.matcher.ElementMatchers.nameMatches;


public class WildcardMatch implements IndirectMatch {

    private final List<String> includeRegexExpressions;
    private final List<String> excludeRegexExpressions;

    private WildcardMatch(List<String> includeRegexExpressions, List<String> excludeRegexExpressions) {
        if (CollUtil.isEmpty(includeRegexExpressions)) {
            throw new IllegalArgumentException("参数不能为空");
        }
        // includeRegexExpressions必须不为空
        // excludeRegexExpressions可以为空
        this.includeRegexExpressions = includeRegexExpressions;
        this.excludeRegexExpressions = excludeRegexExpressions;
    }

    @Override
    public ElementMatcher.Junction<? super TypeDescription> buildJunction() {
        ElementMatcher.Junction<? super TypeDescription> regexJunction = null;
        for (String includeRegexExpression : includeRegexExpressions) {
            if (regexJunction == null) {
                regexJunction = nameMatches(includeRegexExpression);
            } else {
                regexJunction = regexJunction.or(nameMatches(includeRegexExpression));
            }
        }
        return regexJunction;
    }

    @Override
    public boolean isMatch(TypeDescription typeDescription) {
        boolean isMatch = false;
        for (String matchExpression : includeRegexExpressions) {
            String typeName = typeDescription.getTypeName();
            isMatch = typeName.matches(matchExpression);
            if (isMatch) {
                if (CollUtil.isNotEmpty(excludeRegexExpressions)) {
                    for (String excludeRegexExpression : excludeRegexExpressions) {
                        if (typeName.matches(excludeRegexExpression)) {
                            return false;
                        }
                    }
                }
                break;
            }
        }
        return isMatch;
    }

    public static WildcardMatch byRegexMatch(List<String> includeRegexExpressions, List<String> excludeRegexExpressions) {
        return new WildcardMatch(includeRegexExpressions, excludeRegexExpressions);
    }
}