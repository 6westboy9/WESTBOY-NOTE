package com.lachesis.puma.agent.core.plugin.bootstrap;

import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.ClassLoaderUtil;
import cn.hutool.core.util.ClassUtil;
import com.lachesis.puma.agent.core.plugin.AbstractClassEnhancePluginDefine;
import com.lachesis.puma.agent.core.plugin.PluginFinder;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.loader.AgentClassLoader;
import com.lachesis.puma.agent.core.util.IOUtil;
import net.bytebuddy.ByteBuddy;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.ClassFileLocator;
import net.bytebuddy.dynamic.DynamicType;
import net.bytebuddy.dynamic.loading.ClassInjector;
import net.bytebuddy.pool.TypePool;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.instrument.Instrumentation;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static net.bytebuddy.matcher.ElementMatchers.named;

public class BootstrapInstrumentBoost {

    /**
     * 这里要注意打包方式，此路径依赖于打包maven-shade-plugin的配置
     */
    private static final String SHADE_PACKAGE = "com.lachesis.puma.dependencies.";
    private static final String[] BYTE_BUDDY_CORE_CLASSES = {
        SHADE_PACKAGE + "net.bytebuddy.implementation.bind.annotation.RuntimeType",
        SHADE_PACKAGE + "net.bytebuddy.implementation.bind.annotation.This",
        SHADE_PACKAGE + "net.bytebuddy.implementation.bind.annotation.AllArguments",
        SHADE_PACKAGE + "net.bytebuddy.implementation.bind.annotation.AllArguments$Assignment",
        SHADE_PACKAGE + "net.bytebuddy.implementation.bind.annotation.SuperCall",
        SHADE_PACKAGE + "net.bytebuddy.implementation.bind.annotation.Origin",
        SHADE_PACKAGE + "net.bytebuddy.implementation.bind.annotation.Morph",
    };

    private static final String[] HIGH_PRIORITY_CLASSES = {
        "com.lachesis.puma.agent.core.plugin.BootstrapInterceptorRuntimeAssist",
        "com.lachesis.puma.agent.core.plugin.interceptor.StaticMethodsAroundInterceptor",
        "com.lachesis.puma.agent.core.plugin.interceptor.InstanceConstructorInterceptor",
        "com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor",
        "com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance",
        "com.lachesis.puma.agent.core.plugin.OverrideCallable",
        "com.lachesis.puma.agent.core.plugin.MethodInvocationContext",
        "com.lachesis.puma.agent.core.util.LogUtil",
        "com.lachesis.puma.agent.core.util.DateUtil",
    };

    private static final String CONSTRUCTOR_DELEGATE_TEMPLATE = "com.lachesis.puma.agent.core.plugin.bootstrap.template.InstanceConstructorInterceptorTemplate";
    private static final String STATIC_METHOD_DELEGATE_TEMPLATE = "com.lachesis.puma.agent.core.plugin.bootstrap.template.StaticMethodsInterceptorTemplate";
    private static final String STATIC_METHOD_WITH_OVERRIDE_ARGS_DELEGATE_TEMPLATE = "com.lachesis.puma.agent.core.plugin.bootstrap.template.StaticMethodsInterceptorTemplateWithOverrideArgsTemplate";
    private static final String INSTANCE_METHOD_DELEGATE_TEMPLATE = "com.lachesis.puma.agent.core.plugin.bootstrap.template.InstanceMethodsInterceptorTemplate";
    private static final String INSTANCE_METHOD_WITH_OVERRIDE_ARGS_DELEGATE_TEMPLATE = "com.lachesis.puma.agent.core.plugin.bootstrap.template.InstanceMethodsInterceptorWithOverrideArgsTemplate";

    public static AgentBuilder inject(PluginFinder pluginFinder, Instrumentation instrumentation, AgentBuilder builder) {
        Map<String, byte[]> classesTypeMap = new HashMap<>();
        // 针对于目标类是JDK的核心类库插件，这里根据插件的拦截点的不同（实例方法，静态方法，构造方法）
        // 使用不同的模板（xxxTemplate）来定义新的拦截器的核心处理逻辑，并且将插件本身定义的拦截器的全类名赋值给targetInterceptor字段
        // 最终，这些新的拦截器的核心处理逻辑都会被全部放进BootstrapClassLoader中
        if (!prepareJREInstrumentation(pluginFinder, classesTypeMap)) {
            return builder;
        }

        // 插件本身依赖的一些类需要放进BootstrapClassLoader中
        for (String highPriorityClass : HIGH_PRIORITY_CLASSES) {
            loadHighPriorityClass(classesTypeMap, highPriorityClass);
        }
        for (String highPriorityClass : BYTE_BUDDY_CORE_CLASSES) {
            loadHighPriorityClass(classesTypeMap, highPriorityClass);
        }
        ClassInjector.UsingUnsafe.Factory factory = ClassInjector.UsingUnsafe.Factory.resolve(instrumentation);
        factory.make(null, null).injectRaw(classesTypeMap);
        builder = builder.with(new AgentBuilder.InjectionStrategy.UsingUnsafe.OfFactory(factory));
        return builder;
    }

    public static Class<?> forInternalDelegateClass(String methodsInterceptor) {
        try {
            return Class.forName(internalDelegate(methodsInterceptor));
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static boolean prepareJREInstrumentation(PluginFinder pluginFinder, Map<String, byte[]> classesTypeMap) {
        TypePool typePool = TypePool.Default.of(BootstrapInstrumentBoost.class.getClassLoader());
        List<AbstractClassEnhancePluginDefine> bootstrapClassMatchDefines = pluginFinder.getBootstrapClassMatchDefine();
        for (AbstractClassEnhancePluginDefine define : bootstrapClassMatchDefines) {
            // 1.构造方法
            if (ArrayUtil.isNotEmpty(define.getConstructorMethodsInterceptorPoints())) {
                for (MethodsInterceptorPoint point : define.getConstructorMethodsInterceptorPoints()) {
                    generateDelegator(classesTypeMap, typePool, CONSTRUCTOR_DELEGATE_TEMPLATE, point.getInterceptor());
                }
            }

            // 2.实例方法
            if (ArrayUtil.isNotEmpty(define.getInstanceMethodsInterceptorPoints())) {
                for (MethodsInterceptorPoint point : define.getInstanceMethodsInterceptorPoints()) {
                    if (point.isOverrideArgs()) {
                        generateDelegator(classesTypeMap, typePool, INSTANCE_METHOD_WITH_OVERRIDE_ARGS_DELEGATE_TEMPLATE, point.getInterceptor());
                    } else {
                        generateDelegator(classesTypeMap, typePool, INSTANCE_METHOD_DELEGATE_TEMPLATE, point.getInterceptor());
                    }
                }
            }

            // 3.静态方法
            if (ArrayUtil.isNotEmpty(define.getStaticMethodsInterceptorPoints())) {
                for (MethodsInterceptorPoint point : define.getStaticMethodsInterceptorPoints()) {
                    if (point.isOverrideArgs()) {
                        generateDelegator(classesTypeMap, typePool, STATIC_METHOD_WITH_OVERRIDE_ARGS_DELEGATE_TEMPLATE, point.getInterceptor());
                    } else {
                        generateDelegator(classesTypeMap, typePool, STATIC_METHOD_DELEGATE_TEMPLATE, point.getInterceptor());
                    }
                }
            }
        }
        return !bootstrapClassMatchDefines.isEmpty();
    }

    /**
     * 生成增强代理类
     *
     * @param classesTypeMap    代理类字节码映射
     * @param typePool          {@link TypePool}
     * @param templateClassname 模板类名
     * @param interceptor       模板中的拦截器名称
     */
    private static void generateDelegator(Map<String, byte[]> classesTypeMap, TypePool typePool, String templateClassname, String interceptor) {
        // 比如：
        // methodsInterceptor = com.lachesis.puma.agent.plugin.dubbo.DubboInterceptor
        // internalInterceptorName = com.lachesis.puma.agent.plugin.dubbo.DubboInterceptor_internal
        String internalInterceptorName = internalDelegate(interceptor);
        TypeDescription templateTypeDescription = typePool.describe(templateClassname).resolve();
        // 这里仅是将字节码组装好，此时还没有被加载~
        DynamicType.Unloaded<?> interceptorType = new ByteBuddy().redefine(templateTypeDescription,
                ClassFileLocator.ForClassLoader.of(BootstrapInstrumentBoost.class.getClassLoader()))
            .name(internalInterceptorName)
            // 需保证与各个Template中字段名保持一致
            .field(named("targetInterceptor"))
            .value(interceptor)
            .make();
        classesTypeMap.put(internalInterceptorName, interceptorType.getBytes());
    }

    private static void loadHighPriorityClass(Map<String, byte[]> classesTypeMap, String classname) {
        byte[] enhancedInstanceClassFile;
        InputStream inputStream = null;
        try {
            String classResourceName = classname.replace(".", "/").concat(".class");
            AgentClassLoader classLoader = AgentClassLoader.getDefault();
            inputStream = classLoader.getResourceAsStream(classResourceName);
            if (inputStream == null) {
                throw new FileNotFoundException(String.format("类文件找不到:%s", classResourceName));
            }
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;
            // read bytes from the input stream and store them in buffer
            while ((len = inputStream.read(buffer)) != -1) {
                // write bytes from the buffer into output stream
                os.write(buffer, 0, len);
            }
            enhancedInstanceClassFile = os.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            IoUtil.close(inputStream);
        }
        classesTypeMap.put(classname, enhancedInstanceClassFile);
    }

    private static String internalDelegate(String methodsInterceptor) {
        return methodsInterceptor + "_internal";
    }
}
