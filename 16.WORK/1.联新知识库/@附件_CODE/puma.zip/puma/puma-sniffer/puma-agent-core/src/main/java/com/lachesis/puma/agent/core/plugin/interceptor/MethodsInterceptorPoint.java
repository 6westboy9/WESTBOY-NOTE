package com.lachesis.puma.agent.core.plugin.interceptor;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;

/**
 * 方法拦截点
 */
public interface MethodsInterceptorPoint {

    /**
     * 要拦截哪些方法
     */
    ElementMatcher<MethodDescription> getMatcher();

    /**
     * 获取被增强方法对应的拦截器名称
     */
    String getInterceptor();

    /**
     * 是否覆盖参数
     */
    default boolean isOverrideArgs() {
        return false;
    }
}
