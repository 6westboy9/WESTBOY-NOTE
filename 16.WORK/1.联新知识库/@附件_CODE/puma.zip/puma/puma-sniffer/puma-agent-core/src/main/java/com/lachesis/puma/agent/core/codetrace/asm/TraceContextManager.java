package com.lachesis.puma.agent.core.codetrace.asm;

public class TraceContextManager {

    private static final ThreadLocal<TraceContext> CONTEXT = new ThreadLocal<>();

    public static void beforeMethod(MethodInfo methodInfo) {
        TraceContext context = CONTEXT.get();
        if (context == null) {
            context = new TraceContext();
            context.setCreateTime(System.nanoTime());
            context.setRunning(true);
        }
        TraceNode node = new TraceNode();
        if (!context.isInit()) {
            node.setId("0");
            node.setMethodInfo(methodInfo);
            node.setBeforeTime(System.nanoTime());
            context.setRoot(node);
            context.setCurrent(node);
            context.setInit(true);
        } else {
            TraceNode currentNode = context.getCurrent();
            if (currentNode.containsChild(methodInfo.identifier())) {
                currentNode.incrSize();
            } else {
                int size = currentNode.childrenSize();
                node.setId(currentNode.getId() + "." + size);
                node.setMethodInfo(methodInfo);
                node.setBeforeTime(System.nanoTime());
                currentNode.addChild(node);
                // 进入
                node.setParent(currentNode);
                context.setCurrent(node);
            }
        }
        CONTEXT.set(context);
    }

    public static void handleEx(MethodInfo methodInfo) {
        TraceContext context = CONTEXT.get();
        if (context != null) {
            TraceNode currentNode = context.getCurrent();
            currentNode.setAfterTime(System.nanoTime());
            currentNode.setCost(currentNode.getAfterTime() - currentNode.getBeforeTime());
            MethodInfo currentMethodInfo = currentNode.getMethodInfo();
            currentMethodInfo.setThrowable(methodInfo.getThrowable());
        }
    }

    public static void afterMethod(MethodInfo methodInfo) {
        TraceContext context = CONTEXT.get();
        if (context != null) {
            TraceNode currentNode = context.getCurrent();
            currentNode.setAfterTime(System.nanoTime());
            currentNode.setCost(currentNode.getAfterTime() - currentNode.getBeforeTime());
            MethodInfo currentMethodInfo = currentNode.getMethodInfo();
            currentMethodInfo.setReturnValue(methodInfo.getReturnValue());

            // 退出
            context.setCurrent(currentNode.getParent());
        }
    }

    public static void print() {
        TraceContext context = CONTEXT.get();
        context.print(context.getRoot(), System.out);
    }

}
