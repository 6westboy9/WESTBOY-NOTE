package com.lachesis.puma.agent.core.codetrace.samples;

import java.util.ArrayList;
import java.util.List;

public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    public List<User> listUser(String name, int age) {
        return userService.listUser(name, age);
    }

    public List<UserInfo> listUser(Integer id) {
        List<UserInfo> list = new ArrayList<>();
        if (id == 1) {
            list.add(new UserInfo(1, "a1", 18));
            list.add(new UserInfo(2, "a2", 19));
            list.add(new UserInfo(3, "a3", 20));
        } else {
            list.add(new UserInfo(1, "b1", 18));
            list.add(new UserInfo(2, "b2", 19));
            list.add(new UserInfo(3, "b3", 20));
        }
        return list;
    }

    public double test() {
        System.out.println("hello");
        return 1.2;
    }

    static class UserInfo {
        private int id;
        private String name;
        private int age;

        public UserInfo(int id, String name, int age) {
            this.id = id;
            this.name = name;
            this.age = age;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }
    }
}
