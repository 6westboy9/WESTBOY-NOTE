package com.lachesis.puma.agent.core.plugin;

import com.lachesis.puma.agent.core.AgentConstants;
import com.lachesis.puma.agent.core.plugin.loader.AgentClassLoader;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

public class PluginResourcesResolver {

    public static List<URL> getResources() {
        List<URL> cfgUrlPaths = new ArrayList<>();
        try {
            Enumeration<URL> urls = AgentClassLoader.getDefault().getResources(AgentConstants.PLUGIN_DFE_NAME);
            while (urls.hasMoreElements()) {
                URL pluginDefineDefUrl = urls.nextElement();
                cfgUrlPaths.add(pluginDefineDefUrl);
            }
            return cfgUrlPaths;
        } catch (Exception e) {
            LogUtil.error(e, String.format("获取插件定义配置资源[%s]异常", AgentConstants.PLUGIN_DFE_NAME));
        }
        return null;
    }
}
