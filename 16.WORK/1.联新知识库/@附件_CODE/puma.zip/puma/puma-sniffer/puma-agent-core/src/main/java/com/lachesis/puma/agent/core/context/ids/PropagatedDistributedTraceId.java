package com.lachesis.puma.agent.core.context.ids;

public class PropagatedDistributedTraceId extends DistributedTraceId {
    protected PropagatedDistributedTraceId(String id) {
        super(id);
    }
}
