package com.lachesis.puma.agent.core.codetrace;

import cn.hutool.core.io.IoUtil;
import com.lachesis.puma.agent.core.codetrace.asm.MethodInvocationTransformer;
import org.junit.jupiter.api.BeforeEach;

import java.io.InputStream;
import java.security.ProtectionDomain;

class InvocationTransformerUserControllerTest {

    private final MethodInvocationTransformer codeTraceTransformer = new MethodInvocationTransformer(1);
    private byte[] newBytes;

    @BeforeEach
    void before() {
        ClassLoader classLoader = getClass().getClassLoader();
        ProtectionDomain domain = InvocationTransformerUserControllerTest.class.getProtectionDomain();
        InputStream inputStream = getClass().getResourceAsStream("/com/lachesis/puma/agent/core/codetrace/samples/UserController.class");
        byte[] bytes = IoUtil.readBytes(inputStream);
        String className = "com.lachesis.puma.agent.core.codetrace.samples.UserController";
        newBytes = codeTraceTransformer.transform(classLoader, className, null, domain, bytes);
    }

}