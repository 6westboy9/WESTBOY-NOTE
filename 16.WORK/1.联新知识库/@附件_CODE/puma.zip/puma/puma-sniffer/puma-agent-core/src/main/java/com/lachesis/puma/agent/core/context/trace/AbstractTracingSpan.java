package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.context.TracingContext;
import com.lachesis.puma.agent.core.context.support.KeyValuePair;
import com.lachesis.puma.agent.core.context.support.ThrowableTransformer;
import com.lachesis.puma.agent.core.context.tag.StringTag;
import com.lachesis.puma.agent.core.context.tag.TagValuePair;
import com.lachesis.puma.protocol.component.Component;
import com.lachesis.puma.protocol.network.SpanData;
import com.lachesis.puma.protocol.network.SpanLayer;
import com.lachesis.puma.protocol.network.SpanType;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public abstract class AbstractTracingSpan implements ISpan {

    /**
     * 从0开始
     */
    private final int spanId;
    /**
     * 从0开始，-1表示没有父Span
     */
    private final int parentSpanId;
    protected List<TagValuePair> tags;
    private String opName;
    private SpanLayer layer;
    /**
     * 单位：纳秒
     */
    private long startTime;
    /**
     * 单位：纳秒
     */
    private long endTime;
    private boolean errorOccurred = false;
    protected int componentId = 0;
    protected List<LogDataEntity> logs;
    private TracingContext owner;
    protected List<TraceSegmentRef> refs;

    public AbstractTracingSpan(int spanId, int parentSpanId, String opName, TracingContext owner) {
        this.spanId = spanId;
        this.parentSpanId = parentSpanId;
        this.opName = opName;
        this.owner = owner;
    }

    @Override
    public void setComponent(Component component) {
        this.componentId = component.getId();
    }

    @Override
    public void setLayer(SpanLayer layer) {
        this.layer = layer;
    }

    public int getSpanId() {
        return spanId;
    }

    @Override
    public ISpan tag(StringTag tag, String value) {
        if (tags == null) {
            tags = new ArrayList<>();
        }
        if (tag.isCanOverwrite()) {
            for (TagValuePair pair : tags) {
                if (pair.sameWith(tag)) {
                    pair.setValue(value);
                    return this;
                }
            }
        }
        tags.add(new TagValuePair(tag, value));
        return this;
    }

    @Override
    public ISpan log(Throwable t) {
        if (logs == null) {
            logs = new LinkedList<>();
        }
        logs.add(new LogDataEntity.Builder().add(new KeyValuePair("event", "error"))
            .add(new KeyValuePair("error.kind", t.getClass().getName()))
            .add(new KeyValuePair("message", t.getMessage()))
            .add(new KeyValuePair("stack", ThrowableTransformer.INSTANCE.convert2String(t, 4000)))
            .build(System.currentTimeMillis()));
        return this;
    }

    @Override
    public ISpan errorOccurred() {
        this.errorOccurred = true;
        return this;
    }

    @Override
    public ISpan setOpName(String opName) {
        this.opName = opName;
        return this;
    }

    @Override
    public ISpan start() {
        this.startTime = System.nanoTime();
        return this;
    }

    @Override
    public String getOpName() {
        return opName;
    }

    @Override
    public void ref(TraceSegmentRef ref) {
        if (refs == null) {
            refs = new LinkedList<>();
        }
        if (!refs.contains(ref)) {
            refs.add(ref);
        }
    }

    public boolean finish(TraceSegment owner) {
        this.endTime = System.nanoTime();
        owner.archive(this);
        return true;
    }

    /**
     * 序列化可传输对象数据
     *
     * @return 序列化后的可传输对象数据
     */
    public SpanData transform() {
        SpanData spanData = new SpanData();
        spanData.setSpanId(spanId);
        spanData.setParentSpanId(parentSpanId);
        spanData.setStartTime(startTime);
        spanData.setEndTime(endTime);
        spanData.setOpName(opName);
        if (isEntry()) {
            spanData.setSpanType(SpanType.ENTRY);
        } else if (isExit()) {
            spanData.setSpanType(SpanType.EXIT);
        } else {
            spanData.setSpanType(SpanType.LOCAL);
        }
        spanData.setSpanLayer(layer);
        spanData.setComponentId(componentId);
        spanData.setError(errorOccurred);

        if (tags != null) {
            for (TagValuePair tag : tags) {
                spanData.addTag(tag.transform());
            }
        }

        if (logs != null) {
            for (LogDataEntity log : logs) {
                spanData.addLog(log.transform());
            }
        }

        if (refs != null) {
            for (TraceSegmentRef ref : refs) {
                spanData.addRef(ref.transform());
            }
        }
        return spanData;
    }

    private Object getSpanType() {
        if (isEntry()) {
            return "ENTRY";
        } else if (isExit()) {
            return "EXIT";
        } else {
            return "LOCAL";
        }
    }
}
