package com.lachesis.puma.agent.core.plugin;

import cn.hutool.core.util.StrUtil;

public class PluginDefine {

    /**
     * 插件名称
     */
    private final String name;
    /**
     * 插件定义的全类名
     */
    private final String defineClass;

    private PluginDefine(String name, String defineClass) {
        this.name = name;
        this.defineClass = defineClass;
    }

    public String getName() {
        return name;
    }

    public String getDefineClass() {
        return defineClass;
    }

    public static PluginDefine build(String define) {
        if (StrUtil.isEmpty(define)) {
            throw new RuntimeException(define);
        }

        String[] pluginDefine = define.split("=");
        if (pluginDefine.length != 2) {
            throw new RuntimeException(define);
        }
        String pluginName = pluginDefine[0];
        String defineClass = pluginDefine[1];
        return new PluginDefine(pluginName, defineClass);
    }
}

