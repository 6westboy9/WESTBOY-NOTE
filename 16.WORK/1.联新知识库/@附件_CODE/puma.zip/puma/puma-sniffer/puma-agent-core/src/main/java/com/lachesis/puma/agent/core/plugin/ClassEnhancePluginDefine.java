package com.lachesis.puma.agent.core.plugin;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.plugin.bootstrap.BootstrapInstrumentBoost;
import com.lachesis.puma.agent.core.plugin.interceptor.DeclaredInstanceMethodsInterceptPoint;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.interceptor.impl.InstanceConstructorInterceptor;
import com.lachesis.puma.agent.core.plugin.interceptor.impl.InstanceMethodInterceptor;
import com.lachesis.puma.agent.core.plugin.interceptor.impl.StaticMethodInterceptor;
import com.lachesis.puma.agent.core.plugin.interceptor.impl.StaticMethodInterceptorWithOverrideArgs;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.DynamicType;
import net.bytebuddy.implementation.FieldAccessor;
import net.bytebuddy.implementation.MethodDelegation;
import net.bytebuddy.implementation.SuperMethodCall;
import net.bytebuddy.implementation.bind.annotation.Morph;
import net.bytebuddy.jar.asm.Opcodes;
import net.bytebuddy.matcher.ElementMatcher;

import static net.bytebuddy.matcher.ElementMatchers.*;

/**
 * 所有的插件都必须直接或间接继承此类
 */
public abstract class ClassEnhancePluginDefine extends AbstractClassEnhancePluginDefine {

    /**
     * 增强静态的方法
     */
    @Override
    protected DynamicType.Builder<?> enhanceClass(TypeDescription typeDescription, DynamicType.Builder<?> builder, ClassLoader classLoader) {
        MethodsInterceptorPoint[] staticMethodsInterceptorPoints = getStaticMethodsInterceptorPoints();
        if (ArrayUtil.isEmpty(staticMethodsInterceptorPoints)) {
            return builder;
        }
        String transformClassName = typeDescription.getTypeName();
        for (MethodsInterceptorPoint staticMethodsInterceptorPoint : staticMethodsInterceptorPoints) {
            String methodsInterceptor = staticMethodsInterceptorPoint.getInterceptor();
            check(transformClassName, methodsInterceptor);
            if (staticMethodsInterceptorPoint.isOverrideArgs()) {
                if (isBootstrapInstrumentation()) {
                    // 需要覆盖参数 & 基于JDK类库的插件
                    ElementMatcher<MethodDescription> methodsMatcher = staticMethodsInterceptorPoint.getMatcher();
                    builder = builder.method(isStatic().and(methodsMatcher))
                        .intercept(MethodDelegation.withDefaultConfiguration()
                            .withBinders(Morph.Binder.install(OverrideCallable.class))
                            .to(BootstrapInstrumentBoost.forInternalDelegateClass(methodsInterceptor)));
                } else {
                    // 需要覆盖参数 & 非基于JDK类库的插件
                    ElementMatcher<MethodDescription> methodsMatcher = staticMethodsInterceptorPoint.getMatcher();
                    builder = builder.method(isStatic().and(methodsMatcher))
                        .intercept(MethodDelegation.withDefaultConfiguration()
                            .withBinders(Morph.Binder.install(OverrideCallable.class))
                            .to(new StaticMethodInterceptorWithOverrideArgs(transformClassName, methodsInterceptor, classLoader)));
                }
            } else {
                if (isBootstrapInstrumentation()) {
                    // 不需要覆盖参数 & 基于JDK类库的插件
                    ElementMatcher<MethodDescription> methodsMatcher = staticMethodsInterceptorPoint.getMatcher();
                    builder = builder.method(isStatic().and(methodsMatcher))
                        .intercept(MethodDelegation.withDefaultConfiguration()
                            .to(BootstrapInstrumentBoost.forInternalDelegateClass(methodsInterceptor)));
                } else {
                    // 不需要覆盖参数 & 非基于JDK类库的插件
                    ElementMatcher<MethodDescription> methodsMatcher = staticMethodsInterceptorPoint.getMatcher();
                    builder = builder.method(isStatic().and(methodsMatcher))
                        .intercept(MethodDelegation.withDefaultConfiguration()
                            .to(new StaticMethodInterceptor(transformClassName, methodsInterceptor, classLoader)));
                }
            }
        }
        return builder;
    }

    /**
     * 增强实例方法和构造方法
     */
    @Override
    protected DynamicType.Builder<?> enhanceInstance(TypeDescription typeDescription, DynamicType.Builder<?> builder, ClassLoader classLoader, EnhanceContext context) {
        MethodsInterceptorPoint[] constructorMethodsInterceptorPoints = getConstructorMethodsInterceptorPoints();
        MethodsInterceptorPoint[] instanceMethodsInterceptorPoints = getInstanceMethodsInterceptorPoints();
        boolean existConstructorInterceptorPoint = ArrayUtil.isNotEmpty(constructorMethodsInterceptorPoints);
        boolean existInstanceMethodInterceptorPoint = ArrayUtil.isNotEmpty(instanceMethodsInterceptorPoints);
        if (!existConstructorInterceptorPoint && !existInstanceMethodInterceptorPoint) {
            return builder;
        }

        String transformClassName = typeDescription.getTypeName();

        if (!typeDescription.isAssignableTo(EnhancedInstance.class)) {
            if (!context.isObjectExtended()) {
                builder = builder.defineField(CONTEXT_ATTR_NAME, Object.class, Opcodes.ACC_PRIVATE | Opcodes.ACC_VOLATILE)
                    .implement(EnhancedInstance.class)
                    .intercept(FieldAccessor.ofField(CONTEXT_ATTR_NAME));
                context.objectExtendedCompleted();
            }
        }

        // 1.增强构造方法
        if (existConstructorInterceptorPoint) {
            for (MethodsInterceptorPoint constructorMethodsInterceptorPoint : constructorMethodsInterceptorPoints) {
                if (isBootstrapInstrumentation()) {
                    // 基于JDK类库的插件
                    String constructorInterceptor = constructorMethodsInterceptorPoint.getInterceptor();
                    check(transformClassName, constructorInterceptor);
                    ElementMatcher<MethodDescription> constructorMatcher = constructorMethodsInterceptorPoint.getMatcher();
                    builder = builder.constructor(constructorMatcher)
                        .intercept(SuperMethodCall.INSTANCE.andThen(MethodDelegation.withDefaultConfiguration()
                            .to(BootstrapInstrumentBoost.forInternalDelegateClass(constructorMethodsInterceptorPoint.getInterceptor()))));
                } else {
                    // 非基于JDK类库的插件
                    String constructorInterceptor = constructorMethodsInterceptorPoint.getInterceptor();
                    check(transformClassName, constructorInterceptor);
                    ElementMatcher<MethodDescription> constructorMatcher = constructorMethodsInterceptorPoint.getMatcher();
                    builder = builder.constructor(constructorMatcher)
                        .intercept(SuperMethodCall.INSTANCE.andThen(MethodDelegation.withDefaultConfiguration()
                            .to(new InstanceConstructorInterceptor(transformClassName, constructorInterceptor, classLoader))));
                }
            }
        }

        // 2.增强实例方法
        if (existInstanceMethodInterceptorPoint) {
            for (MethodsInterceptorPoint instanceMethodsInterceptorPoint : instanceMethodsInterceptorPoints) {
                String methodsInterceptor = instanceMethodsInterceptorPoint.getInterceptor();
                check(transformClassName, methodsInterceptor);

                ElementMatcher<MethodDescription> methodsMatcher = instanceMethodsInterceptorPoint.getMatcher();
                ElementMatcher.Junction<MethodDescription> junction = not(isStatic().or(isAbstract())).and(methodsMatcher);
                // TODO 特殊处理
                if (instanceMethodsInterceptorPoint instanceof DeclaredInstanceMethodsInterceptPoint) {
                    junction = junction.and(isDeclaredBy(typeDescription));
                }
                if (instanceMethodsInterceptorPoint.isOverrideArgs()) {
                    if (isBootstrapInstrumentation()) {
                        builder = builder.method(junction)
                            .intercept(MethodDelegation.withDefaultConfiguration()
                                .withBinders(Morph.Binder.install(OverrideCallable.class))
                                .to(BootstrapInstrumentBoost.forInternalDelegateClass(methodsInterceptor)));
                    } else {
                        builder = builder.method(junction)
                            .intercept(MethodDelegation.withDefaultConfiguration()
                                .withBinders(Morph.Binder.install(OverrideCallable.class))
                                .to(new InstanceMethodInterceptor(transformClassName, methodsInterceptor, classLoader)));
                    }
                } else {
                    if (instanceMethodsInterceptorPoint.isOverrideArgs()) {
                        builder = builder.method(junction)
                            .intercept(MethodDelegation.withDefaultConfiguration()
                                .to(BootstrapInstrumentBoost.forInternalDelegateClass(methodsInterceptor)));
                    } else {
                        builder = builder.method(junction)
                            .intercept(MethodDelegation.withDefaultConfiguration()
                                .to(new InstanceMethodInterceptor(transformClassName, methodsInterceptor, classLoader)));
                    }
                }
            }
        }
        return builder;
    }

    private void check(String typeName, String constructorInterceptor) {
        if (StrUtil.isEmpty(constructorInterceptor) || constructorInterceptor.trim().isEmpty()) {
            throw new RuntimeException("需要增强的类[" + typeName + "]没有指定拦截器");
        }
    }
}
