package com.lachesis.puma.agent.core.print;

public class TargetClass01 {

    public void init() {
        Object o = new Object();
        int a = 10;
        o.equals(a);
    }
}
