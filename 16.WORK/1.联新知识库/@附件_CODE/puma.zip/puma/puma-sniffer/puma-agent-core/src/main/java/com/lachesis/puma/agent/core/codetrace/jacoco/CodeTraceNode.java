/*
76ce8b保密声明：当前项目源码仅授权王*博本人学习，请勿发给第三方，已添加隐形追踪水印*/
package com.lachesis.puma.agent.core.codetrace.jacoco;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class CodeTraceNode implements java.io.Serializable {

    private String id;
    private long classId;
    private String className;
    /**
     * 方法名+方法描述符
     */
    private String methodName;
    private final List<Integer> lines = new LinkedList<>();
    private int size;
    private boolean done;
    /**
     * 耗时
     */
    private Long cost;

    private Long beginTime;
    private Long finishTime;
    private CodeTraceNode parent;
    private final List<CodeTraceNode> children = new ArrayList<>(20);
    private CodeTraceSession codeTraceSession;

    public CodeTraceNode(Long classId, String className, String methodName) {
        super();
        this.classId = classId;
        this.className = className;
        this.methodName = methodName;
        size = 1;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getClassId() {
        return classId;
    }

    public void setClassId(long classId) {
        this.classId = classId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public List<Integer> getLines() {
        return lines;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public Long getCost() {
        return cost;
    }

    public void setCost(Long cost) {
        this.cost = cost;
    }

    public Long getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(Long beginTime) {
        this.beginTime = beginTime;
    }

    public Long getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Long finishTime) {
        this.finishTime = finishTime;
    }

    public CodeTraceNode getParent() {
        return parent;
    }

    public void setParent(CodeTraceNode parent) {
        this.parent = parent;
    }

    public List<CodeTraceNode> getChildren() {
        return children;
    }

    public CodeTraceSession getStackSession() {
        return codeTraceSession;
    }

    public void setStackSession(CodeTraceSession codeTraceSession) {
        this.codeTraceSession = codeTraceSession;
    }

    @Override
    public boolean equals(Object obj) {
        // 添加执行行号
        if (obj instanceof Integer) {
            if (!lines.contains(obj)) {
                lines.add((Integer) obj);
            }
            codeTraceSession.setHotStack(this);
            return false;
        }
        return super.equals(obj);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        if (id != null) {
            builder.append(id);
            builder.append(" ");
        }
        if (className != null) {
            builder.append(className);
            builder.append("#");
        }
        if (methodName != null) {
            builder.append(methodName);
        }
        // 行号
        // if (!lines.isEmpty()) {
        //     builder.append(" [");
        //     boolean firstLine = true;
        //     for (Integer line : lines) {
        //         if (firstLine) {
        //             firstLine = false;
        //         } else {
        //             builder.append(",");
        //         }
        //         builder.append(line);
        //         builder.append("L");
        //     }
        //     builder.append("] ");
        // }
        if (cost != null) {
            builder.append(String.format(" [cost=%sms]", nanosecondsToMilliseconds(cost)));
        }

        // builder.append(" :");
        // builder.append(size);
        return builder.toString();
    }

    private static String nanosecondsToMilliseconds(long nanoseconds) {
        // 1秒 = 1,000,000,000 纳秒
        double milliseconds = nanoseconds / 1_000_000.0;
        DecimalFormat df = new DecimalFormat("#.####");
        return df.format(milliseconds);
    }

    public void incrSize() {
        size++;
    }

    public void done() {
        this.done = true;
        this.finishTime = System.nanoTime();
        this.cost = finishTime - beginTime;
    }
}
