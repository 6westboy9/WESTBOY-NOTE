package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.context.TracingContext;

public class LocalSpan extends AbstractTracingSpan {

    public LocalSpan(int spanId, int parentSpanId, String opName, TracingContext owner) {
        super(spanId, parentSpanId, opName, owner);
    }

    @Override
    public boolean isEntry() {
        return false;
    }

    @Override
    public boolean isExit() {
        return false;
    }

    @Override
    public ISpan setPeer(String remotePeer) {
        return this;
    }
}
