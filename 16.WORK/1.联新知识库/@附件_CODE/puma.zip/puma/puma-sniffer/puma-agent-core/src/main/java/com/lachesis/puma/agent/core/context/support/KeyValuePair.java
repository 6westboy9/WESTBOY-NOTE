package com.lachesis.puma.agent.core.context.support;

import com.lachesis.puma.protocol.network.StrKeyValuePair;

public class KeyValuePair {

    private final String key;
    private final String value;

    public KeyValuePair(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public StrKeyValuePair transform() {
        StrKeyValuePair pair = new StrKeyValuePair();
        pair.setKey(key);
        pair.setValue(value);
        return pair;
    }
}
