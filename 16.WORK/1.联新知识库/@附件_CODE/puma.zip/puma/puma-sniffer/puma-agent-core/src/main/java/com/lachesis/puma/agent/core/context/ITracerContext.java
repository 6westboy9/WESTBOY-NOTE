package com.lachesis.puma.agent.core.context;

import com.lachesis.puma.agent.core.context.trace.ISpan;

public interface ITracerContext {

    ContextSnapshot capture();

    void continued(ContextSnapshot snapshot);

    String getSegmentId();

    int getSpanId();

    ISpan createEntrySpan(String opName);

    ISpan createLocalSpan(String opName);

    ISpan createExitSpan(String opName, String remotePeer);

    ISpan activeSpan();

    boolean stopSpan(ISpan span);

    ITracerContext awaitFinishAsync();

    void asyncStop(ISpan span);

    String getReadablePrimaryTraceId();

}
