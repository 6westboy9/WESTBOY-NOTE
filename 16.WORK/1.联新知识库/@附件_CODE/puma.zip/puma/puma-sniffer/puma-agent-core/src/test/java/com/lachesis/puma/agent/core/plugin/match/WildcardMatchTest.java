package com.lachesis.puma.agent.core.plugin.match;

import net.bytebuddy.description.type.TypeDescription;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class WildcardMatchTest {

    private static final List<String> INCLUDE_REGEX = new ArrayList<>();
    private static final List<String> EXCLUDE_REGEX = new ArrayList<>();

    static {
        INCLUDE_REGEX.add(".*Service.*");
    }

    @Test
    void testRegexMatch() {
        WildcardMatch wildcardMatch = WildcardMatch.byRegexMatch(INCLUDE_REGEX, EXCLUDE_REGEX);
        // com.lachesis.puma.agent.core.plugin.match.RegexMatchTest$TestService
        TypeDescription typeDefinition = TypeDescription.ForLoadedType.of(RegexMatchTest.TestService.class);
        Assertions.assertTrue(wildcardMatch.isMatch(typeDefinition));

        String excludeRegexExp = ".*TestService.*";
        EXCLUDE_REGEX.add(excludeRegexExp);
        wildcardMatch = WildcardMatch.byRegexMatch(INCLUDE_REGEX, EXCLUDE_REGEX);
        Assertions.assertFalse(wildcardMatch.isMatch(typeDefinition));
        EXCLUDE_REGEX.remove(excludeRegexExp);
    }

    public static class TestService {

    }
}