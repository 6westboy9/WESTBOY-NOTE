package com.lachesis.puma.agent.core.plugin.match;

/**
 * 表示要匹配哪些类的最顶层接口
 */
public interface ClassMatch {
}
