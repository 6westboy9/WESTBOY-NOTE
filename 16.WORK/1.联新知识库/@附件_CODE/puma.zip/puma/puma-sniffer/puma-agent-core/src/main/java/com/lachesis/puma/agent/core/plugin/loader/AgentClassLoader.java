package com.lachesis.puma.agent.core.plugin.loader;

import cn.hutool.core.util.ArrayUtil;
import com.lachesis.puma.agent.core.AgentConstants;
import com.lachesis.puma.agent.core.boot.AgentPackagePath;
import com.lachesis.puma.agent.core.boot.PluginConfig;
import com.lachesis.puma.agent.core.boot.SnifferConfigInitializer;
import com.lachesis.puma.agent.core.plugin.PluginBootstrap;
import com.lachesis.puma.agent.core.util.IOUtil;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class AgentClassLoader extends ClassLoader {

    static {
        // 开启并行类加载器
        registerAsParallelCapable();
    }

    /**
     * 用于加载插件的定义相关的类，如MysqlInstrumentation
     * <p>
     * 除了插件拦截器之外
     */
    private static AgentClassLoader DEFAULT_LOADER;
    /**
     * 自定义类加载器加载类的路径
     */
    private final List<File> classpath;
    private volatile List<Jar> allJars;

    public AgentClassLoader(ClassLoader parent) {
        super(parent);
        File agentJarDir = AgentPackagePath.getPath();
        classpath = new LinkedList<>();
        classpath.add(new File(agentJarDir, AgentConstants.PLUGIN_PACKAGE_NAME));
    }

    public static AgentClassLoader getDefault() {
        return DEFAULT_LOADER;
    }

    public static void initDefaultLoader() {
        if (DEFAULT_LOADER == null) {
            ClassLoader classLoader = PluginBootstrap.class.getClassLoader();
            DEFAULT_LOADER = new AgentClassLoader(classLoader);
            InterceptorLoader.register(DEFAULT_LOADER, classLoader);
        }
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        List<Jar> allJars = getAllJars();
        String path = name.replace(".", "/").concat(".class");
        for (Jar jar : allJars) {
            JarEntry jarEntry = jar.jarFile.getJarEntry(path);
            if (jarEntry == null) {
                continue;
            }
            try {
                URL url = new URL("jar:file:" + jar.sourceFile.getAbsolutePath() + "!/" + path);
                byte[] bytes = IOUtil.toByteArray(url);
                Class<?> loadedClass = defineClass(name, bytes, 0, bytes.length);
                return processLoadedClass(loadedClass);
            } catch (Exception e) {
                LogUtil.error(e, String.format("查找class文件异常:%s", name));
            }
        }
        throw new ClassNotFoundException(name);
    }

    /**
     * 初始化插件配置
     * @param loadedClass
     * @return
     */
    private Class<?> processLoadedClass(Class<?> loadedClass) {
        PluginConfig pluginConfig = loadedClass.getAnnotation(PluginConfig.class);
        if (pluginConfig != null) {
            SnifferConfigInitializer.initializeConfig(pluginConfig.root());
        }
        return loadedClass;
    }

    @Override
    public URL findResource(String name) {
        List<Jar> allJars = getAllJars();
        for (Jar jar : allJars) {
            JarEntry jarEntry = jar.jarFile.getJarEntry(name);
            if (jarEntry != null) {
                try {
                    return new URL("jar:file:" + jar.sourceFile.getAbsolutePath() + "!/" + name);
                } catch (MalformedURLException e) {
                    LogUtil.error(e, String.format("获取资源文件异常:%s", name));
                }
            }
        }
        return null;
    }

    @Override
    public Enumeration<URL> getResources(String name) throws IOException {
        List<URL> allResources = new LinkedList<>();
        List<Jar> allJars = getAllJars();
        for (Jar jar : allJars) {
            JarEntry jarEntry = jar.jarFile.getJarEntry(name);
            if (jarEntry != null) {
                allResources.add(new URL("jar:file:" + jar.sourceFile.getAbsolutePath() + "!/" + name));
            }
        }

        Iterator<URL> iterator = allResources.iterator();

        return new Enumeration<URL>() {
            @Override
            public boolean hasMoreElements() {
                return iterator.hasNext();
            }

            @Override
            public URL nextElement() {
                return iterator.next();
            }
        };
    }

    private List<Jar> getAllJars() {
        if (allJars == null) {
            synchronized (this) {
                if (allJars == null) {
                    allJars = doGetAllJars();
                }
            }
        }
        return allJars;
    }

    private List<Jar> doGetAllJars() {
        List<Jar> list = new LinkedList<>();
        for (File path : classpath) {
            if (path.exists() && path.isDirectory()) {
                String[] jarFileNames = path.list((dir, name) -> name.endsWith(".jar"));
                if (ArrayUtil.isEmpty(jarFileNames)) {
                    continue;
                }
                for (String jarFileName : jarFileNames) {
                    try {
                        File jarSourceFile = new File(path, jarFileName);
                        Jar jar = new Jar(new JarFile(jarSourceFile), jarSourceFile);
                        list.add(jar);
                        LogUtil.info(String.format("已加载:%s", jarSourceFile.getAbsolutePath()));
                    } catch (Exception e) {
                        LogUtil.error(e, String.format("加载文件失败:%s", jarFileName));
                    }
                }
            }
        }
        return list;
    }

    private static class Jar {
        /**
         * jar文件对应的jarFile对象
         */
        private final JarFile jarFile;
        /**
         * jar文件对象
         */
        private final File sourceFile;

        public Jar(JarFile jarFile, File sourceFile) {
            this.jarFile = jarFile;
            this.sourceFile = sourceFile;
        }
    }
}
