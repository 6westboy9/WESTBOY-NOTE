package com.lachesis.puma.agent.core.plugin.interceptor;

import java.lang.reflect.Method;

/**
 * 静态方法拦截器必须实现这个接口
 */
public interface StaticMethodsAroundInterceptor {

    void beforeMethod(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes);

    Object afterMethod(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result);

    void handleEx(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t);

}
