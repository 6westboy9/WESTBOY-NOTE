/*******************************************************************************
 * Copyright (c) 2009, 2023 Mountainminds GmbH & Co. KG and Contributors
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *    Marc R. Hoffmann - initial API and implementation
 *
 *******************************************************************************/
package com.lachesis.puma.agent.core.codetrace.jacoco.flow;

import com.lachesis.puma.agent.core.codetrace.jacoco.instr.InstrSupport;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.commons.AnalyzerAdapter;

import java.util.HashMap;
import java.util.Map;

/**
 * Adapter that creates additional visitor events for probes to be inserted into
 * a method.
 */
public class MethodProbesAdapter extends MethodVisitor {

    private final MethodProbesVisitor probesVisitor;

    private final IProbeIdGenerator idGenerator;

    private AnalyzerAdapter analyzer;

    private final Map<Label, Label> tryCatchProbeLabels;

    /**
     * Create a new adapter instance.
     *
     * @param probesVisitor visitor to delegate to
     * @param idGenerator   generator for unique probe ids
     */
    public MethodProbesAdapter(MethodProbesVisitor probesVisitor, IProbeIdGenerator idGenerator) {
        super(InstrSupport.ASM_API_VERSION, probesVisitor);
        this.probesVisitor = probesVisitor;
        this.idGenerator = idGenerator;
        this.tryCatchProbeLabels = new HashMap<>();
    }

    /**
     * If an analyzer is set {@link IFrame} handles are calculated and emitted
     * to the probes methods.
     *
     * @param analyzer optional analyzer to set
     */
    public void setAnalyzer(AnalyzerAdapter analyzer) {
        this.analyzer = analyzer;
    }

    @Override
    public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
        probesVisitor.visitTryCatchBlock(getTryCatchLabel(start), getTryCatchLabel(end), handler, type);
    }

    private Label getTryCatchLabel(Label label) {
        if (tryCatchProbeLabels.containsKey(label)) {
            label = tryCatchProbeLabels.get(label);
        } else if (LabelInfo.needsProbe(label)) {
            // If a probe will be inserted before the label, we'll need to use a
            // different label to define the range of the try-catch block.
            Label probeLabel = new Label();
            LabelInfo.setSuccessor(probeLabel);
            tryCatchProbeLabels.put(label, probeLabel);
            label = probeLabel;
        }
        return label;
    }

    @Override
    public void visitLabel(Label label) {
        if (LabelInfo.needsProbe(label)) {
            if (tryCatchProbeLabels.containsKey(label)) {
                probesVisitor.visitLabel(tryCatchProbeLabels.get(label));
            }
            probesVisitor.visitProbe(idGenerator.nextId(), "visitLabel");
        }
        probesVisitor.visitLabel(label);
    }

    @Override
    public void visitInsn(int opcode) {
        switch (opcode) {
            case Opcodes.IRETURN:
            case Opcodes.LRETURN:
            case Opcodes.FRETURN:
            case Opcodes.DRETURN:
            case Opcodes.ARETURN:
            case Opcodes.RETURN:
            case Opcodes.ATHROW:
                probesVisitor.visitInsnWithProbe(opcode, idGenerator.nextId(), "visitInsn");
                break;
            default:
                probesVisitor.visitInsnWithProbe(opcode, idGenerator.nextId(), "visitInsn");
                // probesVisitor.visitInsn(opcode);
                break;
        }
    }

    @Override
    public void visitIntInsn(int opcode, int operand) {
        probesVisitor.visitIntInsnWithProbe(opcode, operand, idGenerator.nextId(), "visitIntInsn");
    }

    @Override
    public void visitJumpInsn(int opcode, Label label) {
        if (LabelInfo.isMultiTarget(label)) {
            probesVisitor.visitJumpInsnWithProbe(opcode, label, idGenerator.nextId(), frame(jumpPopCount(opcode)), "visitJumpInsn");
        } else {
            probesVisitor.visitJumpInsn(opcode, label);
        }
    }

    private int jumpPopCount(int opcode) {
        switch (opcode) {
            case Opcodes.GOTO:
                return 0;
            case Opcodes.IFEQ:
            case Opcodes.IFNE:
            case Opcodes.IFLT:
            case Opcodes.IFGE:
            case Opcodes.IFGT:
            case Opcodes.IFLE:
            case Opcodes.IFNULL:
            case Opcodes.IFNONNULL:
                return 1;
            default: // IF_CMPxx and IF_ACMPxx
                return 2;
        }
    }

    @Override
    public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
        if (markLabels(dflt, labels)) {
            probesVisitor.visitLookupSwitchInsnWithProbes(dflt, keys, labels, frame(1), "visitLookupSwitchInsn");
        } else {
            probesVisitor.visitLookupSwitchInsn(dflt, keys, labels);
        }
    }

    @Override
    public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
        if (markLabels(dflt, labels)) {
            probesVisitor.visitTableSwitchInsnWithProbes(min, max, dflt, labels, frame(1), "visitTableSwitchInsn");
        } else {
            probesVisitor.visitTableSwitchInsn(min, max, dflt, labels);
        }
    }

    private boolean markLabels(Label dflt, Label[] labels) {
        boolean probe = false;
        LabelInfo.resetDone(labels);
        if (LabelInfo.isMultiTarget(dflt)) {
            LabelInfo.setProbeId(dflt, idGenerator.nextId());
            probe = true;
        }
        LabelInfo.setDone(dflt);
        for (Label l : labels) {
            if (LabelInfo.isMultiTarget(l) && !LabelInfo.isDone(l)) {
                LabelInfo.setProbeId(l, idGenerator.nextId());
                probe = true;
            }
            LabelInfo.setDone(l);
        }
        return probe;
    }

    private IFrame frame(int popCount) {
        return FrameSnapshot.create(analyzer, popCount);
    }

}
