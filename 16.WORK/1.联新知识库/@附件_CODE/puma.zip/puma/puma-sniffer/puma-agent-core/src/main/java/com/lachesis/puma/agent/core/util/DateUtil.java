package com.lachesis.puma.agent.core.util;

import java.text.DecimalFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class DateUtil {

    public static String nanoToMill(long nanoseconds) {
        // 1秒 = 1,000,000,000 纳秒
        double milliseconds = nanoseconds / 1_000_000.0;
        DecimalFormat df = new DecimalFormat("#.####");
        return df.format(milliseconds);
    }

    public static String nowStr() {
        long timestamp = System.currentTimeMillis();
        Instant instant = Instant.ofEpochMilli(timestamp);
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
        return localDateTime.format(formatter);
    }
}
