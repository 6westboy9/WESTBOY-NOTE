package com.lachesis.puma.agent.core.plugin;

import cn.hutool.core.collection.CollUtil;
import com.lachesis.puma.agent.core.plugin.loader.AgentClassLoader;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PluginBootstrap {

    public static List<AbstractClassEnhancePluginDefine> loadPluginDefines() {
        AgentClassLoader.initDefaultLoader();
        List<URL> resources = PluginResourcesResolver.getResources();
        if (CollUtil.isEmpty(resources)) {
            LogUtil.info("插件定义配置为空");
            return Collections.emptyList();
        }

        for (URL resource : resources) {
            try {
                PluginConfig.INSTANCE.load(resource.openStream());
            } catch (Exception e) {
                LogUtil.error(e, String.format("插件定义配置文件加载异常:%s", resource));
            }
        }

        List<PluginDefine> pluginDefines = PluginConfig.INSTANCE.getPluginDefines();
        if (CollUtil.isEmpty(pluginDefines)) {
            LogUtil.info("插件定义配置文件集合为空");
            return Collections.emptyList();
        }

        List<AbstractClassEnhancePluginDefine> plugins = new ArrayList<>();
        for (PluginDefine pluginDefine : pluginDefines) {
            try {
                Class<?> clazz = Class.forName(pluginDefine.getDefineClass(), true, AgentClassLoader.getDefault());
                AbstractClassEnhancePluginDefine plugin = (AbstractClassEnhancePluginDefine) clazz.newInstance();
                plugins.add(plugin);
            } catch (Exception e) {
                LogUtil.error(e, String.format("插件定义类加载异常:%s", pluginDefine.getDefineClass()));
            }
        }
        return plugins;
    }

}
