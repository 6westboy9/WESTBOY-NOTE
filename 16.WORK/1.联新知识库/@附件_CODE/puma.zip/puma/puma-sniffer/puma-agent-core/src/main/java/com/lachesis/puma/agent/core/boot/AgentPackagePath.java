package com.lachesis.puma.agent.core.boot;

import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.AgentConstants;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.io.File;
import java.net.URL;

public class AgentPackagePath {

    private static File AGENT_PACKAGE_PATH;

    public static File getPath() {
        if (AGENT_PACKAGE_PATH == null) {
            AGENT_PACKAGE_PATH = findPath();
        }
        return AGENT_PACKAGE_PATH;
    }

    /**
     * 获取agent所在目录的File对象
     */
    private static File findPath() {
        String classResourcePath = AgentPackagePath.class.getName().replaceAll("\\.", "/") + ".class";
        URL resource = ClassLoader.getSystemClassLoader().getResource(classResourcePath);
        if (resource != null) {
            String urlString = resource.toString();
            boolean isInJar = urlString.indexOf('!') > -1;
            if (isInJar) {
                urlString = StrUtil.subBetween(urlString, "file:", "!");
                // urlString = StringUtil.substringBetween(urlString, "file:", "!");
                File agentJarFile = null;
                try {
                    agentJarFile = new File(urlString);
                } catch (Exception e) {
                    LogUtil.error(e, String.format("获取%s所在目录的File对象异常:%s", AgentConstants.AGENT_JAR, urlString));
                }
                if (agentJarFile != null && agentJarFile.exists()) {
                    return agentJarFile.getParentFile();
                }
            }
        }
        throw new RuntimeException(String.format("获取%s所在目录的File对象失败", AgentConstants.AGENT_JAR));
    }

}
