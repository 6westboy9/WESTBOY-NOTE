/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.lachesis.puma.agent.core.boot;

import cn.hutool.core.util.StrUtil;

import java.util.*;

public enum PropertyPlaceholderHelper {

    INSTANCE(
        PlaceholderConfigurerSupport.DEFAULT_PLACEHOLDER_PREFIX,
        PlaceholderConfigurerSupport.DEFAULT_PLACEHOLDER_SUFFIX,
        PlaceholderConfigurerSupport.DEFAULT_VALUE_SEPARATOR,
        true
    );

    private final String placeholderPrefix;

    private final String placeholderSuffix;

    private final String simplePrefix;

    private final String valueSeparator;

    private final boolean ignoreUnresolvablePlaceholders;

    PropertyPlaceholderHelper(String placeholderPrefix, String placeholderSuffix, String valueSeparator, boolean ignoreUnresolvablePlaceholders) {
        if (StrUtil.isEmpty(placeholderPrefix) || StrUtil.isEmpty(placeholderSuffix)) {
            throw new UnsupportedOperationException("[placeholderPrefix或placeholderSuffix]参数不能为空");
        }

        Map<String, String> wellKnownSimplePrefixes = new HashMap<>(4);
        wellKnownSimplePrefixes.put("}", "{");
        wellKnownSimplePrefixes.put("]", "[");
        wellKnownSimplePrefixes.put(")", "(");

        // ${
        this.placeholderPrefix = placeholderPrefix;
        // }
        this.placeholderSuffix = placeholderSuffix;
        String simplePrefixForSuffix = wellKnownSimplePrefixes.get(this.placeholderSuffix);
        if (simplePrefixForSuffix != null && this.placeholderPrefix.endsWith(simplePrefixForSuffix)) {
            this.simplePrefix = simplePrefixForSuffix;
        } else {
            this.simplePrefix = this.placeholderPrefix;
        }
        this.valueSeparator = valueSeparator;
        this.ignoreUnresolvablePlaceholders = ignoreUnresolvablePlaceholders;
    }

    public String replacePlaceholders(String value, Properties properties) {
        return replacePlaceholders(value, placeholderName -> getConfigValue(placeholderName, properties));
    }

    private String getConfigValue(String key, Properties properties) {
        String value = System.getProperty(key);
        if (value == null) {
            value = System.getenv(key);
        }
        if (value == null) {
            value = properties.getProperty(key);
        }
        return value;
    }

    public String replacePlaceholders(String value, PlaceholderResolver placeholderResolver) {
        return parseStringValue(value, placeholderResolver, new HashSet<>());
    }

    /**
     * 解析配置项示例：`agent.service_name=${AGENT_NAME:one}`
     *
     * @param value               参考示例，这里的value=`${AGENT_NAME:one}`
     * @param placeholderResolver 占位符解析器，根据key进行值获取，默认先从系统环境变量中获取，再从AGENT_SETTINGS中获取，这里的key=agent.service_name
     * @param visitedPlaceholders 已经遍历过的占位符，用于判断是否存在循环引用的情况
     * @return 配置项的值，可能存在占位符嵌套的情况
     */
    private String parseStringValue(String value, PlaceholderResolver placeholderResolver, Set<String> visitedPlaceholders) {
        StringBuilder result = new StringBuilder(value);
        int startIndex = value.indexOf(placeholderPrefix);
        while (startIndex != -1) {
            int endIndex = findPlaceholderEndIndex(result, startIndex);
            if (endIndex != -1) {
                String placeholder = result.substring(startIndex + placeholderPrefix.length(), endIndex);
                String originalPlaceholder = placeholder;
                // 比如a=${b},b=${a}此时存在占位符循环引用的情况
                if (!visitedPlaceholders.add(originalPlaceholder)) {
                    throw new IllegalArgumentException("存在占位符循环引用[" + originalPlaceholder + "]");
                }
                // 存在占位符
                placeholder = parseStringValue(placeholder, placeholderResolver, visitedPlaceholders);
                // 解析结果存在两种情况：1.指向其他配置项的占位符；2.非占位符
                String propVal = placeholderResolver.resolvePlaceholder(placeholder);
                if (propVal == null && valueSeparator != null) {
                    // 非占位符时，且存在':'分隔符
                    int separatorIndex = placeholder.indexOf(valueSeparator);
                    if (separatorIndex != -1) {
                        // 比如:propVal=PUMA_AGENT_NAME:one，此时actualPlaceholder=PUMA_AGENT_NAME，defaultValue=one
                        // 再次通过key=PUMA_AGENT_NAME去解析一次，如果有值，则取该值，否则，取默认值
                        // 思考：为什么要使用PUMA_AGENT_NAME去解析一次呢？这里主要是考虑操作系统/Docker/K8s层面的环境变量配置
                        String actualPlaceholder = placeholder.substring(0, separatorIndex);
                        String defaultValue = placeholder.substring(separatorIndex + valueSeparator.length());
                        propVal = placeholderResolver.resolvePlaceholder(actualPlaceholder);
                        if (propVal == null) {
                            propVal = defaultValue;
                        }
                    }
                }
                if (propVal != null) {
                    // 递归调用，解析先前解析的占位符值中包含的占位符
                    // 比如a=1，b=${a}，c=${b}，当前propVal==${b}
                    propVal = parseStringValue(propVal, placeholderResolver, visitedPlaceholders);
                    result.replace(startIndex, endIndex + placeholderSuffix.length(), propVal);
                    startIndex = result.indexOf(placeholderPrefix, startIndex + propVal.length());
                } else if (ignoreUnresolvablePlaceholders) {
                    startIndex = result.indexOf(placeholderPrefix, endIndex + placeholderSuffix.length());
                } else {
                    throw new IllegalArgumentException("属性值=[" + value + "]存在无法解析的占位符[" + placeholder + "]");
                }
                visitedPlaceholders.remove(originalPlaceholder);
            } else {
                startIndex = -1;
            }
        }
        return result.toString();
    }

    private int findPlaceholderEndIndex(CharSequence buf, int startIndex) {
        int index = startIndex + placeholderPrefix.length();
        int withinNestedPlaceholder = 0;
        while (index < buf.length()) {
            if (substringMatch(buf, index, placeholderSuffix)) {
                if (withinNestedPlaceholder > 0) {
                    withinNestedPlaceholder--;
                    index = index + placeholderSuffix.length();
                } else {
                    return index;
                }
            } else if (substringMatch(buf, index, simplePrefix)) {
                withinNestedPlaceholder++;
                index = index + simplePrefix.length();
            } else {
                index++;
            }
        }
        return -1;
    }

    public boolean substringMatch(CharSequence str, int index, CharSequence substring) {
        if (index + substring.length() > str.length()) {
            return false;
        }
        for (int i = 0; i < substring.length(); i++) {
            if (str.charAt(index + i) != substring.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 提供的一种解析配置的扩展策略接口
     */
    public interface PlaceholderResolver {
        String resolvePlaceholder(String placeholderName);
    }
}
