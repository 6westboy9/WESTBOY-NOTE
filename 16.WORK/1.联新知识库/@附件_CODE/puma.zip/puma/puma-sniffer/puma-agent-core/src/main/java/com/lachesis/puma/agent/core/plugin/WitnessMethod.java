package com.lachesis.puma.agent.core.plugin;

public class WitnessMethod {
}
