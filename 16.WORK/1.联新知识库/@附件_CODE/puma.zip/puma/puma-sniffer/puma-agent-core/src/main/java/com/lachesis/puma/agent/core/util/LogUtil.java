package com.lachesis.puma.agent.core.util;

import java.io.PrintStream;

public class LogUtil {

    private static final String TAG = "[PUMA]";
    private static final PrintStream INFO;
    private static final PrintStream ERROR;

    static {
        INFO = System.out;
        ERROR = System.err;
    }

    public static void info(String msg) {
        info(true, msg);
    }

    public static void info(boolean framework, String msg) {
        String threadInfo = Thread.currentThread().toString();
        if (threadInfo.contains("HikariPool-1")) {
            return;
        }
        String tag = framework ? "@@@" : "###";
        String infoMsg = String.format("%s %s [%-25s] %s %s", DateUtil.nowStr(), TAG, Thread.currentThread().getName(), tag, msg);
        INFO.println(infoMsg);
    }

    public static void error(Throwable throwable, String msg) {
        error(throwable, true, msg);
    }

    public static void error(Throwable throwable, boolean framework, String msg) {
        String tag = framework ? "@@@" : "###";
        String errorMsg = String.format("%s %s [%-25s] %s %s", DateUtil.nowStr(), TAG, Thread.currentThread().getName(), tag, msg);
        ERROR.println(errorMsg);
        throwable.printStackTrace();
    }
}
