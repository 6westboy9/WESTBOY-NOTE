package com.lachesis.puma.agent.core.plugin.interceptor.impl;

import com.lachesis.puma.agent.core.boot.Config;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.loader.InterceptorLoader;
import com.lachesis.puma.agent.core.util.LogUtil;
import net.bytebuddy.implementation.bind.annotation.AllArguments;
import net.bytebuddy.implementation.bind.annotation.Origin;
import net.bytebuddy.implementation.bind.annotation.RuntimeType;
import net.bytebuddy.implementation.bind.annotation.This;

import java.lang.reflect.Constructor;
import java.util.Arrays;

public class InstanceConstructorInterceptor {

    private static final String TAG = "[构造方法]";
    private String transformClassName;
    private com.lachesis.puma.agent.core.plugin.interceptor.InstanceConstructorInterceptor interceptor;

    public InstanceConstructorInterceptor(String transformClassName, String interceptorClass, ClassLoader classLoader) {
        try {
            // LogUtil.info(String.format("加载构造方法拦截器[%s]增强:%s", interceptorClass, transformClassName));
            this.transformClassName = transformClassName;
            interceptor = InterceptorLoader.load(interceptorClass, classLoader);
        } catch (Throwable t) {
            LogUtil.error(t, String.format("加载构造方法拦截器[%s]异常", interceptorClass));
        }
    }

    @RuntimeType
    public void intercept(@This Object obj, @Origin Constructor<?> constructor, @AllArguments Object[] arguments) {
        try {
            // LogUtil.info(String.format("%-30s 结束%s:%s", transformClassName, TAG, Arrays.toString(arguments)));
            EnhancedInstance instance = (EnhancedInstance) obj;
            interceptor.onConstruct(instance, constructor, arguments);
        } catch (Throwable t) {
            LogUtil.error(t, String.format("%-30s 结束(增强处理异常)%s:", transformClassName, TAG));
        }
    }
}
