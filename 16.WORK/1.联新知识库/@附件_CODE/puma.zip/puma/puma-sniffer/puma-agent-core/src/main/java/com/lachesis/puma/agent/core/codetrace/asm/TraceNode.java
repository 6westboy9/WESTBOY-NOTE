package com.lachesis.puma.agent.core.codetrace.asm;

import cn.hutool.json.JSONUtil;
import com.lachesis.puma.agent.core.util.DateUtil;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class TraceNode {

    private String id;
    private MethodInfo methodInfo;
    private int size;
    private long beforeTime = -1;
    private long afterTime = -1;
    private long cost = -1;

    private TraceNode parent;
    private final Map<String, TraceNode> childMap = new LinkedHashMap<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public MethodInfo getMethodInfo() {
        return methodInfo;
    }

    public void setMethodInfo(MethodInfo methodInfo) {
        this.methodInfo = methodInfo;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void incrSize() {
        this.size++;
    }

    public long getBeforeTime() {
        return beforeTime;
    }

    public void setBeforeTime(long beforeTime) {
        this.beforeTime = beforeTime;
    }

    public long getAfterTime() {
        return afterTime;
    }

    public void setAfterTime(long afterTime) {
        this.afterTime = afterTime;
    }

    public long getCost() {
        return cost;
    }

    public void setCost(long cost) {
        this.cost = cost;
    }

    public TraceNode getParent() {
        return parent;
    }

    public void setParent(TraceNode parent) {
        this.parent = parent;
    }

    public boolean containsChild(String mk) {
        return childMap.containsKey(mk);
    }

    public int childrenSize() {
        return childMap.size();
    }

    public void addChild(TraceNode node) {
        childMap.put(node.getMethodInfo().identifier(), node);
    }

    public Collection<TraceNode> getChildren() {
        return childMap.values();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(id);
        builder.append("|CLASS:");
        builder.append(methodInfo.getClassName());
        builder.append("|METHOD:");
        builder.append(methodInfo.getMethodName());
        builder.append(methodInfo.getDescriptor());
        builder.append("|PARAMS:");
        builder.append(JSONUtil.toJsonStr(methodInfo.getParams()));
        builder.append("|RETURN:");
        builder.append(JSONUtil.toJsonStr(methodInfo.getReturnValue()));
        if (cost != -1) {
            builder.append(String.format(" [cost=%sms]", DateUtil.nanoToMill(cost)));
        }
        return builder.toString();
    }
}