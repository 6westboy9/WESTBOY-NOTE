package com.lachesis.puma.agent.core.plugin.match;

import cn.hutool.core.util.ArrayUtil;
import net.bytebuddy.description.annotation.AnnotationDescription;
import net.bytebuddy.description.annotation.AnnotationList;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static net.bytebuddy.matcher.ElementMatchers.*;

public class ClassAnnotationMatch implements IndirectMatch {

    private final List<String> annotations;

    public ClassAnnotationMatch(String... annotations) {
        if (ArrayUtil.isEmpty(annotations)) {
            throw new IllegalArgumentException("参数不能为空");
        }
        this.annotations = Arrays.asList(annotations);
    }

    public static IndirectMatch byClassAnnotationMatch(String... annotations) {
        return new ClassAnnotationMatch(annotations);
    }

    @Override
    public ElementMatcher.Junction<? super TypeDescription> buildJunction() {
        ElementMatcher.Junction<? super TypeDescription> junction = null;
        for (String anno : annotations) {
            if (junction == null) {
                junction = buildEachAnno(anno);
            } else {
                junction = junction.and(buildEachAnno(anno));
            }
        }
        if (junction != null) {
            junction = junction.and(not(isInterface()));
        }
        return junction;
    }

    @Override
    public boolean isMatch(TypeDescription typeDescription) {
        ArrayList<String> annotationList = new ArrayList<>(annotations);
        // 获取注解列表
        AnnotationList declaredAnnotations = typeDescription.getDeclaredAnnotations();
        for (AnnotationDescription declaredAnnotation : declaredAnnotations) {
            // 获取注解的全限定名
            String actualName = declaredAnnotation.getAnnotationType().getActualName();
            annotationList.remove(actualName);
        }
        // 说明需要满足所有注解条件
        return annotationList.isEmpty();
    }

    private ElementMatcher.Junction<TypeDescription> buildEachAnno(String anno) {
        return isAnnotatedWith(named(anno));
    }
}
