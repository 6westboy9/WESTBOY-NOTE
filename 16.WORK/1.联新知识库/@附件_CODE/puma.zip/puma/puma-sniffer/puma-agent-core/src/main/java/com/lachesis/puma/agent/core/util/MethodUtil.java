package com.lachesis.puma.agent.core.util;

import java.lang.reflect.Method;

public class MethodUtil {

    public static boolean isMethodExist(ClassLoader classLoader, String className, String methodName,
                                        String... parameterTypes) {
        try {
            Class<?> clazz = Class.forName(className, true, classLoader);
            if (parameterTypes == null || parameterTypes.length == 0) {
                clazz.getDeclaredMethod(methodName);
                return true;
            } else {
                Method[] declaredMethods = clazz.getDeclaredMethods();
                for (Method declaredMethod : declaredMethods) {
                    if (declaredMethod.getName().equals(methodName)
                        && isParameterTypesEquals(declaredMethod.getParameterTypes(), parameterTypes)) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            //ignore
        }
        return false;
    }

    private static boolean isParameterTypesEquals(Class<?>[] parameterTypeClazz, String[] parameterTypeString) {
        if (parameterTypeClazz == null) {
            return false;
        }
        if (parameterTypeClazz.length != parameterTypeString.length) {
            return false;
        }
        for (int i = 0; i < parameterTypeClazz.length; i++) {
            if (!parameterTypeClazz[i].getName().equals(parameterTypeString[i])) {
                return false;
            }
        }
        return true;
    }
}
