package com.lachesis.puma.agent.core.plugin;

public interface OverrideCallable {
    Object call(Object[] args);
}
