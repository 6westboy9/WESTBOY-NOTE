package com.lachesis.puma.agent.core.plugin;

import java.lang.reflect.Field;

@SuppressWarnings("unchecked")
public class BootstrapInterceptorRuntimeAssist {

    private static final String AGENT_CLASSLOADER_DEFAULT = "com.lachesis.puma.agent.core.plugin.loader.AgentClassLoader";
    private static final String DEFAULT_AGENT_CLASSLOADER_INSTANCE = "DEFAULT_LOADER";

    public static ClassLoader getAgentClassLoader() {
        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            if (loader == null) {
                return null;
            }
            // 需要通过放射的方式获取，调用此方法的类是由BootstrapClassLoader加载的，是无法直接访问AgentClassLoader的
            Class<?> agentClassLoaderClass = Class.forName(AGENT_CLASSLOADER_DEFAULT, true, loader);
            Field defaultLoaderField = agentClassLoaderClass.getDeclaredField(DEFAULT_AGENT_CLASSLOADER_INSTANCE);
            defaultLoaderField.setAccessible(true);
            return (ClassLoader) defaultLoaderField.get(null);
        } catch (Exception e) {
            // 暂时先通过控制台打印
            e.printStackTrace();
            return null;
        }
    }

    public static <T> T createInterceptor(ClassLoader classLoader, String interceptorClassName) {
        try {
            Class<?> interceptorClass = Class.forName(interceptorClassName, true, classLoader);
            return (T) interceptorClass.newInstance();
        } catch (Exception e) {
            // 暂时先通过控制台打印
            e.printStackTrace();
            return null;
        }
    }
}
