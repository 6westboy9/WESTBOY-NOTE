package com.lachesis.puma.agent.core.plugin.interceptor;

/**
 * 这个接口是为那些只想在出现一些意外问题的情况下增强声明方法设计的，比如Spring Controller
 */
public interface DeclaredInstanceMethodsInterceptPoint extends MethodsInterceptorPoint {
}
