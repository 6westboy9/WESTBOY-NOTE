package com.lachesis.puma.agent.core.codetrace;

import cn.hutool.core.io.IoUtil;
import com.lachesis.puma.agent.core.codetrace.jacoco.CodeTraceSession;
import com.lachesis.puma.agent.core.codetrace.jacoco.CodeTraceTransformer;
import com.lachesis.puma.agent.core.codetrace.samples.UserQuery;
import com.lachesis.puma.agent.core.codetrace.samples.UserServiceImpl;
import javassist.ByteArrayClassPath;
import javassist.ClassPool;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.security.ProtectionDomain;

class CodeTraceTransformerTest {

    private final CodeTraceTransformer codeTraceTransformer = new CodeTraceTransformer(0);
    private final String className = "com.lachesis.puma.agent.core.codetrace.samples.UserServiceImpl";
    private final String sessionBeginClass = "com/lachesis/puma/agent/core/codetrace/CodeTraceTransformerTest";
    private final String sessionBeginMethod = "transformTest";
    private byte[] newBytes;

    @BeforeEach
    void before() {
        ClassLoader classLoader = getClass().getClassLoader();
        ProtectionDomain domain = CodeTraceTransformerTest.class.getProtectionDomain();
        InputStream inputStream = getClass().getResourceAsStream("/com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl.class");
        byte[] bytes = IoUtil.readBytes(inputStream);
        newBytes = codeTraceTransformer.transform(classLoader, className, null, domain, bytes);
    }

    private void loadClass() throws Exception {
        ClassPool pool = new ClassPool();
        pool.insertClassPath(new ByteArrayClassPath(className, newBytes));
        pool.get(className).writeFile(System.getProperty("user.dir") + "/target");
        pool.get(className).toClass();
    }

    @Test
    void transformTest_generate() {

    }

    @Test
    void transformTest_getUser() throws Exception {
        loadClass();
        CodeTraceSession session = new CodeTraceSession(sessionBeginClass, sessionBeginMethod);
        new UserServiceImpl().getUser();
        session.close();
        session.printStack(System.out);
    }

    @Test
    void transformTest_listUser() throws Exception {
        loadClass();
        CodeTraceSession session = new CodeTraceSession(sessionBeginClass, sessionBeginMethod);
        new UserServiceImpl().listUser();
        session.close();
        session.printStack(System.out);
    }

    @Test
    void transformTest_listUserByCondition() throws Exception {
        loadClass();
        CodeTraceSession session = new CodeTraceSession(sessionBeginClass, sessionBeginMethod);
        new UserServiceImpl().listUser("xw", 18);
        session.close();
        session.printStack(System.out);
    }

    @Test
    void transformTest_listUserByConditionV2() throws Exception {
        loadClass();
        CodeTraceSession session = new CodeTraceSession(sessionBeginClass, sessionBeginMethod);
        UserQuery query = new UserQuery();
        query.setName("xw");
        query.setAge(10);
        new UserServiceImpl().listUser(query);
        session.close();
        session.printStack(System.out);
    }

    @Test
    void transformTest_test() throws Exception {
        loadClass();
        CodeTraceSession session = new CodeTraceSession(sessionBeginClass, sessionBeginMethod);
        new UserServiceImpl().test();
        session.close();
        session.printStack(System.out);
    }

    @Test
    void transformTest_testAsync() throws Exception {
        loadClass();
        CodeTraceSession session = new CodeTraceSession(sessionBeginClass, sessionBeginMethod);
        new UserServiceImpl().testAsync();
        session.close();
        session.printStack(System.out);
    }
}