package com.lachesis.puma.agent.core.context;

import com.lachesis.puma.agent.core.context.trace.ISpan;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.util.Objects;

public class ContextManager {

    private static final String EMPTY_TRACE_CONTEXT_ID = "N/A";
    private static final ThreadLocal<TracingContext> CONTEXT = new ThreadLocal<>();

    private static TracingContext getOrCreate() {
        TracingContext context = CONTEXT.get();
        if (context == null) {
            context = new TracingContext();
        }
        CONTEXT.set(context);
        return context;
    }

    private static TracingContext get() {
        return CONTEXT.get();
    }

    public static String getGlobalTraceId() {
        TracingContext context = get();
        return Objects.nonNull(context) ? context.getReadablePrimaryTraceId() : EMPTY_TRACE_CONTEXT_ID;
    }

    // 暂时不考虑分布式服务调用场景
    public static ISpan createEntrySpan(String opName) {
        TracingContext context = getOrCreate();
        return context.createEntrySpan(opName);
    }

    public static ISpan createLocalSpan(String opName) {
        TracingContext context = getOrCreate();
        return context.createLocalSpan(opName);
    }

    public static ISpan createExitSpan(String opName, String remotePeer) {
        // LogUtil.info("=================== createExitSpan");
        TracingContext context = getOrCreate();
        return context.createExitSpan(opName, remotePeer);
    }

    public static void stopSpan() {
        // LogUtil.info("=================== stopSpan");
        TracingContext context = get();
        stopSpan(context.activeSpan(), context);
    }

    public static void stopSpan(ISpan span) {
        stopSpan(span, get());
    }

    private static void stopSpan(ISpan span, final TracingContext context) {
        // 栈为空时
        if (context.stopSpan(span)) {
            CONTEXT.remove();
        }
    }

    public static ISpan activeSpan() {
        return get().activeSpan();
    }

    public static boolean isActive() {
        return get() != null;
    }

    public static ContextSnapshot capture() {
        return get().capture();
    }

    public static void continued(ContextSnapshot snapshot) {
        if (snapshot == null) {
            throw new IllegalArgumentException("快照参数不能为空");
        }
        if (!snapshot.isFromCurrent()) {
            get().continued(snapshot);
        }
    }
}
