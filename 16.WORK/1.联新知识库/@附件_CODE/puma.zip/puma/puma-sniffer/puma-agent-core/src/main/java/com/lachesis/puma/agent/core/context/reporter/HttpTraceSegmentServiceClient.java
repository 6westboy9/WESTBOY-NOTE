package com.lachesis.puma.agent.core.context.reporter;

import cn.hutool.json.JSONUtil;
import com.lachesis.puma.agent.core.context.TracingContext;
import com.lachesis.puma.agent.core.context.trace.TraceSegment;
import com.lachesis.puma.agent.core.context.trace.TracingContextListener;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.protocol.network.SegmentData;

public class HttpTraceSegmentServiceClient implements TracingContextListener {

    private static final HttpTraceSegmentServiceClient INSTANCE = new HttpTraceSegmentServiceClient();

    private HttpTraceSegmentServiceClient() {
    }

    public static void init() {
        // LogUtil.info("HttpTraceSegmentServiceClient init...");
        TracingContext.ListenerManager.add(INSTANCE);
    }

    public void afterFinished(TraceSegment traceSegment) {
        SegmentData segmentData = traceSegment.transform();
        if (segmentData != null) {
            LogUtil.info("======> " + JSONUtil.toJsonStr(segmentData));
        }
    }
}
