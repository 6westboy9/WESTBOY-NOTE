package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.context.support.KeyValuePair;
import com.lachesis.puma.protocol.network.LogData;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class LogDataEntity {

    private final long timestamp;
    private final List<KeyValuePair> logs;

    private LogDataEntity(long timestamp, List<KeyValuePair> logs) {
        this.timestamp = timestamp;
        this.logs = logs;
    }

    public List<KeyValuePair> getLogs() {
        return logs;
    }

    public LogData transform() {
        LogData logData = new LogData();
        if (logs != null) {
            for (KeyValuePair log : logs) {
                logData.addData(log.transform());
            }
        }
        logData.setTime(timestamp);
        return logData;
    }

    public static class Builder {

        protected List<KeyValuePair> logs;

        public Builder() {
            logs = new LinkedList<>();
        }

        public Builder add(KeyValuePair... fields) {
            Collections.addAll(logs, fields);
            return this;
        }

        public LogDataEntity build(long timestamp) {
            return new LogDataEntity(timestamp, logs);
        }
    }
}
