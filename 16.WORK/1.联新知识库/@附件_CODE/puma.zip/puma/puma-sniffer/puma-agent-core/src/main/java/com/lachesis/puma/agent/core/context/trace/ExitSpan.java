package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.context.TracingContext;
import com.lachesis.puma.agent.core.context.tag.StringTag;

public class ExitSpan extends StackBasedTracingSpan {

    public ExitSpan(int spanId, int parentSpanId, String opName, TracingContext owner) {
        super(spanId, parentSpanId, opName, owner);
    }

    public ExitSpan(int spanId, int parentSpanId, String opName, String peer, TracingContext owner) {
        super(spanId, parentSpanId, opName, peer, owner);
    }

    @Override
    public ISpan tag(StringTag tag, String value) {
        if (stackDepth == 1) {
            super.tag(tag, value);
        }
        return this;
    }

    @Override
    public ISpan setOpName(String opName) {
        if (stackDepth == 1) {
            return super.setOpName(opName);
        } else {
            return this;
        }
    }

    @Override
    public ISpan start() {
        if (++stackDepth == 1) {
            super.start();
        }
        return this;
    }

    @Override
    public boolean isEntry() {
        return false;
    }

    @Override
    public boolean isExit() {
        return true;
    }
}
