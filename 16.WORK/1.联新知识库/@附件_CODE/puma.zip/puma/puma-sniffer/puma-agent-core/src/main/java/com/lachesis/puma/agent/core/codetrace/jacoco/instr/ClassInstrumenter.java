/*******************************************************************************
 * Copyright (c) 2009, 2023 Mountainminds GmbH & Co. KG and Contributors
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *    Marc R. Hoffmann - initial API and implementation
 *
 *******************************************************************************/
package com.lachesis.puma.agent.core.codetrace.jacoco.instr;

import com.lachesis.puma.agent.core.codetrace.jacoco.flow.ClassProbesVisitor;
import com.lachesis.puma.agent.core.codetrace.jacoco.flow.MethodProbesVisitor;
import org.objectweb.asm.*;

import java.util.Map;

/**
 * Adapter that instruments a class for coverage tracing.
 */
public class ClassInstrumenter extends ClassProbesVisitor {

    private final ClassInfo classInfo;
    private String className;

    /**
     * Emits a instrumented version of this class to the given class visitor.
     *
     * @param classInfo this strategy will be used to access the probe array
     * @param cv        next delegate in the visitor chain will receive the
     *                  instrumented class
     */
    public ClassInstrumenter(ClassInfo classInfo, ClassVisitor cv) {
        super(cv);
        this.classInfo = classInfo;
    }

    @Override
    public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
        this.className = name;
        super.visit(version, access, name, signature, superName, interfaces);
    }

    @Override
    public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
        InstrSupport.assertNotInstrumented(name, className);
        return super.visitField(access, name, desc, signature, value);
    }

    @Override
    public MethodProbesVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
        InstrSupport.assertNotInstrumented(name, className);
        MethodVisitor mv = cv.visitMethod(access, name, desc, signature, exceptions);
        if (mv == null) {
            return null;
        }
        MethodVisitor frameEliminator = new DuplicateFrameEliminator(mv);
        ProbeInserter probeVariableInserter = new ProbeInserter(access, name, desc, frameEliminator, classInfo);
        return new MethodInstrumenter(probeVariableInserter, probeVariableInserter);
    }

    @Override
    public void visitTotalProbeCount(int count) {
        MethodVisitor mv = cv.visitMethod(InstrSupport.INITMETHOD_ACC, InstrSupport.METHOD_PROBE_SIZE_NAME, InstrSupport.METHOD_PROBE_SIZE_DESC, null, null);
        mv.visitCode();
        int methodSize = classInfo.getMethodProbeSizes().size();
        mv.visitLabel(new Label());
        InstrSupport.push(mv, methodSize);
        mv.visitIntInsn(Opcodes.NEWARRAY, Opcodes.T_INT);
        mv.visitInsn(Opcodes.DUP);
        for (Map.Entry<Integer, Integer> entry : classInfo.getMethodProbeSizes().entrySet()) {
            InstrSupport.push(mv, entry.getKey());
            InstrSupport.push(mv, entry.getValue());
            mv.visitInsn(Opcodes.IASTORE);
            mv.visitInsn(Opcodes.DUP);
        }
        mv.visitVarInsn(Opcodes.ASTORE, 1);
        mv.visitLabel(new Label());
        mv.visitVarInsn(Opcodes.ALOAD, 1);
        mv.visitVarInsn(Opcodes.ILOAD, 0);
        mv.visitInsn(Opcodes.IALOAD);
        mv.visitInsn(Opcodes.IRETURN);
        mv.visitLabel(new Label());
        mv.visitMaxs(4, 2); // Maximum local stack size is 2
        mv.visitEnd();
    }
}
