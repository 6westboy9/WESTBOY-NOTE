package com.lachesis.puma.agent.core.codetrace;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import com.lachesis.puma.agent.core.codetrace.jacoco.CodeTraceTransformer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.security.ProtectionDomain;

class CodeTraceTransformerUserControllerTest {

    private final CodeTraceTransformer codeTraceTransformer = new CodeTraceTransformer(1);
    private byte[] newBytes;

    @BeforeEach
    void before() {
        ClassLoader classLoader = getClass().getClassLoader();
        ProtectionDomain domain = CodeTraceTransformerUserControllerTest.class.getProtectionDomain();
        InputStream inputStream = getClass().getResourceAsStream("/com/lachesis/puma/agent/core/codetrace/samples/UserController.class");
        byte[] bytes = IoUtil.readBytes(inputStream);
        String className = "com.lachesis.puma.agent.core.codetrace.samples.UserController";
        newBytes = codeTraceTransformer.transform(classLoader, className, null, domain, bytes);
    }

    @Test
    void transformTest_generate() {
        String classTargetFilePath = "D:/IdeaProjects/mine/puma/puma-sniffer/puma-agent-core/target/test-classes/com/lachesis/puma/agent/core/codetrace/samples/UserController_1.class";
        FileUtil.writeBytes(newBytes, classTargetFilePath);
    }

}