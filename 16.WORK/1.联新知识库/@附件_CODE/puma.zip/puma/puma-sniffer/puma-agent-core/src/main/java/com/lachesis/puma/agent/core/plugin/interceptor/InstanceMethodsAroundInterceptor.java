package com.lachesis.puma.agent.core.plugin.interceptor;

import java.lang.reflect.Method;

/**
 * 实例方法拦截器必须实现这个接口
 */
public interface InstanceMethodsAroundInterceptor {

    void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes);

    Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result);

    void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t);

}
