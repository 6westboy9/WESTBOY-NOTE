package com.lachesis.puma.agent.core.tmp;

import org.junit.jupiter.api.Test;
import org.objectweb.asm.Type;

public class TmpTest {

    @Test
    void test_01() {
        // Ljava/lang/Object;
        System.out.println(Type.getDescriptor(Object.class));
        // java/lang/Object
        System.out.println(Type.getInternalName(Object.class));
    }
}
