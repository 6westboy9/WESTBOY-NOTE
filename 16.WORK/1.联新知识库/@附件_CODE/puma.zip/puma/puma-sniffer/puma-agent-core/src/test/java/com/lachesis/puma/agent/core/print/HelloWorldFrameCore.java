package com.lachesis.puma.agent.core.print;

import cn.hutool.core.io.FileUtil;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Opcodes;

public class HelloWorldFrameCore {

    private static final String PATH = "D:/IdeaProjects/mine/puma/puma-sniffer/puma-agent-core/target/test-classes/";

    public static void main(String[] args) throws Exception {
        String relative_path = "com/lachesis/puma/agent/core/codetrace/samples/UserTargetController.class";
        String filepath = PATH + relative_path;
        byte[] bytes = FileUtil.readBytes(filepath);
        System.out.println();
        ClassReader cr = new ClassReader(bytes);
        ClassVisitor cv = new MethodStackMapFrameVisitor(Opcodes.ASM9, null);
        int parsingOptions = ClassReader.EXPAND_FRAMES; // 注意，这里使用了EXPAND_FRAMES
        cr.accept(cv, parsingOptions);
    }
}
