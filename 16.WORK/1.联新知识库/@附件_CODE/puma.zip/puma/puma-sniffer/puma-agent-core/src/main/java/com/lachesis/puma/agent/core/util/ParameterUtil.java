package com.lachesis.puma.agent.core.util;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class ParameterUtil {

    public static String toString(Map<String, String[]> map) {
        return map.entrySet()
            .stream()
            .map(entry -> entry.getKey() + "=" + Arrays.toString(entry.getValue()))
            .collect(Collectors.joining("\n"));
    }
}
