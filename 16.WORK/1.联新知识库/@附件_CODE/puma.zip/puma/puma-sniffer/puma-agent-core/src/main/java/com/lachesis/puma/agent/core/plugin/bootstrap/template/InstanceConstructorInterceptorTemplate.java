package com.lachesis.puma.agent.core.plugin.bootstrap.template;

import com.lachesis.puma.agent.core.plugin.BootstrapInterceptorRuntimeAssist;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceConstructorInterceptor;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.util.LogUtil;
import net.bytebuddy.implementation.bind.annotation.AllArguments;
import net.bytebuddy.implementation.bind.annotation.Origin;
import net.bytebuddy.implementation.bind.annotation.RuntimeType;
import net.bytebuddy.implementation.bind.annotation.This;

import java.lang.reflect.Constructor;
import java.util.Arrays;

public class InstanceConstructorInterceptorTemplate {

    private static final String TAG = "[构造方法]";
    private static String targetInterceptor;
    private static String transformClassName;
    private static InstanceConstructorInterceptor interceptor;

    @RuntimeType
    public static void intercept(@This Object obj, @Origin Constructor<?> constructor, @AllArguments Object[] arguments) {
        try {

            // 重要
            prepare();

            if (interceptor == null) {
                return;
            }

            // LogUtil.info(String.format("%-30s 结束%s:%s", transformClassName, TAG, Arrays.toString(arguments)));
            EnhancedInstance instance = (EnhancedInstance) obj;
            interceptor.onConstruct(instance, constructor, arguments);
        } catch (Throwable t) {
            LogUtil.error(t, String.format("%-30s 结束(增强处理异常)%s:", transformClassName, TAG));
        }
    }

    private static void prepare() {
        if (interceptor == null) {
            ClassLoader classLoader = BootstrapInterceptorRuntimeAssist.getAgentClassLoader();
            if (classLoader != null) {
                // TODO 日志
                interceptor = BootstrapInterceptorRuntimeAssist.createInterceptor(classLoader, targetInterceptor);
            }
        }
    }
}
