package com.lachesis.puma.agent.core.codetrace.asm;

public class MethodInvocationAspect {

    public static void beforeMethod(String className, String methodName, String descriptor, Object[] params) {
        MethodInfo methodInfo = new MethodInfo(className, methodName, descriptor, params);
        TraceContextManager.beforeMethod(methodInfo);
    }

    public static void afterMethod(String className, String methodName, String descriptor, Object returnValue) {
        MethodInfo methodInfo = new MethodInfo(className, methodName, descriptor, returnValue);
        TraceContextManager.afterMethod(methodInfo);
    }

    public static void handleEx(String className, String methodName, String descriptor, Throwable throwable) {
        MethodInfo methodInfo = new MethodInfo(className, methodName, descriptor, throwable);
        TraceContextManager.handleEx(methodInfo);
    }
}
