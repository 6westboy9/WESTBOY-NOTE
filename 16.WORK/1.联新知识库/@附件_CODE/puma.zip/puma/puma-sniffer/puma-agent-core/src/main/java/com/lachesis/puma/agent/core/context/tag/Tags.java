/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.lachesis.puma.agent.core.context.tag;

public final class Tags {

    private Tags() {
    }

    public static final StringTag CODE_METHOD_PARAMS = new StringTag(10, "method.params");
    public static final StringTag CODE_METHOD_RESULT = new StringTag(11, "method.result");
    public static final StringTag CODE_METHOD_NAME = new StringTag(12, "method.name");

    public static final StringTag DB_TYPE = new StringTag(20, "db.type");
    public static final StringTag DB_INSTANCE = new StringTag(21, "db.instance");
    public static final StringTag DB_URL = new StringTag(22, "db.url");
    public static final StringTag DB_STATEMENT = new StringTag(23, "db.statement");
    public static final StringTag DB_SQL_PARAMETERS = new StringTag(24, "db.sql.parameters");
    public static final StringTag DB_BIND_VARIABLES = new StringTag(25, "db.bind_vars");

    public static final StringTag MQ_QUEUE = new StringTag(30, "mq.queue");
    public static final StringTag MQ_BROKER = new StringTag(31, "mq.broker");
    public static final StringTag MQ_TOPIC = new StringTag(32, "mq.topic");
    public static final StringTag MQ_STATUS = new StringTag(33, "mq_status");

    public static final StringTag HTTP_METHOD = new StringTag(40, "http.method");
    public static final StringTag HTTP_URL = new StringTag(41, "http.url");
    public static final StringTag HTTP_HEADERS = new StringTag(42, "http.headers");
    public static final StringTag HTTP_PARAMS = new StringTag(43, "http.params", true);
    public static final StringTag HTTP_BODY = new StringTag(44, "http.body");
    public static final StringTag HTTP_STATUS_CODE = new StringTag(44, "http.status_code", true);

    public static final StringTag MVC_CONTROLLER_PATH = new StringTag(50, "mvc.controller.path");

}
