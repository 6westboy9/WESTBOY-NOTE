package com.lachesis.puma.agent.core.codetrace.asm;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyMethodAdapter extends MethodVisitor implements Opcodes {

    private final String className;
    private boolean isStaticMethod;
    private final String methodName;
    private final String descriptor;
    private final String[] paramDescriptors;

    private int nextLocalIndex = 0;
    private final Label from = new Label();
    private final Label to = new Label();
    private final Label target = new Label();

    private static final String SESSION_CLASS = Type.getInternalName(MethodInvocationAspect.class);
    private static final String AFTER_METHOD_NAME = "afterMethod";
    private static final String BEFORE_METHOD_NAME = "beforeMethod";
    private static final String HANDLE_EX_METHOD_NAME = "handleEx";

    public MyMethodAdapter(String className, int access, String methodName, String descriptor, MethodVisitor methodVisitor) {
        super(ASM9, methodVisitor);
        if ((access & ACC_STATIC) == ACC_STATIC) {
            isStaticMethod = true;
        }
        this.className = className;
        this.methodName = methodName;
        this.descriptor = descriptor;
        this.paramDescriptors = getParamDescriptors(descriptor);
    }

    public static String[] getParamDescriptors(String methodDescriptor) {
        List<String> paramDescriptors = new ArrayList<>();
        Matcher matcher = Pattern.compile("(L.*?;|\\[{0,2}L.*?;|[ZCBSIFJD]|\\[{0,2}[ZCBSIFJD])")
            .matcher(methodDescriptor.substring(0, methodDescriptor.lastIndexOf(')') + 1));
        while (matcher.find()) {
            paramDescriptors.add(matcher.group(1));
        }
        if (paramDescriptors.isEmpty()) {
            return null;
        }
        return paramDescriptors.toArray(new String[0]);
    }

    @Override
    public void visitCode() {
        super.visitCode();
        super.visitTryCatchBlock(from, to, target, Type.getInternalName(Throwable.class));
        super.visitLdcInsn(className);
        super.visitLdcInsn(methodName);
        super.visitLdcInsn(descriptor);
        if (paramDescriptors == null) {
            super.visitInsn(ACONST_NULL);
        } else {
            // 为什么有参数时，要使用super呢？
            if (paramDescriptors.length >= 4) {
                super.visitVarInsn(BIPUSH, paramDescriptors.length);
            } else {
                switch (paramDescriptors.length) {
                    case 1:
                        super.visitInsn(ICONST_1);
                        break;
                    case 2:
                        super.visitInsn(ICONST_2);
                        break;
                    case 3:
                        super.visitInsn(ICONST_3);
                        break;
                    default:
                        super.visitInsn(ICONST_0);
                }
            }

            super.visitTypeInsn(ANEWARRAY, Type.getInternalName(Object.class));

            int localIndex = isStaticMethod ? 0 : 1;
            for (int i = 0; i < paramDescriptors.length; i++) {
                super.visitInsn(DUP);
                switch (i) {
                    case 0:
                        super.visitInsn(ICONST_0);
                        break;
                    case 1:
                        super.visitInsn(ICONST_1);
                        break;
                    case 2:
                        super.visitInsn(ICONST_2);
                        break;
                    case 3:
                        super.visitInsn(ICONST_3);
                        break;
                    default:
                        super.visitVarInsn(BIPUSH, i);
                }
                String type = paramDescriptors[i];
                if ("Z".equals(type)) {
                    super.visitVarInsn(ILOAD, localIndex++);
                    super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Boolean.class), "valueOf", "(Z)Ljava/lang/Boolean;", false);
                } else if ("C".equals(type)) {
                    super.visitVarInsn(ILOAD, localIndex++);
                    super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Character.class), "valueOf", "(C)Ljava/lang/Character;", false);
                } else if ("B".equals(type)) {
                    super.visitVarInsn(ILOAD, localIndex++);
                    super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Byte.class), "valueOf", "(B)Ljava/lang/Byte;", false);
                } else if ("S".equals(type)) {
                    super.visitVarInsn(ILOAD, localIndex++);
                    super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Short.class), "valueOf", "(S)Ljava/lang/Short;", false);
                } else if ("I".equals(type)) {
                    super.visitVarInsn(ILOAD, localIndex++);
                    super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Integer.class), "valueOf", "(I)Ljava/lang/Integer;", false);
                } else if ("F".equals(type)) {
                    super.visitVarInsn(FLOAD, localIndex++);
                    super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Float.class), "valueOf", "(F)Ljava/lang/Float;", false);
                } else if ("J".equals(type)) {
                    super.visitVarInsn(LLOAD, localIndex);
                    localIndex += 2;
                    super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Long.class), "valueOf", "(J)Ljava/lang/Long;", false);
                } else if ("D".equals(type)) {
                    localIndex += 2;
                    super.visitVarInsn(DLOAD, localIndex);
                    super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Double.class), "valueOf", "(D)Ljava/lang/Double;", false);
                } else {
                    super.visitVarInsn(ALOAD, localIndex++);
                }
                super.visitInsn(AASTORE);
            }
        }
        super.visitMethodInsn(INVOKESTATIC, SESSION_CLASS, BEFORE_METHOD_NAME, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V", false);
        super.visitLabel(from);
    }

    @Override
    public void visitLineNumber(int line, Label start) {
        super.visitLineNumber(line, start);
    }

    /**
     * 访问局部变量表的指令
     *
     * @param opcode 指令码
     * @param var    局部变量表索引
     */
    @Override
    public void visitVarInsn(int opcode, int var) {
        super.visitVarInsn(opcode, var);
        if (opcode == ILOAD
            || opcode == FLOAD
            || opcode == ALOAD
            || opcode == ISTORE
            || opcode == FSTORE
            || opcode == ASTORE) {
            if (var > nextLocalIndex) {
                nextLocalIndex = var + 1;
            }
        } else if (opcode == LLOAD
            || opcode == DLOAD
            || opcode == LSTORE
            || opcode == DSTORE) {
            // long和double类型占用局部变量表的两个slot
            if (var + 1 > nextLocalIndex) {
                nextLocalIndex = var + 2;
            }
        }
    }

    @Override
    public void visitInsn(int opcode) {
        //  获取最后一个局部变量的后面一个位置
        int li = nextLocalIndex;
        switch (opcode) {
            case RETURN:
                super.visitLdcInsn(className);
                super.visitLdcInsn(methodName);
                super.visitLdcInsn(descriptor);
                super.visitInsn(ACONST_NULL);
                super.visitMethodInsn(INVOKESTATIC, SESSION_CLASS, AFTER_METHOD_NAME, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V", false);
                break;
            case IRETURN:
                super.visitInsn(DUP);
                super.visitVarInsn(ISTORE, li);
                super.visitLdcInsn(className);
                super.visitLdcInsn(methodName);
                super.visitLdcInsn(descriptor);
                super.visitVarInsn(ILOAD, li);
                super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Integer.class), "valueOf", "(I)Ljava/lang/Integer;", false);
                super.visitMethodInsn(INVOKESTATIC, SESSION_CLASS, AFTER_METHOD_NAME, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V", false);
                break;
            case FRETURN:
                super.visitInsn(DUP);
                super.visitVarInsn(FSTORE, li);
                super.visitLdcInsn(className);
                super.visitLdcInsn(methodName);
                super.visitLdcInsn(descriptor);
                super.visitVarInsn(FLOAD, li);
                super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Float.class), "valueOf", "(F)Ljava/lang/Float;", false);
                super.visitMethodInsn(INVOKESTATIC, SESSION_CLASS, AFTER_METHOD_NAME, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V", false);
                break;
            case LRETURN:
                super.visitInsn(DUP2);
                super.visitVarInsn(LSTORE, li);
                super.visitLdcInsn(className);
                super.visitLdcInsn(methodName);
                super.visitLdcInsn(descriptor);
                super.visitVarInsn(LLOAD, li);
                super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Long.class), "valueOf", "(J)Ljava/lang/Long;", false);
                super.visitMethodInsn(INVOKESTATIC, SESSION_CLASS, AFTER_METHOD_NAME, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V", false);
                break;
            case DRETURN:
                super.visitInsn(DUP2);
                super.visitVarInsn(DSTORE, li);
                super.visitLdcInsn(className);
                super.visitLdcInsn(methodName);
                super.visitLdcInsn(descriptor);
                super.visitVarInsn(DLOAD, li);
                super.visitMethodInsn(INVOKESTATIC, Type.getInternalName(Double.class), "valueOf", "(D)Ljava/lang/Double;", false);
                super.visitMethodInsn(INVOKESTATIC, SESSION_CLASS, AFTER_METHOD_NAME, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V", false);
                break;
            case ARETURN:
                super.visitInsn(DUP);
                super.visitVarInsn(ASTORE, li);
                super.visitLdcInsn(className);
                super.visitLdcInsn(methodName);
                super.visitLdcInsn(descriptor);
                super.visitVarInsn(ALOAD, li);
                super.visitMethodInsn(INVOKESTATIC, SESSION_CLASS, AFTER_METHOD_NAME, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V", false);
                break;
        }
        super.visitInsn(opcode);
    }

    @Override
    public void visitMaxs(int maxStack, int maxLocals) {
        super.visitLabel(to);
        super.visitLabel(target);
        super.visitVarInsn(ASTORE, maxLocals + 1);
        super.visitLdcInsn(className);
        super.visitLdcInsn(methodName);
        super.visitLdcInsn(descriptor);
        super.visitVarInsn(ALOAD, maxLocals + 1);
        super.visitMethodInsn(INVOKESTATIC, SESSION_CLASS, HANDLE_EX_METHOD_NAME, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V", false);
        super.visitVarInsn(ALOAD, maxLocals + 1);
        super.visitInsn(ATHROW);
        super.visitMaxs(maxStack, maxLocals);
    }
}