/*******************************************************************************
 * Copyright (c) 2009, 2023 Mountainminds GmbH & Co. KG and Contributors
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *    Marc R. Hoffmann - initial API and implementation
 *
 *******************************************************************************/
package com.lachesis.puma.agent.core.codetrace.jacoco.instr;

import com.lachesis.puma.agent.core.codetrace.jacoco.flow.IFrame;
import com.lachesis.puma.agent.core.codetrace.jacoco.flow.LabelInfo;
import com.lachesis.puma.agent.core.codetrace.jacoco.flow.MethodProbesVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/**
 * This method adapter inserts probes as requested by the
 * {@link MethodProbesVisitor} events.
 */
class MethodInstrumenter extends MethodProbesVisitor {

    private final IProbeInserter probeInserter;

    /**
     * Create a new instrumenter instance for the given method.
     *
     * @param mv            next method visitor in the chain
     * @param probeInserter call-back to insert probes where required
     */
    public MethodInstrumenter(MethodVisitor mv, IProbeInserter probeInserter) {
        super(mv);
        this.probeInserter = probeInserter;
    }

    // === IMethodProbesVisitor ===

    @Override
    public void visitProbe(int probeId, String from) {
        probeInserter.insertProbe(from, probeId);
    }

    @Override
    public void visitInsnWithProbe(int opcode, int probeId, String from) {
        probeInserter.insertProbe(from, probeId);
        mv.visitInsn(opcode);
    }

	@Override
	public void visitIntInsnWithProbe(int opcode, int operand, int probeId, String from) {
		probeInserter.insertProbe(from, probeId);
		mv.visitIntInsn(opcode, operand);
	}

	@Override
    public void visitJumpInsnWithProbe(int opcode, Label label, int probeId, IFrame frame, String from) {
        if (opcode == Opcodes.GOTO) {
            probeInserter.insertProbe(from, probeId);
            mv.visitJumpInsn(Opcodes.GOTO, label);
        } else {
            Label intermediate = new Label();
            mv.visitJumpInsn(getInverted(opcode), intermediate);
            probeInserter.insertProbe(from, probeId);
            mv.visitJumpInsn(Opcodes.GOTO, label);
            mv.visitLabel(intermediate);
            frame.accept(mv);
        }
    }

    private int getInverted(int opcode) {
        switch (opcode) {
            case Opcodes.IFEQ:
                return Opcodes.IFNE;
            case Opcodes.IFNE:
                return Opcodes.IFEQ;
            case Opcodes.IFLT:
                return Opcodes.IFGE;
            case Opcodes.IFGE:
                return Opcodes.IFLT;
            case Opcodes.IFGT:
                return Opcodes.IFLE;
            case Opcodes.IFLE:
                return Opcodes.IFGT;
            case Opcodes.IF_ICMPEQ:
                return Opcodes.IF_ICMPNE;
            case Opcodes.IF_ICMPNE:
                return Opcodes.IF_ICMPEQ;
            case Opcodes.IF_ICMPLT:
                return Opcodes.IF_ICMPGE;
            case Opcodes.IF_ICMPGE:
                return Opcodes.IF_ICMPLT;
            case Opcodes.IF_ICMPGT:
                return Opcodes.IF_ICMPLE;
            case Opcodes.IF_ICMPLE:
                return Opcodes.IF_ICMPGT;
            case Opcodes.IF_ACMPEQ:
                return Opcodes.IF_ACMPNE;
            case Opcodes.IF_ACMPNE:
                return Opcodes.IF_ACMPEQ;
            case Opcodes.IFNULL:
                return Opcodes.IFNONNULL;
            case Opcodes.IFNONNULL:
                return Opcodes.IFNULL;
        }
        throw new IllegalArgumentException();
    }

    @Override
    public void visitTableSwitchInsnWithProbes(int min, int max, Label dflt, Label[] labels, IFrame frame, String from) {
        // 1. Calculate intermediate labels:
        LabelInfo.resetDone(dflt);
        LabelInfo.resetDone(labels);
        Label newDflt = createIntermediate(dflt);
        Label[] newLabels = createIntermediates(labels);
        mv.visitTableSwitchInsn(min, max, newDflt, newLabels);

        // 2. Insert probes:
        insertIntermediateProbes(dflt, labels, frame, from);
    }

    @Override
    public void visitLookupSwitchInsnWithProbes(Label dflt, int[] keys, Label[] labels, IFrame frame, String from) {
        // 1. Calculate intermediate labels:
        LabelInfo.resetDone(dflt);
        LabelInfo.resetDone(labels);
        Label newDflt = createIntermediate(dflt);
        Label[] newLabels = createIntermediates(labels);
        mv.visitLookupSwitchInsn(newDflt, keys, newLabels);

        // 2. Insert probes:
        insertIntermediateProbes(dflt, labels, frame, from);
    }

    private Label[] createIntermediates(Label[] labels) {
        Label[] intermediates = new Label[labels.length];
        for (int i = 0; i < labels.length; i++) {
            intermediates[i] = createIntermediate(labels[i]);
        }
        return intermediates;
    }

    private Label createIntermediate(Label label) {
        Label intermediate;
        if (LabelInfo.getProbeId(label) == LabelInfo.NO_PROBE) {
            intermediate = label;
        } else {
            if (LabelInfo.isDone(label)) {
                intermediate = LabelInfo.getIntermediateLabel(label);
            } else {
                intermediate = new Label();
                LabelInfo.setIntermediateLabel(label, intermediate);
                LabelInfo.setDone(label);
            }
        }
        return intermediate;
    }

    private void insertIntermediateProbe(Label label, IFrame frame, String from) {
        int probeId = LabelInfo.getProbeId(label);
        if (probeId != LabelInfo.NO_PROBE && !LabelInfo.isDone(label)) {
            mv.visitLabel(LabelInfo.getIntermediateLabel(label));
            frame.accept(mv);
            probeInserter.insertProbe(from, probeId);
            mv.visitJumpInsn(Opcodes.GOTO, label);
            LabelInfo.setDone(label);
        }
    }

    private void insertIntermediateProbes(Label dflt, Label[] labels, IFrame frame, String from) {
        LabelInfo.resetDone(dflt);
        LabelInfo.resetDone(labels);
        insertIntermediateProbe(dflt, frame, from);
        for (Label l : labels) {
            insertIntermediateProbe(l, frame, from);
        }
    }
}
