package com.lachesis.puma.agent.core.context.ids;

public class NewDistributedTraceId extends DistributedTraceId {

    public NewDistributedTraceId() {
        super(GlobalIdGenerator.generate());
    }
}
