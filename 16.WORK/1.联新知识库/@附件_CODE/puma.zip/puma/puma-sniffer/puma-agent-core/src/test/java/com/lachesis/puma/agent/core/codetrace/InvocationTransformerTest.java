package com.lachesis.puma.agent.core.codetrace;

import cn.hutool.core.io.IoUtil;
import com.lachesis.puma.agent.core.codetrace.asm.MethodInvocationTransformer;
import com.lachesis.puma.agent.core.codetrace.asm.TraceContextManager;
import com.lachesis.puma.agent.core.codetrace.samples.UserQuery;
import com.lachesis.puma.agent.core.codetrace.samples.UserServiceImpl;
import javassist.ByteArrayClassPath;
import javassist.ClassPool;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.InputStream;
import java.security.ProtectionDomain;

class InvocationTransformerTest {

    private final MethodInvocationTransformer codeTraceTransformer = new MethodInvocationTransformer(1);

    @BeforeEach
    void before() throws Exception {
        String className = "com.lachesis.puma.agent.core.codetrace.samples.UserServiceImpl";
        String classFilePath = "/com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl.class";
        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = getClass().getResourceAsStream(classFilePath);
        byte[] bytes = IoUtil.readBytes(inputStream);
        ProtectionDomain domain = InvocationTransformerTest.class.getProtectionDomain();
        byte[] newBytes = codeTraceTransformer.transform(classLoader, className, null, domain, bytes);
        loadClass(className, newBytes);
    }

    private void loadClass(String className, byte[] newBytes) throws Exception {
        ClassPool pool = new ClassPool();
        pool.insertClassPath(new ByteArrayClassPath(className, newBytes));
        String dir = System.getProperty("user.dir") + File.separator + "target" + File.separator + "generated-classes";
        System.out.println("TARGET_DIR:" + dir);
        pool.get(className).writeFile(dir);
        Class<?> aClass = pool.get(className).toClass();
        System.out.println(aClass);

    }

    @Test
    void transformTest_generate() {
        // 验证
    }

    @Test
    void transformTest_getUser() {
        new UserServiceImpl().getUser();
        TraceContextManager.print();
    }

    @Test
    void transformTest_listUser() {
        new UserServiceImpl().listUser();
    }

    @Test
    void transformTest_listUserByCondition() {
        new UserServiceImpl().listUser("xw", 18);
    }

    @Test
    void transformTest_listUserByConditionV2() {
        UserQuery query = new UserQuery();
        query.setName("xw");
        query.setAge(10);
        new UserServiceImpl().listUser(query);
        TraceContextManager.print();
    }

    @Test
    void transformTest_test() {
        new UserServiceImpl().test();
        TraceContextManager.print();
    }

    @Test
    void transformTest_testAsync() {
        new UserServiceImpl().testAsync();
    }
}