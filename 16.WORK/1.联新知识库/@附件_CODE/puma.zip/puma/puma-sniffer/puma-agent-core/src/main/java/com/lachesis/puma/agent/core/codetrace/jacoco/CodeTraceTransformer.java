package com.lachesis.puma.agent.core.codetrace.jacoco;

import com.lachesis.puma.agent.core.codetrace.asm.MyClassAdapter;
import com.lachesis.puma.agent.core.codetrace.jacoco.flow.ClassProbesAdapter;
import com.lachesis.puma.agent.core.codetrace.jacoco.instr.ClassInfo;
import com.lachesis.puma.agent.core.codetrace.jacoco.instr.ClassInstrumenter;
import com.lachesis.puma.agent.core.codetrace.jacoco.instr.InstrSupport;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.util.CheckClassAdapter;

import java.io.PrintWriter;
import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;

public class CodeTraceTransformer implements ClassFileTransformer {

    /**
     * 检查类型：0.不检查 1.过程中检查 2.过程后检查
     */
    private final int checkType;

    public CodeTraceTransformer(int checkType) {
        this.checkType = checkType;
    }

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                            ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (className == null) {
            return null;
        }

        className = className.replaceAll("/", ".");
        if (!className.contains("puma")) {
            return null;
            // LogUtil.info(String.format("ClassName:%s", className));
        }

        ClassReader reader = new ClassReader(classfileBuffer);
        if (InstrSupport.isInterface(reader)) {
            return null;
        }

        byte[] bytes;
        ClassInfo info = new ClassInfo(reader);
        ClassWriter cw = new ClassWriter(reader, ClassWriter.COMPUTE_FRAMES);
        if (checkType == 1) {
            CheckClassAdapter cca = new CheckClassAdapter(cw);
            ClassVisitor cv = new ClassProbesAdapter(new ClassInstrumenter(info, cca), true);
            reader.accept(cv, ClassReader.SKIP_FRAMES);
            bytes = cw.toByteArray();
        } else if (checkType == 2) {
            ClassVisitor cv = new ClassProbesAdapter(new ClassInstrumenter(info, cw), true);
            reader.accept(cv, ClassReader.SKIP_FRAMES);
            bytes = cw.toByteArray();
            PrintWriter printWriter = new PrintWriter(System.out);
            CheckClassAdapter.verify(new ClassReader(bytes), false, printWriter);
        } else {
            ClassVisitor cv = new ClassProbesAdapter(new ClassInstrumenter(info, cw), true);
            reader.accept(cv, ClassReader.SKIP_FRAMES);
            bytes = cw.toByteArray();
        }
        return bytes;
    }
}
