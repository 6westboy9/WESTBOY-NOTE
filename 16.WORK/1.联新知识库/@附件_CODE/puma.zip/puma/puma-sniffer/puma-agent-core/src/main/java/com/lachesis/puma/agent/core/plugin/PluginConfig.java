package com.lachesis.puma.agent.core.plugin;

import com.lachesis.puma.agent.core.util.LogUtil;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public enum PluginConfig {

    INSTANCE;

    /**
     * 存放所有插件.def文件构造出来的PluginDefine实例
     */
    private final List<PluginDefine> pluginDefines = new ArrayList<>();

    /**
     * 转换.def文件的内容为PluginDefine
     */
    public void load(InputStream input) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input))) {
            String pluginDefine;
            while ((pluginDefine = reader.readLine()) != null) {
                try {
                    if (pluginDefine.trim().isEmpty() || pluginDefine.startsWith("#")) {
                        continue;
                    }
                    PluginDefine plugin = PluginDefine.build(pluginDefine);
                    pluginDefines.add(plugin);
                } catch (Exception e) {
                    LogUtil.error(e, String.format("插件定义配置文件格式错误:%s", pluginDefine));
                }
            }
        }
    }

    public List<PluginDefine> getPluginDefines() {
        return pluginDefines;
    }

}

