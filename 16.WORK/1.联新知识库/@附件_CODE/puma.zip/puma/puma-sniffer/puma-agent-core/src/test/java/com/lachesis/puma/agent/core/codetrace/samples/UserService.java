package com.lachesis.puma.agent.core.codetrace.samples;

import java.util.List;

public interface UserService {

    /**
     * 单个
     */
    User getUser();

    /**
     * 多个的情况
     */
    List<User> listUser();

    /**
     * 重载
     */
    List<User> listUser(String name, int age);

    /**
     * 重载2
     */
    List<User> listUser(UserQuery query);

    /**
     * 嵌套
     */
    int test();

    /**
     * 多线程
     */
    void testAsync();


}
