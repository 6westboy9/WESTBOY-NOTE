/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.lachesis.puma.agent.core.boot;

import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class SnifferConfigInitializer {
    private static final String SPECIFIED_CONFIG_PATH = "puma_config";
    private static final String DEFAULT_CONFIG_FILE_NAME = "/config/agent.config";
    private static final String ENV_KEY_PREFIX = "puma.";
    private static Properties AGENT_SETTINGS;
    private static boolean IS_INIT_COMPLETED = false;

    /**
     * <ol>
     *     <li>1.默认配置文件路径：/dist/config/agent.config，也可以通过系统变量（puma_config）指定配置文件路径</li>
     *     <li>2.解析配置文件中的配置项，生成最终的键值对存储于AGENT_SETTINGS中，具体的解析过程如下：
     *     <ol>
     *         <li>没有占位符的情况：agent.service_name=one</li>
     *         <li>占位符的情况一：agent.service_instance=${agent.service_name}_1，最终的结果为one_1</li>
     *         <li>占位符的情况二：agent.service_instance=${PUMA_AGENT_NAME:one}_1，最终的结果为one_1，PUMA_AGENT_NAME从环境变量获取，获取不到取默认值</li>
     *         <li>嵌套占位符的情况</li>
     *     </ol>
     *     </li>
     * </ol>
     *
     * @param agentOptions 命令行参数选项内容
     */
    public static void initializeCoreConfig(String agentOptions) {
        // 1.配置文件方式
        AGENT_SETTINGS = new Properties();
        try (InputStreamReader configFileStream = loadConfig()) {
            // 配置读取到AGENT_SETTINGS
            AGENT_SETTINGS.load(configFileStream);
            for (String key : AGENT_SETTINGS.stringPropertyNames()) {
                String value = (String) AGENT_SETTINGS.get(key);
                AGENT_SETTINGS.put(key, PropertyPlaceholderHelper.INSTANCE.replacePlaceholders(value, AGENT_SETTINGS));
            }
        } catch (Exception e) {
            LogUtil.error(e, "读取插件配置文件失败，将以默认配置方式运行");
        }

        try {
            // 2.系统属性方式
            overrideConfigBySystemProp();
        } catch (Exception e) {
            LogUtil.error(e, "读取系统属性配置失败");
        }

        // 3.启动命令参数设置
        agentOptions = StrUtil.trim(agentOptions, ',');
        if (StrUtil.isNotEmpty(agentOptions)) {
            try {
                agentOptions = agentOptions.trim();
                LogUtil.info("启动参数设置:" + agentOptions);
                overrideConfigByAgentOptions(agentOptions);
            } catch (Exception e) {
                LogUtil.error(e, "解析启动参数设置失败:" + agentOptions);
            }
        }

        // 将配置文件中的属性设置到Config类中去
        initializeConfig(Config.class);

        if (StrUtil.isEmpty(Config.Agent.SERVICE_NAME)) {
            throw new ExceptionInInitializerError("配置缺失:[agent.service_name]");
        }
        IS_INIT_COMPLETED = true;
    }

    public static void initializeConfig(Class<?> configClass) {
        if (AGENT_SETTINGS == null) {
            return;
        }
        try {
            ConfigInitializer.initialize(AGENT_SETTINGS, configClass);
        } catch (IllegalAccessException e) {
            LogUtil.error(e, "配置设置失败:" + configClass.getName());
        }
    }

    private static void overrideConfigByAgentOptions(String agentOptions) throws IllegalArgumentException {
        for (List<String> terms : parseAgentOptions(agentOptions)) {
            if (terms.size() != 2) {
                throw new IllegalArgumentException("[" + terms + "] is not a key-value pair.");
            }
            AGENT_SETTINGS.put(terms.get(0), terms.get(1));
        }
    }

    /**
     * 解析启动命令中的参数选项内容
     *
     * @param agentOptions 参数选项内容
     * @return 两个元素的列表，第一个元素为key，第二个元素为value
     */
    private static List<List<String>> parseAgentOptions(String agentOptions) {
        List<List<String>> options = new ArrayList<>();
        List<String> terms = new ArrayList<>();
        boolean isInQuotes = false;
        StringBuilder currentTerm = new StringBuilder();
        for (char c : agentOptions.toCharArray()) {
            if (c == '\'' || c == '"') {
                isInQuotes = !isInQuotes;
            } else if (c == '=' && !isInQuotes) {
                // 键值对使用'='作为分隔符
                terms.add(currentTerm.toString());
                currentTerm = new StringBuilder();
            } else if (c == ',' && !isInQuotes) {
                // 多个值时使用','作为分隔符
                terms.add(currentTerm.toString());
                currentTerm = new StringBuilder();
                options.add(terms);
                terms = new ArrayList<>();
            } else {
                currentTerm.append(c);
            }
        }
        terms.add(currentTerm.toString());
        options.add(terms);
        return options;
    }

    public static boolean isInitCompleted() {
        return IS_INIT_COMPLETED;
    }

    /**
     * 通过系统属性覆盖，对应的key必须是puma前缀
     * <p>
     * 比如：在插件配置文件中的属性key是agent.service_name，使用系统化变量进行覆盖时，就需要加上puma前缀，即puma.agent.service_name
     */
    private static void overrideConfigBySystemProp() {
        Properties systemProperties = System.getProperties();
        for (Map.Entry<Object, Object> prop : systemProperties.entrySet()) {
            String key = prop.getKey().toString();
            // 判断必须是puma前缀
            if (key.startsWith(ENV_KEY_PREFIX)) {
                // 真实插件配置的key
                String realKey = key.substring(ENV_KEY_PREFIX.length());
                AGENT_SETTINGS.put(realKey, prop.getValue());
            }
        }
    }

    /**
     * 加载通过系统变量指定的插件配置文件或者默认配置文件
     */
    private static InputStreamReader loadConfig() {
        // 默认配置：dist/config/agent.config，可通过puma_config系统变量进行覆盖配置
        String specifiedConfigPath = System.getProperty(SPECIFIED_CONFIG_PATH);
        File configFile = StrUtil.isEmpty(specifiedConfigPath) ?
            new File(AgentPackagePath.getPath(), DEFAULT_CONFIG_FILE_NAME)
            : new File(specifiedConfigPath);

        if (configFile.exists() && configFile.isFile()) {
            try {
                LogUtil.info("加载配置文件:" + configFile.getAbsolutePath());
                return new InputStreamReader(new FileInputStream(configFile), StandardCharsets.UTF_8);
            } catch (FileNotFoundException e) {
                throw new RuntimeException("文件找不到:" + configFile.getName(), e);
            }
        }
        throw new RuntimeException("文件找不到:" + configFile.getName());
    }
}
