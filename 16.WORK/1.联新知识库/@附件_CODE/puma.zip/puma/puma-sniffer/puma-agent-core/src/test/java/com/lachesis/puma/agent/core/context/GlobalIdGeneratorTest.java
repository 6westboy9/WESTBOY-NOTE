package com.lachesis.puma.agent.core.context;

import com.lachesis.puma.agent.core.context.ids.GlobalIdGenerator;
import org.junit.jupiter.api.Test;

class GlobalIdGeneratorTest {

    @Test
    void generate() {
        String id = GlobalIdGenerator.generate();
        System.out.println(id);
        System.out.println(System.nanoTime());
    }
}