package com.lachesis.puma.agent.core.plugin;

public class MethodInvocationContext {

    private final String className;
    private final String methodName;
    private final String descriptor;
    private Object[] params;
    private Throwable throwable;
    private Object returnValue;

    public MethodInvocationContext(String className, String methodName, String descriptor, Object[] params) {
        this.className = className;
        this.methodName = methodName;
        this.descriptor = descriptor;
        this.params = params;
    }

    public MethodInvocationContext(String className, String methodName, String descriptor, Throwable throwable) {
        this.className = className;
        this.methodName = methodName;
        this.descriptor = descriptor;
        this.throwable = throwable;
    }

    public MethodInvocationContext(String className, String methodName, String descriptor, Object returnValue) {
        this.className = className;
        this.methodName = methodName;
        this.descriptor = descriptor;
        this.returnValue = returnValue;
    }

    public void setParams(Object[] params) {
        this.params = params;
    }

    public void setThrowable(Throwable throwable) {
        this.throwable = throwable;
    }

    public void setReturnValue(Object returnValue) {
        this.returnValue = returnValue;
    }

    public String getClassName() {
        return className;
    }

    public String getMethodName() {
        return methodName;
    }

    public String getDescriptor() {
        return descriptor;
    }

    public Object[] getParams() {
        return params;
    }

    public Throwable getThrowable() {
        return throwable;
    }

    public Object getReturnValue() {
        return returnValue;
    }

    public String identifier() {
        return String.format("%s#%s%s", className, methodName, descriptor);
    }
}
