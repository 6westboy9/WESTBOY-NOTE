package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.context.TracingContext;

public abstract class StackBasedTracingSpan extends AbstractTracingSpan {

    protected int stackDepth;
    protected String peer;

    protected StackBasedTracingSpan(int spanId, int parentSpanId, String opName, TracingContext owner) {
        super(spanId, parentSpanId, opName, owner);
        this.stackDepth = 0;
        this.peer = null;
    }

    protected StackBasedTracingSpan(int spanId, int parentSpanId, String opName, String peer, TracingContext owner) {
        super(spanId, parentSpanId, opName, owner);
        this.peer = peer;
    }

    @Override
    public boolean finish(TraceSegment owner) {
        if (--stackDepth == 0) {
            return super.finish(owner);
        } else {
            return false;
        }
    }

    @Override
    public ISpan setPeer(final String remotePeer) {
        this.peer = remotePeer;
        return this;
    }

}
