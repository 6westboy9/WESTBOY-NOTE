package com.lachesis.puma.agent.core.codetrace.samples;

import cn.hutool.core.util.RandomUtil;
import com.lachesis.puma.agent.core.codetrace.asm.MethodInvocationAspect;

import java.util.ArrayList;
import java.util.List;

public class UserServiceImplV2 {

    public UserServiceImplV2() {
    }

    public User getUser() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "getUser", "()Lcom/lachesis/puma/agent/core/codetrace/samples/User;", (Object[])null);

        try {
            User user = new User();
            user.setName("xw");
            user.setAge(18);
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "getUser", "()Lcom/lachesis/puma/agent/core/codetrace/samples/User;", user);
            return user;
        } catch (Throwable var4) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "getUser", "()Lcom/lachesis/puma/agent/core/codetrace/samples/User;", var4);
            throw var4;
        }
    }

    public List<User> listUser() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "()Ljava/util/List;", (Object[])null);

        try {
            ArrayList<User> list = new ArrayList();

            for(int i = 0; i < 3; ++i) {
                User user = new User();
                user.setName("xw");
                user.setAge(18);
                list.add(user);
            }

            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "()Ljava/util/List;", list);
            return list;
        } catch (Throwable var6) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "()Ljava/util/List;", var6);
            throw var6;
        }
    }

    public List<User> listUser(String var1, int age) {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "(Ljava/lang/String;I)Ljava/util/List;", new Object[]{var1, age});

        try {
            ArrayList<User> list = new ArrayList();

            for(int i = 0; i < 3; ++i) {
                int randomAge = RandomUtil.randomInt(15, 20);
                if (randomAge > age) {
                    User user = new User();
                    user.setName("xw");
                    user.setAge(randomAge);
                    list.add(user);
                }
            }

            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "(Ljava/lang/String;I)Ljava/util/List;", list);
            return list;
        } catch (Throwable var9) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "(Ljava/lang/String;I)Ljava/util/List;", var9);
            throw var9;
        }
    }

    public List<User> listUser(UserQuery query) {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "(Lcom/lachesis/puma/agent/core/codetrace/samples/UserQuery;)Ljava/util/List;", new Object[]{query});

        try {
            List var2;
            List var10000 = var2 = this.listUser(query.getName(), query.getAge());
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "(Lcom/lachesis/puma/agent/core/codetrace/samples/UserQuery;)Ljava/util/List;", var2);
            return var10000;
        } catch (Throwable var4) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "listUser", "(Lcom/lachesis/puma/agent/core/codetrace/samples/UserQuery;)Ljava/util/List;", var4);
            throw var4;
        }
    }

    public void test() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test", "()V", (Object[])null);

        try {
            this.test1();
            this.test2();
            this.test3();
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test", "()V", var3);
            throw var3;
        }
    }

    private void test3() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test3", "()V", (Object[])null);

        try {
            this.test31();
            this.test32();
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test3", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test3", "()V", var3);
            throw var3;
        }
    }

    private void test32() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test32", "()V", (Object[])null);

        try {
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test32", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test32", "()V", var3);
            throw var3;
        }
    }

    private void test31() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test31", "()V", (Object[])null);

        try {
            this.test311();
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test31", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test31", "()V", var3);
            throw var3;
        }
    }

    private void test311() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test311", "()V", (Object[])null);

        try {
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test311", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test311", "()V", var3);
            throw var3;
        }
    }

    private void test2() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test2", "()V", (Object[])null);

        try {
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test2", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test2", "()V", var3);
            throw var3;
        }
    }

    private void test1() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test1", "()V", (Object[])null);

        try {
            this.test11();
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test1", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test1", "()V", var3);
            throw var3;
        }
    }

    private void test11() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test11", "()V", (Object[])null);

        try {
            this.test111();
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test11", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test11", "()V", var3);
            throw var3;
        }
    }

    private void test111() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test111", "()V", (Object[])null);

        try {
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test111", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "test111", "()V", var3);
            throw var3;
        }
    }

    public void testAsync() {
        MethodInvocationAspect.beforeMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "testAsync", "()V", (Object[])null);

        try {
            (new Thread(this::test)).start();
            MethodInvocationAspect.afterMethod("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "testAsync", "()V", (Object)null);
        } catch (Throwable var3) {
            MethodInvocationAspect.handleEx("com/lachesis/puma/agent/core/codetrace/samples/UserServiceImpl", "testAsync", "()V", var3);
            throw var3;
        }
    }
}
