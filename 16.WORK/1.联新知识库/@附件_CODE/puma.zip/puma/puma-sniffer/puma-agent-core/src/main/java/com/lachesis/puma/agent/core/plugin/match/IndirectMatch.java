package com.lachesis.puma.agent.core.plugin.match;

import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;

/**
 * 非NameMatch的情况
 * <p>
 * 间接匹配
 */
public interface IndirectMatch extends ClassMatch {

    ElementMatcher.Junction<? super TypeDescription> buildJunction();

    boolean isMatch(TypeDescription typeDescription);
}
