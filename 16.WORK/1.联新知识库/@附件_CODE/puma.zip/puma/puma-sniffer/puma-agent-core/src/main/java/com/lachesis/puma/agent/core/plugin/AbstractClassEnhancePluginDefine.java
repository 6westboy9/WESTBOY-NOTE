package com.lachesis.puma.agent.core.plugin;

import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.util.LogUtil;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.DynamicType;

import java.util.List;

public abstract class AbstractClassEnhancePluginDefine {

    /**
     * 为匹配到的字节码新增的新属性名称
     */
    public static final String CONTEXT_ATTR_NAME = "_$EnhancedClassField_";
    /**
     * 获取当前插件要增强的类
     */
    public abstract ClassMatch enhanceClass();
    /**
     * 获取构造方法的拦截点
     */
    public abstract MethodsInterceptorPoint[] getConstructorMethodsInterceptorPoints();
    /**
     * 获取实例方法的拦截点
     */
    public abstract MethodsInterceptorPoint[] getStaticMethodsInterceptorPoints();
    /**
     * 获取实例方法的拦截点
     */
    public abstract MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints();

    public DynamicType.Builder<?> define(TypeDescription typeDescription, DynamicType.Builder<?> builder, ClassLoader classLoader, EnhanceContext context) {
        String pluginDefineClassName = this.getClass().getName();
        String transformClassName = typeDescription.getTypeName();
        if (StrUtil.isEmpty(transformClassName)) {
            LogUtil.info(String.format("被拦截的类无法被[%s]增强", pluginDefineClassName));
            return null;
        }
        // LogUtil.info(String.format("开始使用[%s]增强[%s]", pluginDefineClassName, transformClassName));
        DynamicType.Builder<?> newBuilder = enhance(typeDescription, builder, classLoader, context);
        context.initializationStageCompleted();
        return newBuilder;
    }

    /**
     * 增强实现
     */
    private DynamicType.Builder<?> enhance(TypeDescription typeDescription, DynamicType.Builder<?> builder, ClassLoader classLoader, EnhanceContext context) {
        // 静态方法增强
        builder = enhanceClass(typeDescription, builder, classLoader);
        // 构造方法和实例方法增强
        builder = enhanceInstance(typeDescription, builder, classLoader, context);
        return builder;
    }

    /**
     * 增强静态方法
     */
    protected abstract DynamicType.Builder<?> enhanceClass(TypeDescription typeDescription, DynamicType.Builder<?> builder, ClassLoader classLoader);

    /**
     * 增强实例方法和构造方法
     */
    protected abstract DynamicType.Builder<?> enhanceInstance(TypeDescription typeDescription, DynamicType.Builder<?> builder, ClassLoader classLoader, EnhanceContext context);

    /**
     * 针对组件依赖包的不同版本，插件增强的处理逻辑不同，因此需要不同组件版本的插件
     * <p>
     * 根据是否存在一个或多个类仅同时存在于某一个版本中来确定插件版本
     *
     * @return 类名称
     */
    protected String[] witnessClasses() {
        return new String[]{};
    }

    /**
     * 当witnessClasses判断不出组件版本时，就使用witnessMethods
     * <p>
     * 假设Spring5.x相对比Spring4.x并没有新增新的类，不能通过类的差异化判断是Spring4.x还是Spring5.x，
     * 但是在Spring4.x的C类中有getCache()方法返回值是int类型参数类型为a、b，在Spring5.x的C类中返回值改为了long类型参数类型改为a，
     * 这时候就判断当应用中的C类型包含int getCache(a,b)方法时，spring-v4-plugin插件生效；
     * 当应用中的C类型包含long getCache(a)方法时，spring-v5-plugin插件生效
     *
     * @return {@link WitnessMethod}
     */
    protected List<WitnessMethod> witnessMethods() {
        return null;
    }

    /**
     *
     * @return
     */
    public boolean isBootstrapInstrumentation() {
        return false;
    }

}
