package com.lachesis.puma.agent.core.codetrace.samples;

import cn.hutool.core.util.RandomUtil;

import java.util.ArrayList;
import java.util.List;

public class UserServiceImpl implements UserService {

    @Override
    public User getUser() {
        User user = new User();
        user.setName("xw");
        user.setAge(18);
        return user;
    }

    @Override
    public List<User> listUser() {
        ArrayList<User> list = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            User user = new User();
            user.setName("xw");
            user.setAge(18);
            list.add(user);
        }
        return list;
    }

    @Override
    public List<User> listUser(String name, int age) {
        ArrayList<User> list = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            int randomAge = RandomUtil.randomInt(15, 20);
            if (randomAge > age) {
                User user = new User();
                user.setName("xw");
                user.setAge(randomAge);
                list.add(user);
            }
        }
        return list;
    }

    @Override
    public List<User> listUser(UserQuery query) {
        return listUser(query.getName(), query.getAge());
    }

    @Override
    public int test() {
        test1(1);
        int r2 = test2(2);
        return test3(r2);
    }

    private int test3(int i) {
        // String s = test31(3.0);
        return test32();
    }

    private int test32() {
        return 111;
    }

    // private String test31(double d) {
    //     return test311(d);
    // }
    //
    // private String test311(double d) {
    //     return "hello" + d;
    // }

    private int test2(int i) {
        return i + 1;
    }

    private void test1(int i) {
        test11();
    }

    private void test11() {
        test111();
    }

    private void test111() {

    }

    @Override
    public void testAsync() {
        new Thread(this::test).start();
    }
}
