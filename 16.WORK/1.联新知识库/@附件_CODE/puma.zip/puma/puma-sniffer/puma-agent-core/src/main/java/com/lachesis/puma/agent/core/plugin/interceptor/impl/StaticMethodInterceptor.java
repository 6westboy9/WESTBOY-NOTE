package com.lachesis.puma.agent.core.plugin.interceptor.impl;

import com.lachesis.puma.agent.core.plugin.MethodInvocationContext;
import com.lachesis.puma.agent.core.plugin.interceptor.StaticMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.plugin.loader.InterceptorLoader;
import com.lachesis.puma.agent.core.util.LogUtil;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bind.annotation.AllArguments;
import net.bytebuddy.implementation.bind.annotation.Origin;
import net.bytebuddy.implementation.bind.annotation.RuntimeType;
import net.bytebuddy.implementation.bind.annotation.SuperCall;

import java.lang.reflect.Method;
import java.util.concurrent.Callable;

public class StaticMethodInterceptor {

    private static final String TAG = "[静态方法]";
    private String transformClassName;
    private StaticMethodsAroundInterceptor interceptor;

    public StaticMethodInterceptor(String transformClassName, String interceptorClass, ClassLoader classLoader) {
        try {
            this.transformClassName = transformClassName;
            interceptor = InterceptorLoader.load(interceptorClass, classLoader);
        } catch (Throwable t) {
            LogUtil.error(t, String.format("加载静态方法拦截器[%s]异常", interceptorClass));
        }
    }

    @RuntimeType
    public Object intercept(@Origin Class<?> clazz, @Origin Method method, @AllArguments Object[] arguments, @SuperCall Callable<?> zuper) throws Throwable {
        String interceptorName = interceptor.getClass().getSimpleName();
        MethodDescription.ForLoadedMethod forLoadedMethod = new MethodDescription.ForLoadedMethod(method);
        String descriptor = forLoadedMethod.getDescriptor();
        String methodName = method.getName();
        MethodInvocationContext context = new MethodInvocationContext(transformClassName, methodName, descriptor, arguments);
        try {
            // LogUtil.info(String.format("%-30s 开始%s:%s", interceptorName, TAG, context.identifier()));
            interceptor.beforeMethod(clazz, method, arguments, method.getParameterTypes());
        } catch (Throwable t) {
            LogUtil.error(t, String.format("%-30s 开始(增长处理异常)%s:%s", interceptorName, TAG, context.identifier()));
        }

        Object call = null;
        try {
            call = zuper.call();
        } catch (Throwable t) {
            try {
                // LogUtil.error(t, String.format("%-30s 异常%s:%s", interceptorName, TAG, context.identifier()));
                interceptor.handleEx(clazz, method, arguments, method.getParameterTypes(), t);
            } catch (Throwable throwable) {
                LogUtil.error(throwable, String.format("%-30s 异常(增强处理异常)%s:%s", interceptorName, TAG, context.identifier()));
            }
            throw t;
        } finally {
            try {
                // LogUtil.info(String.format("%-30s 结束%s:%s", interceptorName, TAG, context.identifier()));
                call = interceptor.afterMethod(clazz, method, arguments, method.getParameterTypes(), call);
            } catch (Throwable throwable) {
                LogUtil.error(throwable, String.format("%-30s 结束(增强处理异常)%s:%s", interceptorName, TAG, context.identifier()));
            }
        }
        return call;
    }
}
