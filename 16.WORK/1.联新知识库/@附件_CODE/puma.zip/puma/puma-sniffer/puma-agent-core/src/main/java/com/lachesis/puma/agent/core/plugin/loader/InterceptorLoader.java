package com.lachesis.puma.agent.core.plugin.loader;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("unchecked")
public class InterceptorLoader {

    private static final ConcurrentHashMap<String, Object> INSTANCE_CACHE = new ConcurrentHashMap<>();
    /**
     * k: 加载当前插件要拦截的那个类的类加载器
     * <p>
     * v: 既能加载插件拦截器，又能加载拦截的那个类的类加载器
     */
    private static final Map<ClassLoader, ClassLoader> EXTEND_PLUGIN_CLASSLOADERS = new HashMap<>();

    public static <T> T load(String interceptorClassName, ClassLoader targetClassLoader) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        if (targetClassLoader == null) {
            targetClassLoader = InterceptorLoader.class.getClassLoader();
        }
        String instanceKey = interceptorClassName + "_OF_" + targetClassLoader.getClass().getName() + "@" + Integer.toHexString(targetClassLoader.hashCode());
        Object interceptor = INSTANCE_CACHE.get(instanceKey);
        if (interceptor == null) {
            ClassLoader pluginClassLoader;
            synchronized (InterceptorLoader.class) {
                pluginClassLoader = EXTEND_PLUGIN_CLASSLOADERS.get(targetClassLoader);
                if (pluginClassLoader == null) {
                    // 为什么每个拦截器都要重新new一个AgentClassLoader对象，而不是所有的拦截器共用一个AgentClassLoader呢？
                    // 因为每个拦截器拦截的类的类加载器可能不同
                    // 基于类的加载机制，拦截器要访问被拦截的类，必须指定拦截器对应父类加载器为被拦截器类的类加载器
                    // 被拦截的类是不可见的
                    pluginClassLoader = new AgentClassLoader(targetClassLoader);
                    EXTEND_PLUGIN_CLASSLOADERS.put(targetClassLoader, pluginClassLoader);
                }
            }
            Class<?> clazz = Class.forName(interceptorClassName, true, pluginClassLoader);
            interceptor = clazz.newInstance();
            INSTANCE_CACHE.put(instanceKey, interceptor);
        }
        return (T) interceptor;
    }

    public static void register(AgentClassLoader pluginClassLoader, ClassLoader targetClassLoader) {
        EXTEND_PLUGIN_CLASSLOADERS.put(targetClassLoader, pluginClassLoader);
    }
}
