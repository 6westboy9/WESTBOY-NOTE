package com.lachesis.puma.agent.core.plugin;

import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.IndirectMatch;
import com.lachesis.puma.agent.core.plugin.match.NameMatch;
import net.bytebuddy.description.NamedElement;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;

import java.util.*;

import static net.bytebuddy.matcher.ElementMatchers.*;

public class PluginFinder {

    /**
     * 用于存储ClassMatch类型为NameMatch的插件
     */
    private final Map<String, LinkedList<AbstractClassEnhancePluginDefine>> nameMatchDefine = new HashMap<>();
    /**
     * 用于存储ClassMatch类型为IndirectMatch的插件
     */
    private final List<AbstractClassEnhancePluginDefine> signatureMatchDefine = new ArrayList<>();
    /**
     * 用于存储JDK类库的插件
     */
    private final List<AbstractClassEnhancePluginDefine> bootstrapClassMatchDefine = new ArrayList<>();

    /**
     * 对插件进行分类
     */
    public PluginFinder(List<AbstractClassEnhancePluginDefine> plugins) {
        for (AbstractClassEnhancePluginDefine plugin : plugins) {
            ClassMatch classMatch = plugin.enhanceClass();
            if (classMatch == null) {
                continue;
            }
            if (classMatch instanceof NameMatch) {
                NameMatch nameMatch = (NameMatch) classMatch;
                LinkedList<AbstractClassEnhancePluginDefine> list = nameMatchDefine.computeIfAbsent(nameMatch.getClassName(), a -> new LinkedList<>());
                list.add(plugin);
            } else {
                signatureMatchDefine.add(plugin);
            }

            // 基于JDK类库的插件
            if (plugin.isBootstrapInstrumentation()) {
                bootstrapClassMatchDefine.add(plugin);
            }
        }
    }

    public ElementMatcher.Junction<? super TypeDescription> buildMather() {
        ElementMatcher.Junction<? super TypeDescription> matcher = new ElementMatcher.Junction.AbstractBase<NamedElement>() {
            @Override
            public boolean matches(NamedElement target) {
                return nameMatchDefine.containsKey(target.getActualName());
            }
        };
        // 排除接口
        matcher = matcher.and(not(isInterface()));
        for (AbstractClassEnhancePluginDefine pluginDefine : signatureMatchDefine) {
            // 类匹配
            ClassMatch classMatch = pluginDefine.enhanceClass();
            if (classMatch instanceof IndirectMatch) {
                IndirectMatch indirectMatch = (IndirectMatch) classMatch;
                matcher = matcher.or(indirectMatch.buildJunction().and(not(isInterface())));
            }
        }
        return matcher;
    }

    public List<AbstractClassEnhancePluginDefine> find(TypeDescription typeDescription) {
        List<AbstractClassEnhancePluginDefine> matchedPlugins = new LinkedList<>();
        String typeName = typeDescription.getTypeName();
        if (nameMatchDefine.containsKey(typeName)) {
            matchedPlugins.addAll(nameMatchDefine.get(typeName));
        }
        for (AbstractClassEnhancePluginDefine pluginDefine : signatureMatchDefine) {
            IndirectMatch indirectMatch = (IndirectMatch) pluginDefine.enhanceClass();
            if (indirectMatch.isMatch(typeDescription)) {
                matchedPlugins.add(pluginDefine);
            }
        }
        return matchedPlugins;
    }

    public List<AbstractClassEnhancePluginDefine> getBootstrapClassMatchDefine() {
        return bootstrapClassMatchDefine;
    }
}
