package com.lachesis.puma.agent.core.plugin.match;

import net.bytebuddy.description.type.TypeDescription;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class RegexMatchTest {

    private static final String[] REGEX = new String[]{".*Service.*", ".*Repository.*"};

    @Test
    void testRegexMatch() {
        RegexMatch regexMatch = RegexMatch.byRegexMatch(REGEX);
        TypeDescription typeDefinition = TypeDescription.ForLoadedType.of(TestService.class);
        // com.lachesis.puma.agent.core.plugin.match.RegexMatchTest$TestService
        Assertions.assertTrue(regexMatch.isMatch(typeDefinition));
    }

    public static class TestService {

    }

}