package com.lachesis.puma.agent.core.plugin.interceptor;

import java.lang.reflect.Constructor;

/**
 * 构造方法拦截器必须实现这个接口
 */
public interface InstanceConstructorInterceptor {

    /**
     * 在构造器执行后调用
     */
    void onConstruct(EnhancedInstance instance, Constructor<?> constructor, Object[] arguments);
}
