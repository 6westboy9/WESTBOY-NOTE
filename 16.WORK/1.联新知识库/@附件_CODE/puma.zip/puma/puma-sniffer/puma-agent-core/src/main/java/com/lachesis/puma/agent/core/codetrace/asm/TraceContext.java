package com.lachesis.puma.agent.core.codetrace.asm;

import java.io.PrintStream;
import java.util.Collection;

public class TraceContext {

    private static final ThreadLocal<TraceContext> contexts = new ThreadLocal<>();

    private boolean init;
    private TraceNode root;
    private TraceNode current;
    private long createTime;
    private boolean running;

    public boolean isInit() {
        return init;
    }

    public void setInit(boolean init) {
        this.init = init;
    }

    public TraceNode getRoot() {
        return root;
    }

    public void setRoot(TraceNode root) {
        this.root = root;
    }

    public TraceNode getCurrent() {
        return current;
    }

    public void setCurrent(TraceNode current) {
        this.current = current;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public boolean isRunning() {
        return running;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }

    public void print(TraceNode node, PrintStream out) {
        if (node != null) {
            out.println(node);
            Collection<TraceNode> children = node.getChildren();
            if (children.isEmpty()) {
                return;
            }
            for (TraceNode child : children) {
                print(child, out);
            }
        }
    }
}
