package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.boot.Config;
import com.lachesis.puma.agent.core.context.ids.GlobalIdGenerator;
import com.lachesis.puma.agent.core.context.ids.DistributedTraceId;
import com.lachesis.puma.agent.core.context.ids.NewDistributedTraceId;
import com.lachesis.puma.protocol.network.SegmentData;

import java.util.LinkedList;
import java.util.List;

/**
 * 与线程绑定：一个JVM进程内的一个线程对应一个TraceSegment
 * <p>
 * 一个Trace是由多个TraceSegment组成的
 */
public class TraceSegment {

    /**
     * 全局唯一，单个TraceSegment唯一标识
     */
    private final String traceSegmentId;
    private final List<AbstractTracingSpan> spans;
    /**
     * 该字段并不会被序列化，只为快速访问整条链路，通过该引用快速定位parent的TraceSegment
     */
    private TraceSegmentRef ref;
    /**
     * 关联的TraceId
     */
    private DistributedTraceId relatedGlobalTraceId;

    public TraceSegment() {
        this.traceSegmentId = GlobalIdGenerator.generate();
        this.spans = new LinkedList<>();
        this.relatedGlobalTraceId = new NewDistributedTraceId();
    }

    /**
     * 将当前Segment关联到某一个Trace上去
     */
    public void relatedGlobalTrace(DistributedTraceId distributedTraceId) {
        if (relatedGlobalTraceId instanceof NewDistributedTraceId) {
            this.relatedGlobalTraceId = distributedTraceId;
        }
    }

    public String getTraceSegmentId() {
        return traceSegmentId;
    }

    public DistributedTraceId getRelatedGlobalTraceId() {
        return relatedGlobalTraceId;
    }

    public DistributedTraceId getRelatedTraceId() {
        return relatedGlobalTraceId;
    }

    public TraceSegmentRef getRef() {
        return ref;
    }

    public void ref(TraceSegmentRef refSegment) {
        if (null == ref) {
            this.ref = refSegment;
        }
    }

    public void archive(AbstractTracingSpan finishedSpan) {
        spans.add(finishedSpan);
    }

    /**
     * 序列化可传输对象数据
     *
     * @return 序列化后的可传输对象数据
     */
    public SegmentData transform() {
        SegmentData segmentData = new SegmentData();
        segmentData.setTraceId(getRelatedGlobalTraceId().getId());
        segmentData.setTraceSegmentId(traceSegmentId);
        for (AbstractTracingSpan span : spans) {
            segmentData.addSpan(span.transform());
        }
        // 目前来说非必要
        segmentData.setService(Config.Agent.SERVICE_NAME);
        segmentData.setServiceInstance(Config.Agent.INSTANCE_NAME);
        return segmentData;
    }
}
