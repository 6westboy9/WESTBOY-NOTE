package com.lachesis.puma.agent.core.context.trace;

import com.lachesis.puma.agent.core.context.tag.StringTag;
import com.lachesis.puma.protocol.component.Component;
import com.lachesis.puma.protocol.network.SpanLayer;

public interface ISpan {

    void setComponent(Component component);

    void setLayer(SpanLayer spanLayer);

    boolean isEntry();

    boolean isExit();

    ISpan tag(StringTag tag, String value);

    ISpan log(Throwable t);

    ISpan errorOccurred();

    ISpan setOpName(String opName);

    ISpan start();

    ISpan setPeer(String remotePeer);

    int getSpanId();

    String getOpName();

    void ref(TraceSegmentRef ref);


}
