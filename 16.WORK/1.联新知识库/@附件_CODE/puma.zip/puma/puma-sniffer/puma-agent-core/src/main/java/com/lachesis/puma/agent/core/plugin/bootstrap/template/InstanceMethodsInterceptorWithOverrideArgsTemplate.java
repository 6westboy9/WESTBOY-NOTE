package com.lachesis.puma.agent.core.plugin.bootstrap.template;

import com.lachesis.puma.agent.core.plugin.BootstrapInterceptorRuntimeAssist;
import com.lachesis.puma.agent.core.plugin.MethodInvocationContext;
import com.lachesis.puma.agent.core.plugin.OverrideCallable;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.bind.annotation.*;

import java.lang.reflect.Method;

/**
 * 仅仅是在字节码增强时当做模板使用
 */
public class InstanceMethodsInterceptorWithOverrideArgsTemplate {

    private static final String TAG = "[实例方法]";
    private static String targetInterceptor;
    private static String transformClassName;
    private static InstanceMethodsAroundInterceptor interceptor;

    @RuntimeType
    public static Object intercept(@This Object obj, @Origin Method method, @AllArguments Object[] arguments, @Morph OverrideCallable zuper) throws Throwable {
        EnhancedInstance instance = (EnhancedInstance) obj;

        // 重要
        prepare();

        String interceptorName = "";
        if (interceptor != null) {
            interceptorName = interceptor.getClass().getSimpleName();
        }

        MethodDescription.ForLoadedMethod forLoadedMethod = new MethodDescription.ForLoadedMethod(method);
        String descriptor = forLoadedMethod.getDescriptor();
        String methodName = method.getName();

        MethodInvocationContext context = new MethodInvocationContext(transformClassName, methodName, descriptor, arguments);
        try {
            // LogUtil.info(String.format("%-30s 开始%s:%s", interceptorName, TAG, context.identifier()));
            if (interceptor != null) {
                interceptor.beforeMethod(instance, method, arguments, method.getParameterTypes());
            }
        } catch (Throwable t) {
            LogUtil.info(String.format("%-30s 开始(增长处理异常)%s:%s", interceptorName, TAG, context.identifier()));
        }

        Object call = null;
        try {
            call = zuper.call(arguments);
        } catch (Throwable t) {
            try {
                // LogUtil.error(t, String.format("%-30s 异常%s:%s", interceptorName, TAG, context.identifier()));
                if (interceptor != null) {
                    interceptor.handleEx(instance, method, arguments, method.getParameterTypes(), t);
                }
            } catch (Throwable throwable) {
                LogUtil.error(throwable, String.format("%-30s 异常(增强处理异常)%s:%s", interceptorName, TAG, context.identifier()));
            }
            throw t;
        } finally {
            try {
                // LogUtil.info(String.format("%-30s 结束%s:%s", interceptorName, TAG, context.identifier()));
                if (interceptor != null) {
                    call = interceptor.afterMethod(instance, method, arguments, method.getParameterTypes(), call);
                }
            } catch (Throwable throwable) {
                LogUtil.error(throwable, String.format("%-30s 结束(增强处理异常)%s:%s", interceptorName, TAG, context.identifier()));
            }
        }
        return call;
    }

    private static void prepare() {
        if (interceptor == null) {
            ClassLoader classLoader = BootstrapInterceptorRuntimeAssist.getAgentClassLoader();
            if (classLoader != null) {
                // TODO 日志
                interceptor = BootstrapInterceptorRuntimeAssist.createInterceptor(classLoader, targetInterceptor);
            }
        }
    }
}