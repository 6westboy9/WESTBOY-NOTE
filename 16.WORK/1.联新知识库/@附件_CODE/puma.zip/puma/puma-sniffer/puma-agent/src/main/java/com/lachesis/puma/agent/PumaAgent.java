package com.lachesis.puma.agent;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.FileUtil;
import com.lachesis.puma.agent.core.boot.SnifferConfigInitializer;
import com.lachesis.puma.agent.core.context.reporter.HttpTraceSegmentServiceClient;
import com.lachesis.puma.agent.core.plugin.AbstractClassEnhancePluginDefine;
import com.lachesis.puma.agent.core.plugin.EnhanceContext;
import com.lachesis.puma.agent.core.plugin.PluginBootstrap;
import com.lachesis.puma.agent.core.plugin.PluginFinder;
import com.lachesis.puma.agent.core.plugin.bootstrap.BootstrapInstrumentBoost;
import com.lachesis.puma.agent.core.util.LogUtil;
import net.bytebuddy.ByteBuddy;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.DynamicType;
import net.bytebuddy.dynamic.scaffold.TypeValidation;
import net.bytebuddy.utility.JavaModule;

import java.io.File;
import java.io.IOException;
import java.lang.instrument.Instrumentation;
import java.util.List;

import static net.bytebuddy.matcher.ElementMatchers.*;

public class PumaAgent {

    private static final String MARK = "##################################################################";

    public static void premain(String agentOps, Instrumentation instrumentation) {
        LogUtil.info(MARK);
        try {
            try {
                // 插件配置解析
                SnifferConfigInitializer.initializeCoreConfig(agentOps);
            } catch (Exception e) {
                LogUtil.error(e, "配置解析异常，关闭中...");
                return;
            }

            List<AbstractClassEnhancePluginDefine> pluginDefines = PluginBootstrap.loadPluginDefines();
            if (CollUtil.isEmpty(pluginDefines)) {
                LogUtil.info(MARK);
                return;
            }

            PluginFinder pluginFinder = new PluginFinder(pluginDefines);
            AgentBuilder builder = new AgentBuilder.Default(new ByteBuddy()
                .with(TypeValidation.ENABLED));
            builder.ignore(nameStartsWith("net.bytebuddy")
                .or(nameStartsWith("sun.reflect"))
                .or(nameStartsWith("com.lachesis.puma.agent"))
                .or(nameContains("javassist"))
                .or(nameContains(".reflectasm."))
                .or(nameContains(".asm."))
                .or(isSynthetic()));

            try {
                // 基于JDK类库的增强，处理与非JDK类库是完全不一样的
                builder = BootstrapInstrumentBoost.inject(pluginFinder, instrumentation, builder);
            } catch (Exception e) {
                LogUtil.error(e, "Bootstrap增强异常，关闭中...");
                return;
            }

            builder.type(pluginFinder.buildMather())
                .transform(new Transformer(pluginFinder))
                .with(AgentBuilder.RedefinitionStrategy.RETRANSFORMATION)
                .with(new AgentBuilder.Listener() {
                    @Override
                    public void onDiscovery(String typeName, ClassLoader classLoader, JavaModule module, boolean loaded) {

                    }

                    @Override
                    public void onTransformation(TypeDescription typeDescription, ClassLoader classLoader, JavaModule module, boolean loaded, DynamicType dynamicType) {
                        // LogUtil.info("--------------------------- 开始写入字节码:" + typeDescription.getTypeName());
                        try {
                            dynamicType.saveIn(new File("D:\\IdeaProjects\\mine\\puma\\dist\\bytes\\"));
                        } catch (IOException e) {
                            LogUtil.error(e, "字节码写入异常:" + typeDescription.getTypeName());
                        }
                        // FileUtil.writeBytes(dynamicType.getBytes(),  + typeDescription.getTypeName() + ".class");
                    }

                    @Override
                    public void onIgnored(TypeDescription typeDescription, ClassLoader classLoader, JavaModule module, boolean loaded) {

                    }

                    @Override
                    public void onError(String typeName, ClassLoader classLoader, JavaModule module, boolean loaded, Throwable throwable) {
                        LogUtil.error(throwable, String.format("增强异常:%s", typeName));
                    }

                    @Override
                    public void onComplete(String typeName, ClassLoader classLoader, JavaModule module, boolean loaded) {

                    }
                })
                .installOn(instrumentation);

            HttpTraceSegmentServiceClient.init();
            Runtime.getRuntime().addShutdownHook(new Thread(() -> LogUtil.info("关闭中...")));
        } catch (Throwable throwable) {
            LogUtil.error(throwable, MARK);
        } finally {
            LogUtil.info(MARK);
        }
    }

    private static class Transformer implements AgentBuilder.Transformer {

        private final PluginFinder pluginFinder;

        public Transformer(PluginFinder pluginFinder) {
            this.pluginFinder = pluginFinder;
        }

        @Override
        public DynamicType.Builder<?> transform(DynamicType.Builder<?> builder, TypeDescription typeDescription, ClassLoader classLoader, JavaModule module) {
            // LogUtil.info(String.format("TO:%s", typeDescription.getTypeName()));
            List<AbstractClassEnhancePluginDefine> pluginDefines = pluginFinder.find(typeDescription);
            if (!pluginDefines.isEmpty()) {
                DynamicType.Builder<?> newBuilder = builder;
                EnhanceContext context = new EnhanceContext();
                for (AbstractClassEnhancePluginDefine pluginDefine : pluginDefines) {
                    DynamicType.Builder<?> possibleNewBuilder = pluginDefine.define(typeDescription, newBuilder, classLoader, context);
                    // 注意:ByteBuddy大部分类都是不可变对象~
                    if (possibleNewBuilder != null) {
                        newBuilder = possibleNewBuilder;
                    }
                }
                if (context.isEnhanced()) {
                    // LogUtil.info(String.format("增强完成:%s", typeDescription.getTypeName()));
                }
                return newBuilder;
            }
            return builder;
        }
    }
}
