package com.lachesis.puma.agent;

import com.lachesis.puma.agent.core.codetrace.asm.MethodInvocationTransformer;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.lang.instrument.Instrumentation;

/**
 * 仅限测试使用
 */
public class PumaTestAgent {
    public static void premain(String agentOps, Instrumentation instrumentation) {
        LogUtil.info("======================");
        // instrumentation.addTransformer(new CodeTraceTransformer());
        instrumentation.addTransformer(new MethodInvocationTransformer(0));
    }
}
