package com.lachesis.puma.agent.plugin.mysql5x;

public class Mysql5xConnectionInstrumentation {
}
