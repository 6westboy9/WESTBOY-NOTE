package com.lachesis.puma.agent.jdbc.point;

import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.jdbc.PumaAgentJdbcConstants;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static net.bytebuddy.matcher.ElementMatchers.named;
import static net.bytebuddy.matcher.ElementMatchers.none;

public class PSSetterDefinitionOfJDBCMethodsInterceptorPoint implements MethodsInterceptorPoint {

    private final boolean ignorable;
    private static final Set<String> PS_IGNORABLE_SETTERS = new HashSet<>(Arrays.asList("setAsciiStream", "setBinaryStream", "setBlob",
        "setBytes", "setCharacterStream", "setClob", "setNCharacterStream", "setNClob", "setRef", "setSQLXML", "setUnicodeStream"));
    private static final Set<String> PS_SETTERS = new HashSet<>(Arrays.asList("setArray", "setBigDecimal", "setBoolean", "setByte",
        "setDate", "setDouble", "setFloat", "setInt", "setLong", "setNString", "setObject", "setRowId", "setShort", "setString", "setTime", "setTimestamp", "setURL"));

    public PSSetterDefinitionOfJDBCMethodsInterceptorPoint(boolean ignorable) {
        this.ignorable = ignorable;
    }

    @Override
    public ElementMatcher<MethodDescription> getMatcher() {
        ElementMatcher.Junction<MethodDescription> matcher = none();
            final Set<String> setters = ignorable ? PS_IGNORABLE_SETTERS : PS_SETTERS;
            for (String setter : setters) {
                matcher = matcher.or(named(setter));
            }

        return matcher;
    }

    @Override
    public String getInterceptor() {
        return ignorable ? PumaAgentJdbcConstants.PREPARED_STATEMENT_IGNORABLE_SETTER_METHODS_INTERCEPTOR : PumaAgentJdbcConstants.PREPARED_STATEMENT_SETTER_METHODS_INTERCEPTOR;
    }
}
