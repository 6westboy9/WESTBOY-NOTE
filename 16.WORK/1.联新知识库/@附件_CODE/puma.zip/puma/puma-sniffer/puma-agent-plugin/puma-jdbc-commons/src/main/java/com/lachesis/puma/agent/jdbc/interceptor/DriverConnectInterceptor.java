package com.lachesis.puma.agent.jdbc.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.agent.jdbc.ConnectionCache;
import com.lachesis.puma.agent.jdbc.ConnectionInfo;
import com.lachesis.puma.agent.jdbc.connectionurl.parser.URLParser;

import java.lang.reflect.Method;

public class DriverConnectInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        ConnectionInfo connectionInfo = URLParser.parser(arguments[0].toString());
        LogUtil.info(false, String.format("建立连接URL:%s", connectionInfo.getUrl()));
        ConnectionCache.save(connectionInfo);
    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}
