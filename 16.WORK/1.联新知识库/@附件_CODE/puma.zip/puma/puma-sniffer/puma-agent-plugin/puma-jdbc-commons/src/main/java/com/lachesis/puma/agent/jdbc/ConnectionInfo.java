package com.lachesis.puma.agent.jdbc;

import com.lachesis.puma.protocol.component.Component;

public class ConnectionInfo {

    private final String dbType;
    // windranger_hospital
    private String databaseName;
    // 10.2.3.114:3306
    private String databasePeer;
    private final Component component;
    // jdbc:mysql://10.2.3.114:3306/windranger_hospital?characterEncoding=utf8&serverTimezone=GMT%2B8
    private final String url;

    public ConnectionInfo(Component component, String dbType, String host, int port, String databaseName, String url) {
        this.dbType = dbType;
        this.url = url;
        this.databasePeer = host + ":" + port;
        this.databaseName = databaseName;
        this.component = component;
    }

    public ConnectionInfo(Component component, String dbType, String hosts, String databaseName, String url) {
        this.dbType = dbType;
        this.databasePeer = hosts;
        this.databaseName = databaseName;
        this.component = component;
        this.url = url;
    }

    public String getDbType() {
        return dbType;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getDatabasePeer() {
        return databasePeer;
    }

    public void setDatabasePeer(String databasePeer) {
        this.databasePeer = databasePeer;
    }

    public Component getComponent() {
        return component;
    }

    public String getUrl() {
        return url;
    }
}
