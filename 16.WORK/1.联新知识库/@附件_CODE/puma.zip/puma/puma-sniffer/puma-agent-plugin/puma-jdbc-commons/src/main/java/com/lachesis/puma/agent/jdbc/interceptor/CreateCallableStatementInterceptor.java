
package com.lachesis.puma.agent.jdbc.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.jdbc.ConnectionInfo;
import com.lachesis.puma.agent.jdbc.StatementEnhanceInfo;

import java.lang.reflect.Method;

public class CreateCallableStatementInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {

    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        if (result instanceof EnhancedInstance) {
            ConnectionInfo connectionInfo = (ConnectionInfo) instance.getSkyWalkingDynamicField();
            StatementEnhanceInfo enhanceInfos = new StatementEnhanceInfo(connectionInfo, (String) arguments[0], "CallableStatement");
            ((EnhancedInstance) result).setSkyWalkingDynamicField(enhanceInfos);
        }
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}
