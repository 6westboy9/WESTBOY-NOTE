package com.lachesis.puma.agent.jdbc.interceptor;

import cn.hutool.core.util.ArrayUtil;
import com.lachesis.puma.agent.core.context.ContextManager;
import com.lachesis.puma.agent.core.context.tag.Tags;
import com.lachesis.puma.agent.core.context.trace.ISpan;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.agent.jdbc.ConnectionInfo;
import com.lachesis.puma.agent.jdbc.PreparedStatementParameterBuilder;
import com.lachesis.puma.agent.jdbc.StatementEnhanceInfo;
import com.lachesis.puma.agent.jdbc.util.SQLUtil;
import com.lachesis.puma.protocol.network.SpanLayer;

import java.lang.reflect.Method;

public class StatementExecuteMethodsInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        // LogUtil.info(false, "instance:" + instance.getClass());
        // if (instance.getSkyWalkingDynamicField() != null) {
        //     LogUtil.info(false, "dynamicField:" + instance.getSkyWalkingDynamicField().getClass());
        // } else {
        //     LogUtil.info(false, "dynamicField:" + null);
        // }
        StatementEnhanceInfo statementEnhanceInfo = (StatementEnhanceInfo) instance.getSkyWalkingDynamicField();
        ConnectionInfo connectInfo = statementEnhanceInfo.getConnectionInfo();
        // LogUtil.info(false, "connectInfo is null: " + (connectInfo == null));
        if (connectInfo != null) {
            // LogUtil.info(false, String.format("SQL:%s", SQLUtil.removeExtraWhitespaces(statementEnhanceInfo.getSql())));
            String opName = buildOpName(connectInfo, method.getName(), statementEnhanceInfo.getStatementName());
            ISpan span = ContextManager.createExitSpan(opName, connectInfo.getDatabasePeer());
            span.tag(Tags.DB_TYPE, "sql");
            span.tag(Tags.DB_INSTANCE, connectInfo.getDatabaseName());
            span.setLayer(SpanLayer.DB);
            span.setComponent(connectInfo.getComponent());

            if (ArrayUtil.isNotEmpty(arguments)) {
                // com.mysql.cj.jdbc.StatementImpl.execute(java.lang.String)
                // com.mysql.cj.jdbc.StatementImpl.executeLargeUpdate(java.lang.String)
                // com.mysql.cj.jdbc.StatementImpl.executeUpdate(java.lang.String)
                // ...
                span.tag(Tags.DB_STATEMENT, SQLUtil.removeExtraWhitespaces((String) arguments[0]));
            }
        }
    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        if (instance.getSkyWalkingDynamicField() instanceof StatementEnhanceInfo) {
            StatementEnhanceInfo cacheObject = (StatementEnhanceInfo) instance.getSkyWalkingDynamicField();
            if (cacheObject.getConnectionInfo() != null) {
                ContextManager.stopSpan();
            }
        }
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {
        if (instance.getSkyWalkingDynamicField() instanceof StatementEnhanceInfo) {
            StatementEnhanceInfo cacheObject = (StatementEnhanceInfo) instance.getSkyWalkingDynamicField();
            if (cacheObject.getConnectionInfo() != null) {
                ContextManager.activeSpan().log(t);
            }
        }
    }

    private String buildOpName(ConnectionInfo connectInfo, String methodName, String statementName) {
        return connectInfo.getDbType() + "/JDBI/" + statementName + "/" + methodName;
    }

    private String getParameterString(Object[] parameters, int maxIndex) {
        return new PreparedStatementParameterBuilder()
            .setParameters(parameters)
            .setMaxIndex(maxIndex)
            .build();
    }
}
