package com.lachesis.puma.agent.jdbc.connectionurl.parser;

public class URLLocation {
    private final int startIndex;
    private final int endIndex;

    public URLLocation(int startIndex, int endIndex) {
        this.startIndex = startIndex;
        this.endIndex = endIndex;
    }

    public int startIndex() {
        return startIndex;
    }

    public int endIndex() {
        return endIndex;
    }
}
