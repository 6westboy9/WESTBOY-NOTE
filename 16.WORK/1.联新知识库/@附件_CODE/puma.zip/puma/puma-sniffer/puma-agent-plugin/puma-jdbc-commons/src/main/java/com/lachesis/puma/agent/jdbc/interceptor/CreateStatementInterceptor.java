package com.lachesis.puma.agent.jdbc.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.agent.jdbc.ConnectionInfo;
import com.lachesis.puma.agent.jdbc.StatementEnhanceInfo;

import java.lang.reflect.Method;

public class CreateStatementInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        // com.mysql.cj.jdbc.ConnectionImpl.createStatement(int resultSetType, int resultSetConcurrency)
        // LogUtil.info(false, "instance:" + instance.getClass());
        // if (instance.getSkyWalkingDynamicField() != null) {
        //     LogUtil.info(false, "dynamicField:" + instance.getSkyWalkingDynamicField().getClass());
        // } else {
        //     LogUtil.info(false, "dynamicField:" + null);
        // }
        // LogUtil.info(false, "result:" + result.getClass());
        // LogUtil.info(false, "result instanceof EnhancedInstance:" + (result instanceof EnhancedInstance));

        if (result instanceof EnhancedInstance) {
            if (instance.getSkyWalkingDynamicField() instanceof ConnectionInfo) {
                ConnectionInfo connectionInfo = (ConnectionInfo) instance.getSkyWalkingDynamicField();
                StatementEnhanceInfo enhanceInfos = new StatementEnhanceInfo(connectionInfo, "", "Statement");
                // 给java.sql.Statement增强对象设置动态属性
                ((EnhancedInstance) result).setSkyWalkingDynamicField(enhanceInfos);
            }
        }
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}
