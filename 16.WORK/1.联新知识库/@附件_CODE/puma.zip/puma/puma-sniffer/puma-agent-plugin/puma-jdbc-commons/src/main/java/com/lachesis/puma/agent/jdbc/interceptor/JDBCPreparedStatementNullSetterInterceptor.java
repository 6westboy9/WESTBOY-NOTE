package com.lachesis.puma.agent.jdbc.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.jdbc.StatementEnhanceInfo;

import java.lang.reflect.Method;

public class JDBCPreparedStatementNullSetterInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        StatementEnhanceInfo statementEnhanceInfo = (StatementEnhanceInfo) instance.getSkyWalkingDynamicField();
        if (statementEnhanceInfo != null) {
            int index = (Integer) arguments[0];
            statementEnhanceInfo.setParameter(index, "NULL");
        }
    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}
