package com.lachesis.puma.agent.jdbc;

public class PumaAgentJdbcConstants {

    public static final String DRIVER_CONNECT_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.DriverConnectInterceptor";
    public static final String CREATE_CALLABLE_STATEMENT_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.CreateCallableStatementInterceptor";
    public static final String CREATE_PREPARED_STATEMENT_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.CreatePreparedStatementInterceptor";
    public static final String CREATE_STATEMENT_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.CreateStatementInterceptor";
    public static final String PREPARED_STATEMENT_EXECUTE_METHODS_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.PreparedStatementExecuteMethodsInterceptor";
    public static final String STATEMENT_EXECUTE_METHODS_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.StatementExecuteMethodsInterceptor";
    public static final String SERVICE_METHOD_INTERCEPT_CLASS = "com.lachesis.puma.agent.jdbc.interceptor.ConnectionServiceMethodsInterceptor";

    public static final String PREPARED_STATEMENT_NULL_SETTER_METHODS_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.JDBCPreparedStatementNullSetterInterceptor";
    public static final String PREPARED_STATEMENT_SETTER_METHODS_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.JDBCPreparedStatementSetterInterceptor";
    public static final String PREPARED_STATEMENT_IGNORABLE_SETTER_METHODS_INTERCEPTOR = "com.lachesis.puma.agent.jdbc.interceptor.JDBCPreparedStatementIgnorableSetterInterceptor";

}
