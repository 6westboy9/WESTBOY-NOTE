package com.lachesis.puma.agent.jdbc.interceptor;

import com.lachesis.puma.agent.core.context.ContextManager;
import com.lachesis.puma.agent.core.context.tag.Tags;
import com.lachesis.puma.agent.core.context.trace.ISpan;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.agent.jdbc.ConnectionInfo;
import com.lachesis.puma.protocol.network.SpanLayer;

import java.lang.reflect.Method;

public class ConnectionServiceMethodsInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        ConnectionInfo connectInfo = (ConnectionInfo) instance.getSkyWalkingDynamicField();
        if (connectInfo != null) {
            ISpan span = ContextManager.createExitSpan(connectInfo.getDbType() + "/JDBI/Connection/" + method.getName(), connectInfo.getDatabasePeer());
            span.tag(Tags.DB_TYPE, "sql");
            span.tag(Tags.DB_INSTANCE, connectInfo.getDatabaseName());
            span.setComponent(connectInfo.getComponent());
            span.setLayer(SpanLayer.DB);
        }
    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        ConnectionInfo connectInfo = (ConnectionInfo) instance.getSkyWalkingDynamicField();
        if (connectInfo != null) {
            ContextManager.stopSpan();
        }
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {
        ContextManager.activeSpan().log(t);
    }

}
