package com.lachesis.puma.agent.jdbc.point;

import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.jdbc.PumaAgentJdbcConstants;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;

import static net.bytebuddy.matcher.ElementMatchers.named;

public class JDBCPreparedStatementNullSetterMethodsInterceptorPoint implements MethodsInterceptorPoint {

    @Override
    public ElementMatcher<MethodDescription> getMatcher() {
        return named("setNull");
    }

    @Override
    public String getInterceptor() {
        return PumaAgentJdbcConstants.PREPARED_STATEMENT_NULL_SETTER_METHODS_INTERCEPTOR;
    }
}
