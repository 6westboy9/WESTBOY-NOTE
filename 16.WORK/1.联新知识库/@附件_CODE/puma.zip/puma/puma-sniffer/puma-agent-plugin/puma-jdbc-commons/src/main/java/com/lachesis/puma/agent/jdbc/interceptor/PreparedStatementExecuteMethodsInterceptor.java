package com.lachesis.puma.agent.jdbc.interceptor;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.json.JSONUtil;
import com.lachesis.puma.agent.core.context.ContextManager;
import com.lachesis.puma.agent.core.context.tag.Tags;
import com.lachesis.puma.agent.core.context.trace.ISpan;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.agent.jdbc.ConnectionInfo;
import com.lachesis.puma.agent.jdbc.PreparedStatementParameterBuilder;
import com.lachesis.puma.agent.jdbc.StatementEnhanceInfo;
import com.lachesis.puma.agent.jdbc.util.SQLUtil;
import com.lachesis.puma.protocol.network.SpanLayer;

import java.lang.reflect.Method;

public class PreparedStatementExecuteMethodsInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        StatementEnhanceInfo statementEnhanceInfo = (StatementEnhanceInfo) instance.getSkyWalkingDynamicField();
        if (statementEnhanceInfo != null && statementEnhanceInfo.getConnectionInfo() != null) {
            ConnectionInfo connectInfo = statementEnhanceInfo.getConnectionInfo();
            // LogUtil.info(false, String.format("SQL:%s", SQLUtil.removeExtraWhitespaces(statementEnhanceInfo.getSql())));
            // LogUtil.info(false, String.format("StatementEnhanceInfo:%s", JSONUtil.toJsonStr(statementEnhanceInfo)));
            String opName = buildOpName(connectInfo, method.getName(), statementEnhanceInfo.getStatementName());
            ISpan span = ContextManager.createExitSpan(opName, connectInfo.getDatabasePeer());
            span.tag(Tags.DB_TYPE, "sql");
            span.tag(Tags.DB_INSTANCE, connectInfo.getDatabaseName());
            span.tag(Tags.DB_STATEMENT, SQLUtil.removeExtraWhitespaces(statementEnhanceInfo.getSql()));
            span.setLayer(SpanLayer.DB);
            span.setComponent(connectInfo.getComponent());

            Object[] parameters = statementEnhanceInfo.getParameters();
            String parameterString;
            if (ArrayUtil.isNotEmpty(parameters)) {
                int maxIndex = statementEnhanceInfo.getMaxIndex();
                parameterString = getParameterString(parameters, maxIndex);
                // LogUtil.info(false, String.format("PARAMS:%S", parameterString));
                span.tag(Tags.DB_SQL_PARAMETERS, parameterString);
            }
        }
    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        StatementEnhanceInfo statementEnhanceInfo = (StatementEnhanceInfo) instance.getSkyWalkingDynamicField();
        if (statementEnhanceInfo != null && statementEnhanceInfo.getConnectionInfo() != null) {
            ContextManager.stopSpan();
        }
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {
        StatementEnhanceInfo statementEnhanceInfo = (StatementEnhanceInfo) instance.getSkyWalkingDynamicField();
        if (statementEnhanceInfo != null && statementEnhanceInfo.getConnectionInfo() != null) {
            ContextManager.activeSpan().log(t);
        }
    }

    private String buildOpName(ConnectionInfo connectInfo, String methodName, String statementName) {
        return connectInfo.getDbType() + "/JDBI/" + statementName + "/" + methodName;
    }

    private String getParameterString(Object[] parameters, int maxIndex) {
        return new PreparedStatementParameterBuilder()
            .setParameters(parameters)
            .setMaxIndex(maxIndex)
            .build();
    }
}