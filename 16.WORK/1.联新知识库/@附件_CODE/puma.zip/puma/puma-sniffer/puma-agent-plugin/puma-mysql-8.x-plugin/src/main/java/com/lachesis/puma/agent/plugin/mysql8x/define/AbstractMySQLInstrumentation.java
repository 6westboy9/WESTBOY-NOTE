package com.lachesis.puma.agent.plugin.mysql8x.define;

import com.lachesis.puma.agent.core.plugin.ClassEnhancePluginDefine;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;

public abstract class AbstractMySQLInstrumentation extends ClassEnhancePluginDefine {

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }

    @Override
    public MethodsInterceptorPoint[] getConstructorMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }

    @Override
    public MethodsInterceptorPoint[] getStaticMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }
}
