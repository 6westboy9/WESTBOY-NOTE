package com.lachesis.puma.agent.plugin.mysql8x.define;

import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.NameMatch;
import com.lachesis.puma.agent.jdbc.PumaAgentJdbcConstants;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;

import static net.bytebuddy.matcher.ElementMatchers.named;
import static net.bytebuddy.matcher.ElementMatchers.takesArguments;

public class ConnectionImplInstrumentation extends AbstractMySQLInstrumentation {

    private static final String CLASS_NAME = "com.mysql.cj.jdbc.ConnectionImpl";
    public static final String CONNECTION_CREATE_INTERCEPTOR = "com.lachesis.puma.agent.plugin.mysql8x.interceptor.ConnectionCreateInterceptor";

    @Override
    public ClassMatch enhanceClass() {
        return NameMatch.byNameMatch(CLASS_NAME);
    }

    @Override
    public MethodsInterceptorPoint[] getStaticMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("getInstance");
                }

                @Override
                public String getInterceptor() {
                    return CONNECTION_CREATE_INTERCEPTOR;
                }
            }
        };
    }

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("prepareStatement").and(takesArguments(1));
                }

                @Override
                public String getInterceptor() {
                    return PumaAgentJdbcConstants.CREATE_PREPARED_STATEMENT_INTERCEPTOR;
                }
            },
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("prepareCall");
                }

                @Override
                public String getInterceptor() {
                    return PumaAgentJdbcConstants.CREATE_CALLABLE_STATEMENT_INTERCEPTOR;
                }
            },
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("createStatement").and(takesArguments(2));
                }

                @Override
                public String getInterceptor() {
                    return PumaAgentJdbcConstants.CREATE_STATEMENT_INTERCEPTOR;
                }
            },
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("commit")
                        .or(named("rollback"))
                        .or(named("close"))
                        .or(named("releaseSavepoint"));
                }

                @Override
                public String getInterceptor() {
                    return PumaAgentJdbcConstants.SERVICE_METHOD_INTERCEPT_CLASS;
                }
            }
        };
    }
}
