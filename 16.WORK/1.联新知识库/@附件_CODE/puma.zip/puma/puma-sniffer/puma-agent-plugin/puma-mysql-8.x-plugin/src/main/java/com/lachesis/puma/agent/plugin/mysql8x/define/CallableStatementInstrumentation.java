package com.lachesis.puma.agent.plugin.mysql8x.define;

import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.NameMatch;
import com.lachesis.puma.agent.jdbc.PumaAgentJdbcConstants;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;

import static net.bytebuddy.matcher.ElementMatchers.named;

public class CallableStatementInstrumentation extends AbstractMySQLInstrumentation {

    private static final String CLASS_NAME = "java.sql.CallableStatement";

    @Override
    public ClassMatch enhanceClass() {
        return NameMatch.byNameMatch(CLASS_NAME);
    }

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("execute").or(named("executeQuery")).or(named("executeUpdate"));
                }

                @Override
                public String getInterceptor() {
                    return PumaAgentJdbcConstants.PREPARED_STATEMENT_EXECUTE_METHODS_INTERCEPTOR;
                }
            }
        };
    }
}
