package com.lachesis.puma.agent.plugin.mysql8x.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.StaticMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.agent.jdbc.ConnectionCache;
import com.lachesis.puma.agent.jdbc.ConnectionInfo;
import com.mysql.cj.conf.HostInfo;

import java.lang.reflect.Method;

public class ConnectionCreateInterceptor implements StaticMethodsAroundInterceptor {

    @Override
    public void beforeMethod(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes) {
    }

    @Override
    public Object afterMethod(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        if (result instanceof EnhancedInstance) {
            HostInfo hostInfo = (HostInfo) arguments[0];
            LogUtil.info(false, String.format("HostInfo:%s", hostInfo.toString()));
            ConnectionInfo connectionInfo = ConnectionCache.get(hostInfo.getHostPortPair());
            ((EnhancedInstance) result).setSkyWalkingDynamicField(connectionInfo);
        }
        return result;
    }

    @Override
    public void handleEx(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}