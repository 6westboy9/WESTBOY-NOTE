package com.lachesis.puma.agent.plugin.mysql8x.define;

import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.MultiClassNameMatch;
import com.lachesis.puma.agent.jdbc.PumaAgentJdbcConstants;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;

import static net.bytebuddy.matcher.ElementMatchers.named;

public class PreparedStatementInstrumentation extends AbstractMySQLInstrumentation {

    private static final String CLIENT_PREPARE_STATEMENT_CLASS_NAME = "com.mysql.cj.jdbc.ClientPreparedStatement";
    private static final String SERVER_PREPARED_STATEMENT_CLASS_NAME = "com.mysql.cj.jdbc.ServerPreparedStatement";

    @Override
    public ClassMatch enhanceClass() {
        return MultiClassNameMatch.byMultiClassMatch(CLIENT_PREPARE_STATEMENT_CLASS_NAME, SERVER_PREPARED_STATEMENT_CLASS_NAME);
    }

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("execute").or(named("executeQuery"))
                        .or(named("executeUpdate"))
                        .or(named("executeLargeUpdate"));
                }

                @Override
                public String getInterceptor() {
                    return PumaAgentJdbcConstants.PREPARED_STATEMENT_EXECUTE_METHODS_INTERCEPTOR;
                }
            }
        };
    }
}
