package com.lachesis.puma.agent.plugin.mysql8x.define;

import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.jdbc.point.PSSetterDefinitionOfJDBCMethodsInterceptorPoint;

public class PreparedStatementSetterInstrumentation extends PreparedStatementInstrumentation {

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{new PSSetterDefinitionOfJDBCMethodsInterceptorPoint(false)};
    }
}
