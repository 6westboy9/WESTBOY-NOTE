/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.lachesis.puma.agent.plugin.tomcat78x.interceptor;

import com.lachesis.puma.agent.core.context.ContextManager;
import com.lachesis.puma.agent.core.context.tag.Tags;
import com.lachesis.puma.agent.core.context.trace.ISpan;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.ParameterUtil;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.agent.core.util.MethodUtil;
import com.lachesis.puma.protocol.component.ComponentsDefine;
import com.lachesis.puma.protocol.network.SpanLayer;
import org.apache.catalina.connector.Request;
import org.apache.tomcat.util.http.Parameters;

import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

public class TomcatInvokeInterceptor implements InstanceMethodsAroundInterceptor {

    private static final boolean IS_SERVLET_GET_STATUS_METHOD_EXIST;
    private static final String SERVLET_RESPONSE_CLASS = "javax.servlet.http.HttpServletResponse";
    private static final String GET_STATUS_METHOD = "getStatus";

    static {
        IS_SERVLET_GET_STATUS_METHOD_EXIST = MethodUtil.isMethodExist(TomcatInvokeInterceptor.class.getClassLoader(),
            SERVLET_RESPONSE_CLASS, GET_STATUS_METHOD);
    }

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        Request request = (Request) arguments[0];
        // LogUtil.info(false, "URL:" + request.getRequestURL().toString());
        // LogUtil.info(false, "METHOD:" + request.getMethod());
        ISpan span = ContextManager.createEntrySpan(request.getRequestURI());
        span.tag(Tags.HTTP_URL, request.getRequestURL().toString());
        span.tag(Tags.HTTP_METHOD, request.getMethod());
        span.setComponent(ComponentsDefine.TOMCAT);
        span.setLayer(SpanLayer.HTTP);
        // 收集参数信息
        collectHttpParam(request, span);
    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        HttpServletResponse response = (HttpServletResponse) arguments[1];
        ISpan span = ContextManager.activeSpan();
        span.tag(Tags.HTTP_STATUS_CODE, Integer.toString(response.getStatus()));
        if (IS_SERVLET_GET_STATUS_METHOD_EXIST && response.getStatus() >= 400) {
            span.errorOccurred();
        }
        ContextManager.stopSpan(span);
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {
        ContextManager.activeSpan().log(t);
    }

    private void collectHttpParam(Request request, ISpan span) {
        Map<String, String[]> parameterMap = new HashMap<>();
        org.apache.coyote.Request coyoteRequest = request.getCoyoteRequest();
        Parameters parameters = coyoteRequest.getParameters();

        Enumeration<String> names = parameters.getParameterNames();
        while (names.hasMoreElements()) {
            String name = names.nextElement();
            parameterMap.put(name, parameters.getParameterValues(name));
        }

        if (!parameterMap.isEmpty()) {
            String tagValue = ParameterUtil.toString(parameterMap);
            span.tag(Tags.HTTP_PARAMS, tagValue);
        }
    }
}
