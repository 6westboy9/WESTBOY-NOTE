package com.lachesis.puma.agent.plugin.tomcat78x.define;

import com.lachesis.puma.agent.core.plugin.ClassEnhancePluginDefine;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.NameMatch;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;

import static net.bytebuddy.matcher.ElementMatchers.named;

public class TomcatInstrumentation extends ClassEnhancePluginDefine {

    private static final String ENHANCE_CLASS = "org.apache.catalina.core.StandardHostValve";
    private static final String INVOKE_INTERCEPT_CLASS = "com.lachesis.puma.agent.plugin.tomcat78x.interceptor.TomcatInvokeInterceptor";
    private static final String EXCEPTION_INTERCEPT_CLASS = "com.lachesis.puma.agent.plugin.tomcat78x.interceptor.TomcatExceptionInterceptor";

    @Override
    public ClassMatch enhanceClass() {
        return NameMatch.byNameMatch(ENHANCE_CLASS);
    }

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("invoke");
                }

                @Override
                public String getInterceptor() {
                    return INVOKE_INTERCEPT_CLASS;
                }
            },
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named("throwable");
                }

                @Override
                public String getInterceptor() {
                    return EXCEPTION_INTERCEPT_CLASS;
                }
            }
        };
    }

    @Override
    public MethodsInterceptorPoint[] getConstructorMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }

    @Override
    public MethodsInterceptorPoint[] getStaticMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }
}
