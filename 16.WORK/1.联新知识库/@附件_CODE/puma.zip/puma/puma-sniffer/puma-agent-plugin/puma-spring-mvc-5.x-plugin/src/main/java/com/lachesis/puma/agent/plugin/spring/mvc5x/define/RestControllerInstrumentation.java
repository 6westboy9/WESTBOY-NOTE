package com.lachesis.puma.agent.plugin.spring.mvc5x.define;

import com.lachesis.puma.agent.core.plugin.match.ClassAnnotationMatch;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;

public class RestControllerInstrumentation extends SpringMvcCommonInstrumentation {

    private static final String REST_CONTROLLER_NAME = "org.springframework.web.bind.annotation.RestController";

    @Override
    public ClassMatch enhanceClass() {
        return ClassAnnotationMatch.byClassAnnotationMatch(REST_CONTROLLER_NAME);
    }
}
