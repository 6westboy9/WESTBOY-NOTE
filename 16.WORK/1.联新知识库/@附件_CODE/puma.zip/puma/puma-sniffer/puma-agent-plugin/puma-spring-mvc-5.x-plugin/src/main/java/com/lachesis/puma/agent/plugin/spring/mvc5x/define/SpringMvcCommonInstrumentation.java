package com.lachesis.puma.agent.plugin.spring.mvc5x.define;

import com.lachesis.puma.agent.core.plugin.ClassEnhancePluginDefine;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.ElementMatchers;

import static net.bytebuddy.matcher.ElementMatchers.*;

public abstract class SpringMvcCommonInstrumentation extends ClassEnhancePluginDefine {

    private static final String MAPPING_PKG_PREFIX = "org.springframework.web.bind.annotation";
    private static final String MAPPING_SUFFIX = "Mapping";
    private static final String INTERCEPTOR = "com.lachesis.puma.agent.plugin.spring.mvc5x.interceptor.SpringMvcInterceptor";

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return not(ElementMatchers.isStatic())
                        .and(isAnnotatedWith(nameStartsWith(MAPPING_PKG_PREFIX)
                            .and(nameEndsWith(MAPPING_SUFFIX))));
                }

                @Override
                public String getInterceptor() {
                    return INTERCEPTOR;
                }
            }
        };
    }

    @Override
    public MethodsInterceptorPoint[] getConstructorMethodsInterceptorPoints() {
        return null;
    }

    @Override
    public MethodsInterceptorPoint[] getStaticMethodsInterceptorPoints() {
        return null;
    }
}
