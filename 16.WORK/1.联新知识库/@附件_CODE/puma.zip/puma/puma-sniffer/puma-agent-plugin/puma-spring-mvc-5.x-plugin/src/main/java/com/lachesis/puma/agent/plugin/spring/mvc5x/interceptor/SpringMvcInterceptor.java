package com.lachesis.puma.agent.plugin.spring.mvc5x.interceptor;

import com.lachesis.puma.agent.core.context.ContextManager;
import com.lachesis.puma.agent.core.context.tag.Tags;
import com.lachesis.puma.agent.core.context.trace.ISpan;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.plugin.spring.mvc5x.SpringMvcHelper;
import com.lachesis.puma.protocol.component.ComponentsDefine;
import com.lachesis.puma.protocol.network.SpanLayer;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("unchecked")
public class SpringMvcInterceptor implements InstanceMethodsAroundInterceptor {

    private static final String START = "START";

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        Map<String, Object> map = new HashMap<>();
        map.put(START, System.nanoTime());
        map.put("PARAMS", arguments);
        instance.setSkyWalkingDynamicField(map);
        String requestURL = SpringMvcHelper.getRequestURL(method);
        String acceptedMethodTypes = SpringMvcHelper.getAcceptedMethodTypes(method);
        ISpan span = ContextManager.createLocalSpan(acceptedMethodTypes + requestURL);

        span.setComponent(ComponentsDefine.SPRING_MVC);
        span.setLayer(SpanLayer.HTTP);
        span.tag(Tags.MVC_CONTROLLER_PATH, method.toGenericString());
    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        // Map<String, Object> map = (Map<String, Object>) instance.getSkyWalkingDynamicField();
        // long start = (long) map.get(START);
        ISpan span = ContextManager.activeSpan();
        ContextManager.stopSpan(span);
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {
        // Map<String, Object> map = (Map<String, Object>) instance.getSkyWalkingDynamicField();
        // long start = (long) map.get(START);
        // LogUtil.error(t, false, String.format("请求异常:%s", DateUtil.nanoToMill(System.nanoTime() - start)));
        ISpan span = ContextManager.activeSpan();
        span.log(t);
        span.errorOccurred();
    }
}
