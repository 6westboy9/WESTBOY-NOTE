package com.lachesis.puma.agent.plugin.spring.mvc5x.define;

import com.lachesis.puma.agent.core.plugin.match.ClassAnnotationMatch;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.IndirectMatch;
import com.lachesis.puma.agent.core.plugin.match.MultiClassNameMatch;
import com.lachesis.puma.agent.core.plugin.match.logical.LogicalMatchOperation;

public class ControllerInstrumentation extends SpringMvcCommonInstrumentation {

    private static final String CONTROLLER_NAME = "org.springframework.stereotype.Controller";
    private static final String[] EXCLUDE_CLASS_NAMES = {"org.springframework.boot.autoconfigure.web.servlet.error.BasicErrorController"};

    @Override
    public ClassMatch enhanceClass() {
        IndirectMatch match1 = ClassAnnotationMatch.byClassAnnotationMatch(CONTROLLER_NAME);
        IndirectMatch match2 = MultiClassNameMatch.byMultiClassMatch(EXCLUDE_CLASS_NAMES);
        return LogicalMatchOperation.and(match1, LogicalMatchOperation.not(match2));
    }
}
