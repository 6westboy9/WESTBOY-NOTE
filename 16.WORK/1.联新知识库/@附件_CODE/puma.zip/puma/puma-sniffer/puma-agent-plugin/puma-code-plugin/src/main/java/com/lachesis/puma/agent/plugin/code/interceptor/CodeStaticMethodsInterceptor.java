package com.lachesis.puma.agent.plugin.code.interceptor;

import cn.hutool.core.collection.ArrayIter;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.context.ContextManager;
import com.lachesis.puma.agent.core.context.tag.Tags;
import com.lachesis.puma.agent.core.context.trace.ISpan;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.StaticMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.protocol.component.ComponentsDefine;
import com.lachesis.puma.protocol.network.SpanLayer;
import net.bytebuddy.description.method.MethodDescription;

import java.lang.reflect.Method;
import java.util.Arrays;

public class CodeStaticMethodsInterceptor implements StaticMethodsAroundInterceptor {

    @Override
    public void beforeMethod(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        // LogUtil.info(false, "CLASS:" + clazz.getName());
        // LogUtil.info(false, "METHOD:" + method.getName());
        MethodDescription.ForLoadedMethod loadedMethod = new MethodDescription.ForLoadedMethod(method);
        String parameterDescriptor = "";
        if (ArrayUtil.isNotEmpty(parameterTypes)) {
            String[] internalNames = loadedMethod.getParameters().asTypeList().asErasures().toInternalNames();
            if (ArrayUtil.isNotEmpty(internalNames)) {
                parameterDescriptor = StrUtil.join(";", new ArrayIter<>(internalNames));
                // LogUtil.info(false, "参数类型描述符:" + parameterDescriptor);
            }
        }
        String returnDescriptor = loadedMethod.getReturnType().asRawType().asErasure().getDescriptor();
        // LogUtil.info(false, "返回类型描述符:" + returnDescriptor);

        String opName = String.format("%s.%s(%s)%s", clazz.getName(), method.getName(), parameterDescriptor, returnDescriptor);
        ISpan span = ContextManager.createLocalSpan(opName);
        span.tag(Tags.CODE_METHOD_NAME, method.toGenericString());
        if (ArrayUtil.isNotEmpty(arguments)) {
            span.tag(Tags.CODE_METHOD_PARAMS, Arrays.toString(arguments));
        }
        span.setComponent(ComponentsDefine.CODE);
        span.setLayer(SpanLayer.CODE);
    }

    @Override
    public Object afterMethod(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        if (ContextManager.isActive()) {
            ISpan span = ContextManager.activeSpan();
            if (result != null) {
                span.tag(Tags.CODE_METHOD_RESULT, result.toString());
            }
            ContextManager.stopSpan(span);
        }
        return result;
    }

    @Override
    public void handleEx(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {
        if (ContextManager.isActive()) {
            ISpan span = ContextManager.activeSpan();
            span.log(t);
            span.errorOccurred();
        }
    }
}
