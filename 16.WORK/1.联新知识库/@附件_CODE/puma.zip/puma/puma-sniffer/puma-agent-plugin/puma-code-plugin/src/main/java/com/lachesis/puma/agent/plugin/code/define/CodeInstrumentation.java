package com.lachesis.puma.agent.plugin.code.define;

import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.plugin.ClassEnhancePluginDefine;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.WildcardMatch;
import com.lachesis.puma.agent.plugin.code.config.CodePluginConfig;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.ElementMatchers;

import java.util.List;

public class CodeInstrumentation extends ClassEnhancePluginDefine {

    private static final String INSTANCE_INTERCEPTOR = "com.lachesis.puma.agent.plugin.code.interceptor.CodeInstanceMethodsInterceptor";
    private static final String STATIC_INTERCEPTOR = "com.lachesis.puma.agent.plugin.code.interceptor.CodeStaticMethodsInterceptor";

    @Override
    public ClassMatch enhanceClass() {
        if (!CodePluginConfig.Plugin.Code.ENABLE) {
            return null;
        }
        String includeRegex = CodePluginConfig.Plugin.Code.INCLUDE_REGEX;
        String excludeRegex = CodePluginConfig.Plugin.Code.EXCLUDE_REGEX;
        List<String> includeRegexList = StrUtil.split(includeRegex, ",");
        List<String> excludeRegexList = StrUtil.split(excludeRegex, ",");
        return WildcardMatch.byRegexMatch(includeRegexList, excludeRegexList);
    }

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return ElementMatchers.isMethod()
                        .and(ElementMatchers.not(ElementMatchers.isStatic()))
                        .and(ElementMatchers.not(ElementMatchers.isAbstract()))
                        .and(ElementMatchers.not(ElementMatchers.isToString()))
                        .and(ElementMatchers.not(ElementMatchers.isEquals()))
                        .and(ElementMatchers.not(ElementMatchers.isHashCode()));
                }

                @Override
                public String getInterceptor() {
                    return INSTANCE_INTERCEPTOR;
                }
            }
        };
    }

    @Override
    public MethodsInterceptorPoint[] getConstructorMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }

    @Override
    public MethodsInterceptorPoint[] getStaticMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return ElementMatchers.isStatic();
                }

                @Override
                public String getInterceptor() {
                    return STATIC_INTERCEPTOR;
                }
            }
        };
    }
}
