package com.lachesis.puma.agent.plugin.code.config;

import com.lachesis.puma.agent.core.boot.PluginConfig;

public class CodePluginConfig {
    public static class Plugin {
        @PluginConfig(root = CodePluginConfig.class)
        public static class Code {
            public static boolean ENABLE = false;
            public static String INCLUDE_REGEX = "";
            public static String EXCLUDE_REGEX = "";
        }
    }
}
