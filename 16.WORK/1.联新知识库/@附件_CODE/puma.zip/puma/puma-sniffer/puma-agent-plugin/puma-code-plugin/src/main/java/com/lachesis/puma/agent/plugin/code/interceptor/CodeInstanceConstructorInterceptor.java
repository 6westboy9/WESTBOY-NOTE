package com.lachesis.puma.agent.plugin.code.interceptor;

import cn.hutool.core.collection.ArrayIter;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.context.ContextManager;
import com.lachesis.puma.agent.core.context.tag.Tags;
import com.lachesis.puma.agent.core.context.trace.ISpan;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceConstructorInterceptor;
import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.util.LogUtil;
import com.lachesis.puma.protocol.component.ComponentsDefine;
import com.lachesis.puma.protocol.network.SpanLayer;
import net.bytebuddy.description.method.MethodDescription;

import java.lang.reflect.Constructor;
import java.util.Arrays;

public class CodeInstanceConstructorInterceptor implements InstanceConstructorInterceptor {

    @Override
    public void onConstruct(EnhancedInstance instance, Constructor<?> constructor, Object[] arguments) {
        Class<? extends EnhancedInstance> clazz = instance.getClass();
        String parameterDescriptor = "";
        MethodDescription.ForLoadedConstructor loadedConstructor = new MethodDescription.ForLoadedConstructor(constructor);
        String[] internalNames = loadedConstructor.getParameters().asTypeList().asErasures().toInternalNames();
        if (ArrayUtil.isNotEmpty(internalNames)) {
            parameterDescriptor = StrUtil.join(";", new ArrayIter<>(internalNames));
            // LogUtil.info(false, "参数类型描述符:" + parameterDescriptor);
        }
        String opName = String.format("%s.<init>(%s)", clazz.getName(), parameterDescriptor);
        ISpan span = ContextManager.createLocalSpan(opName);
        span.tag(Tags.CODE_METHOD_NAME, loadedConstructor.toGenericString());
        if (ArrayUtil.isNotEmpty(arguments)) {
            span.tag(Tags.CODE_METHOD_PARAMS, Arrays.toString(arguments));
        }
        span.setComponent(ComponentsDefine.CODE);
        span.setLayer(SpanLayer.CODE);
        ContextManager.stopSpan();
    }
}
