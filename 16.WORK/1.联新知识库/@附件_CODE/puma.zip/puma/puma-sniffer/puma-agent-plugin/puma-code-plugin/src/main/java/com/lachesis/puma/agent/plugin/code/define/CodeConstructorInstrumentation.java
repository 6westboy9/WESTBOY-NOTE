package com.lachesis.puma.agent.plugin.code.define;

import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.HierarchyMatch;
import com.lachesis.puma.agent.core.plugin.match.IndirectMatch;
import com.lachesis.puma.agent.core.plugin.match.WildcardMatch;
import com.lachesis.puma.agent.core.plugin.match.logical.LogicalMatchOperation;
import com.lachesis.puma.agent.plugin.code.config.CodePluginConfig;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.ElementMatchers;

import java.util.List;

public class CodeConstructorInstrumentation extends CodeInstrumentation {

    private static final String CONSTRUCTOR_INTERCEPTOR = "com.lachesis.puma.agent.plugin.code.interceptor.CodeInstanceConstructorInterceptor";

    private static final String CALLABLE_CLASS = "java.util.concurrent.Callable";
    private static final String RUNNABLE_CLASS = "java.lang.Runnable";

    @Override
    public ClassMatch enhanceClass() {
        if (!CodePluginConfig.Plugin.Code.ENABLE) {
            return null;
        }
        String includeRegex = CodePluginConfig.Plugin.Code.INCLUDE_REGEX;
        String excludeRegex = CodePluginConfig.Plugin.Code.EXCLUDE_REGEX;
        List<String> includeRegexList = StrUtil.split(includeRegex, ",");
        List<String> excludeRegexList = StrUtil.split(excludeRegex, ",");
        WildcardMatch wildcardMatch = WildcardMatch.byRegexMatch(includeRegexList, excludeRegexList);
        IndirectMatch noRunnableMatch = LogicalMatchOperation.not(HierarchyMatch.byHierarchyMatch(RUNNABLE_CLASS));
        IndirectMatch noCallableMatch = LogicalMatchOperation.not(HierarchyMatch.byHierarchyMatch(CALLABLE_CLASS));
        return LogicalMatchOperation.and(wildcardMatch, noRunnableMatch, noCallableMatch);
    }

    @Override
    public MethodsInterceptorPoint[] getConstructorMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return ElementMatchers.any();
                }

                @Override
                public String getInterceptor() {
                    return CONSTRUCTOR_INTERCEPTOR;
                }
            }
        };
    }
}
