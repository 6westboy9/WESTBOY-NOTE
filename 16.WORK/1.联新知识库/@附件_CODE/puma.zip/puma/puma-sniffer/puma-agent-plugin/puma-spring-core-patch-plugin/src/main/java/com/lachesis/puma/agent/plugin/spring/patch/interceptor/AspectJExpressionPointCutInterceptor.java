/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lachesis.puma.agent.plugin.spring.patch.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;

import java.lang.reflect.Method;


public class AspectJExpressionPointCutInterceptor implements InstanceMethodsAroundInterceptor {
    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {

    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
            Method targetAopMethod = (Method) arguments[0];
            Class<?> targetAopClass = (Class<?>) arguments[1];
            if (targetAopClass != null && EnhancedInstance.class.isAssignableFrom(targetAopClass) && MatchUtil.isEnhancedMethod(targetAopMethod)) {
                return false;
            }
            return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}