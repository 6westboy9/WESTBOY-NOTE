package com.lachesis.puma.agent.plugin.spring.patch.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.StaticMethodsAroundInterceptor;

import java.lang.reflect.Method;

public class AopExpressionMatchInterceptor implements StaticMethodsAroundInterceptor {

    @Override
    public void beforeMethod(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes) {

    }

    @Override
    public Object afterMethod(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        //     public static boolean matches(MethodMatcher mm, Method method, Class<?> targetClass, boolean hasIntroductions) {
        //         Assert.notNull(mm, "MethodMatcher must not be null");
        //         return mm instanceof IntroductionAwareMethodMatcher && ((IntroductionAwareMethodMatcher)mm).matches(method, targetClass, hasIntroductions) || mm.matches(method, targetClass);
        //     }
        Method targetAopMethod = (Method) arguments[1];
        Class<?> targetAopClass = (Class<?>) arguments[2];
        // 如果目标类AOP代理类实现了EnhancedInstance接口，并且方法
        if (targetAopClass != null && EnhancedInstance.class.isAssignableFrom(targetAopClass) && MatchUtil.isEnhancedMethod(targetAopMethod)) {
            return false;
        }
        return result;
    }

    @Override
    public void handleEx(Class<?> clazz, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}
