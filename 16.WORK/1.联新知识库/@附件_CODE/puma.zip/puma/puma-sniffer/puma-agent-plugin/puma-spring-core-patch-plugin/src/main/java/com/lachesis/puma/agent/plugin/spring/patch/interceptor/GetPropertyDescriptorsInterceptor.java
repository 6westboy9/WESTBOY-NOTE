/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 *
 */

package com.lachesis.puma.agent.plugin.spring.patch.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import org.springframework.beans.BeanWrapperImpl;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class GetPropertyDescriptorsInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {

    }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        PropertyDescriptor[] propertyDescriptors = (PropertyDescriptor[]) result;
        Class<?> rootClass = ((BeanWrapperImpl) instance).getRootClass();
        if (rootClass != null && EnhancedInstance.class.isAssignableFrom(rootClass)) {
            List<PropertyDescriptor> newPropertyDescriptors = new ArrayList<>();
            for (PropertyDescriptor descriptor : propertyDescriptors) {
                if (!"skyWalkingDynamicField".equals(descriptor.getName())) {
                    newPropertyDescriptors.add(descriptor);
                }
            }
            return newPropertyDescriptors.toArray(new PropertyDescriptor[0]);
        }
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}
