/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.lachesis.puma.agent.plugin.spring.patch.define;

import com.lachesis.puma.agent.core.plugin.ClassEnhancePluginDefine;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.NameMatch;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;

import static net.bytebuddy.matcher.ElementMatchers.named;

/**
 * puma在增强类的构造方法或者实例方法时，会自动实现EnhancedInstance接口，
 * 导致Spring的DefaultAopProxyFactory#hasNoUserSuppliedProxyInterfaces(AdvisedSupport)返回false错误，实际应该返回true，
 * 关于这个问题可以参考：<a href="https://github.com/apache/skywalking/issues/581">issues#581</a>
 */
public class AopProxyFactoryInstrumentation extends ClassEnhancePluginDefine {

    private static final String ENHANCE_CLASS = "org.springframework.aop.framework.DefaultAopProxyFactory";
    public static final String ENHANCE_METHOD = "hasNoUserSuppliedProxyInterfaces";
    public static final String INTERCEPT_CLASS = "com.lachesis.puma.agent.plugin.spring.patch.interceptor.CreateAopProxyInterceptor";

    @Override
    public ClassMatch enhanceClass() {
        return NameMatch.byNameMatch(ENHANCE_CLASS);
    }

    @Override
    public MethodsInterceptorPoint[] getConstructorMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }

    @Override
    public MethodsInterceptorPoint[] getStaticMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return named(ENHANCE_METHOD);
                }

                @Override
                public String getInterceptor() {
                    return INTERCEPT_CLASS;
                }
            }
        };
    }
}
