package com.lachesis.puma.agent.plugin.mybatis.interceptor;

import com.lachesis.puma.agent.core.plugin.interceptor.EnhancedInstance;
import com.lachesis.puma.agent.core.plugin.interceptor.InstanceMethodsAroundInterceptor;
import com.lachesis.puma.agent.core.util.LogUtil;
import org.apache.ibatis.builder.SqlSourceBuilder;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;

import java.lang.reflect.Method;
import java.util.List;

public class MyBatisInterceptor implements InstanceMethodsAroundInterceptor {

    @Override
    public void beforeMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes) {
        MappedStatement statement = (MappedStatement) arguments[0];
        String id = statement.getId();
        BoundSql boundSql = (BoundSql) arguments[5];
        String sql = boundSql.getSql().replace("\n", "");
        List<ParameterMapping> parameterMappings = boundSql.getParameterMappings();
        // ParameterMapping paramNames = (ParameterMapping) arguments[1];
        // HashMap<String, Object> paramValues = (HashMap<String, Object>) arguments[2];
        // instance.setSkyWalkingDynamicField("select * from user = ?");
        // LogUtil.info(false, "ID:" + id);
        // LogUtil.info(false, "SQL:" + removeExtraWhitespace(sql));
    }

    private String removeExtraWhitespace(String original) {
        return SqlSourceBuilder.removeExtraWhitespaces(original);
    }

    // private String getParameterValueString() {
    //     List<Object> typeList = new ArrayList<>(columnValues.size());
    //     for (Object value : columnValues) {
    //         if (value == null) {
    //             typeList.add("null");
    //         } else {
    //             typeList.add(objectValueString(value) + "(" + value.getClass().getSimpleName() + ")");
    //         }
    //     }
    //     final String parameters = typeList.toString();
    //     return parameters.substring(1, parameters.length() - 1);
    // }
    //
    // private String objectValueString(Object value) {
    //     if (value instanceof Array) {
    //         try {
    //             return ArrayUtil.toString(((Array) value).getArray());
    //         } catch (SQLException e) {
    //             // ignore
    //         }
    //     }
    //     return value.toString();
    // }

    @Override
    public Object afterMethod(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Object result) {
        return result;
    }

    @Override
    public void handleEx(EnhancedInstance instance, Method method, Object[] arguments, Class<?>[] parameterTypes, Throwable t) {

    }
}
