package com.lachesis.puma.agent.plugin.jdk.thread.config;

import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.agent.core.boot.PluginConfig;
import com.lachesis.puma.agent.core.plugin.match.IndirectMatch;
import com.lachesis.puma.agent.core.plugin.match.PrefixMatch;
import com.lachesis.puma.agent.core.plugin.match.logical.LogicalMatchOperation;
import com.lachesis.puma.agent.core.util.LogUtil;

import java.util.ArrayList;
import java.util.List;

public class ThreadPluginConfig {

    public static class Plugin {
        @PluginConfig(root = ThreadPluginConfig.class)
        public static class JdkThread {
            public static String CLASS_PREFIXES = "";
        }
    }

    public static IndirectMatch prefixesMatchesForJdkThread() {
        // 在主动引用com.lachesis.puma.agent.plugin.jdk.thread.config.ThreadPluginConfig.Plugin.JdkThread.JDKTHREAD_CLASS_PREFIXES时，会进行加载并根据配置文件进行默认值覆盖操作
        String jdkthreadClassPrefixes = ThreadPluginConfig.Plugin.JdkThread.CLASS_PREFIXES;
        if (StrUtil.isEmpty(jdkthreadClassPrefixes)) {
            return null;
        }

        List<String> prefixes = StrUtil.split(jdkthreadClassPrefixes, ",");
        List<PrefixMatch> matchList = new ArrayList<>();
        prefixes.forEach(prefix -> {
            if (prefix.startsWith("java.") || prefix.startsWith("javax.")) {
                LogUtil.info(false, "配置前缀被忽略:" + prefix);
                return;
            }
            matchList.add(PrefixMatch.nameStartsWith(prefix));
        });

        if (matchList.isEmpty()) {
            return null;
        }
        return LogicalMatchOperation.or(matchList.toArray(new PrefixMatch[0]));
    }
}
