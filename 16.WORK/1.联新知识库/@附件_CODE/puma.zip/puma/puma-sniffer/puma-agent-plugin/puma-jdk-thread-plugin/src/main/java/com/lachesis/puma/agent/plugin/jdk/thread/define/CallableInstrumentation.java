package com.lachesis.puma.agent.plugin.jdk.thread.define;

import com.lachesis.puma.agent.core.plugin.ClassEnhancePluginDefine;
import com.lachesis.puma.agent.core.plugin.interceptor.MethodsInterceptorPoint;
import com.lachesis.puma.agent.core.plugin.match.ClassMatch;
import com.lachesis.puma.agent.core.plugin.match.HierarchyMatch;
import com.lachesis.puma.agent.core.plugin.match.IndirectMatch;
import com.lachesis.puma.agent.core.plugin.match.logical.LogicalMatchOperation;
import com.lachesis.puma.agent.plugin.jdk.thread.config.ThreadPluginConfig;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.ElementMatchers;

public class CallableInstrumentation extends ClassEnhancePluginDefine {

    private static final String CALLABLE_CLASS = "java.util.concurrent.Callable";
    private static final String CALLABLE_CLASS_INTERCEPTOR = "com.lachesis.puma.agent.plugin.jdk.thread.interceptor.ThreadConstructorInterceptor";
    private static final String CALLABLE_CALL_METHOD = "call";
    private static final String CALLABLE_CALL_METHOD_INTERCEPTOR = "com.lachesis.puma.agent.plugin.jdk.thread.interceptor.ThreadMethodsInterceptor";

    @Override
    public ClassMatch enhanceClass() {
        IndirectMatch indirectMatch = ThreadPluginConfig.prefixesMatchesForJdkThread();
        if (indirectMatch == null) {
            return null;
        }
        return LogicalMatchOperation.and(indirectMatch, HierarchyMatch.byHierarchyMatch(CALLABLE_CLASS));
    }

    @Override
    public MethodsInterceptorPoint[] getConstructorMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{
            new MethodsInterceptorPoint() {
                @Override
                public ElementMatcher<MethodDescription> getMatcher() {
                    return ElementMatchers.any();
                }

                @Override
                public String getInterceptor() {
                    return CALLABLE_CLASS_INTERCEPTOR;
                }
            }
        };
    }

    @Override
    public MethodsInterceptorPoint[] getStaticMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[0];
    }

    @Override
    public MethodsInterceptorPoint[] getInstanceMethodsInterceptorPoints() {
        return new MethodsInterceptorPoint[]{new MethodsInterceptorPoint() {
            @Override
            public ElementMatcher<MethodDescription> getMatcher() {
                return ElementMatchers.named(CALLABLE_CALL_METHOD).and(ElementMatchers.takesArguments(0));
            }

            @Override
            public String getInterceptor() {
                return CALLABLE_CALL_METHOD_INTERCEPTOR;
            }
        }};
    }

    @Override
    public boolean isBootstrapInstrumentation() {
        return true;
    }
}
