package com.lachesis.puma.console;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.core.common.SideOpt;
import com.lachesis.puma.core.util.PumaPrintStream;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConsoleConfig {

    private static final ConsoleConfig instance = new ConsoleConfig();

    private String dir;
    private String gitSshKeyPath;
    private String javaHomePath;
    private String mavenHomePath;

    public static ConsoleConfig getInstance() {
        return instance;
    }

    public void init(String configPath) {
        Properties properties = new Properties();
        if (StrUtil.isNotEmpty(configPath)) {
            try (BufferedReader bufferedReader = new BufferedReader(new FileReader(configPath))) {
                properties.load(bufferedReader);
                this.dir = checkAndResetDir(properties);
                this.gitSshKeyPath = check(properties, "git.ssh.key.path");
                this.javaHomePath = check(properties, "java.home.path");
                this.mavenHomePath = check(properties, "maven.home.path");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private String check(Properties properties, String key) {
        String value = properties.getProperty(key);
        if (StrUtil.isEmpty(value)) {
            throw new IllegalArgumentException(key + "不能为空");
        }
        return value;
    }

    private String checkAndResetDir(Properties properties) {
        String value = check(properties, "data.dir");
        File dirFile = FileUtil.file(value);
        if (!dirFile.exists()) {
            boolean ok = FileUtil.mkdirsSafely(dirFile, 5, 1);
            if (ok) {
                PumaPrintStream.logInfo("初始化{}: {}", "data.dir", dirFile.getAbsolutePath());
                return dirFile.getAbsolutePath();
            } else {
                throw new RuntimeException("初始化data.dir失败: " + dirFile.getAbsolutePath());
            }
        }
        if (!dirFile.isDirectory()) {
            throw new RuntimeException("并非目录");
        }
        return dirFile.getAbsolutePath();
    }

    public String getDir() {
        return dir;
    }

    public String getDir(SideOpt sideOpt) {
        return dir + FileUtil.FILE_SEPARATOR + sideOpt.getLowerCaseName();
    }

    public String getGitSshKeyPath() {
        return gitSshKeyPath;
    }

    public String getJavaHomePath() {
        return javaHomePath;
    }

    public String getMavenHomePath() {
        return mavenHomePath;
    }
}
