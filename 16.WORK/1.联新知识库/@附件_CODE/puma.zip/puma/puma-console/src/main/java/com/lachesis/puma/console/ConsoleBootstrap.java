package com.lachesis.puma.console;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.core.builder.CodeBuilder;
import com.lachesis.puma.core.common.SideOpt;
import com.lachesis.puma.core.common.PumaStage;
import com.lachesis.puma.core.compare.Comparator;
import com.lachesis.puma.core.repo.CodeRepoManager;
import com.lachesis.puma.core.util.PumaPrintStream;
import org.apache.commons.cli.*;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.fusesource.jansi.Ansi;
import org.jline.reader.EndOfFileException;
import org.jline.reader.LineReader;
import org.jline.reader.LineReaderBuilder;
import org.jline.reader.UserInterruptException;
import org.jline.reader.impl.history.DefaultHistory;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;

import java.io.IOException;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import static com.lachesis.puma.core.util.PumaPrintStream.INPUT_PREFIX;

public class ConsoleBootstrap {

    private static final ConsoleBootstrap instance = new ConsoleBootstrap();
    private Terminal terminal;
    private LineReader lineReader;
    private ConsoleConfig config;
    private ConsoleContext context;

    private ConsoleBootstrap() {
    }

    public static ConsoleBootstrap getInstance() {
        return instance;
    }

    public boolean init(String[] args) {
        try {
            initJLine();
            String configPath = parse(args);
            initConfig(configPath);
            initContext();
            return true;
        } catch (ParseException e) {
            PumaPrintStream.logError(e, "参数解析异常");
            return false;
        } catch (Exception e) {
            PumaPrintStream.logError(e, "初始化异常");
            return false;
        }
    }

    private String parse(String[] args) throws ParseException {
        Option opt1 = new Option("c", "config", true, "指定配置");
        opt1.setRequired(false);
        Options options = new Options();
        options.addOption(opt1);
        CommandLineParser cliParser = new DefaultParser();
        CommandLine commandLine = cliParser.parse(options, args);
        if (!commandLine.hasOption("c")) {
            PumaPrintStream.logError("未指定配置文件路径");
        }
        return commandLine.getOptionValue("c");
    }

    private void initJLine() throws IOException {
        terminal = TerminalBuilder.builder()
            .streams(PumaPrintStream.in, PumaPrintStream.out)
            .system(true)
            .dumb(true)
            .encoding(PumaPrintStream.charset)
            .color(true)
            .build();
        PumaPrintStream.setPrintWriter(terminal.writer());
        lineReader = LineReaderBuilder.builder()
            .terminal(terminal)
            .history(new DefaultHistory())
            .build();
    }

    private void initConfig(String configPath) {
        config = ConsoleConfig.getInstance();
        config.init(configPath);
    }

    private void initContext() {
        context = ConsoleContext.getInstance(config);
        context.loadInput();
    }

    public void start() {
        boolean continueFlag = true;
        try {
            while (continueFlag) {
                String stepInput = readInput("#NAVIGATION", "请选择待执行操作({})", PumaStage.getPrompt());
                PumaStage stage = PumaStage.of(stepInput);
                if (stage == null) {
                    continue;
                }
                switch (stage) {
                    case CLONE:
                        startClone();
                        break;
                    case BUILD:
                        startBuild();
                        break;
                    case COMPARE:
                        startCompare();
                        break;
                    case CLEAR_SESSION:
                        doClearSession();
                        break;
                    case EXIST:
                        continueFlag = false;
                }
            }
        } catch (EndOfFileException | UserInterruptException e) {
            System.exit(1);
        } catch (Exception e) {
            PumaPrintStream.logError(e, "执行异常");
            System.exit(2);
        }
    }

    private void doClearSession() {
        context.clearSession();
        PumaPrintStream.logInfo("清空会话完成");
    }

    public void shutdown() {
        context.saveInput();
    }

    /* ------------------ 克隆 ------------------ */
    private void startClone() throws GitAPIException {
        while (true) {
            String gitUrl = readInput("@CLONE_GIT_URL", "请输入地址(SSH)");
            CodeRepoManager manager = CodeRepoManager.newInstance(gitUrl, config.getGitSshKeyPath());
            if (manager.checkGitUrl()) {
                context.setGitUrl(gitUrl);
                cloneBranch(manager);
                break;
            }
        }
    }

    private void cloneBranch(CodeRepoManager manager) throws GitAPIException {
        while (true) {
            String code = readInput("#CLONE_BRANCH_SELECT", "请选择克隆分支({})", SideOpt.getPrompt());
            if (SideOpt.RETURN.getCode().equals(code)) {
                break;
            }
            SideOpt sideOpt = SideOpt.ofCode(code);
            if (sideOpt != null) {
                startClone(manager, sideOpt);
            }
        }
    }

    private void startClone(CodeRepoManager manager, SideOpt sideOpt) throws GitAPIException {
        String branch = readInput("@CLONE_" + sideOpt + "_BRANCH", "请输入{}分支", sideOpt.getDesc());
        manager.clone(branch, config.getDir(sideOpt));
        context.setBranch(branch, sideOpt);
    }

    /* ------------------ 构建 ------------------ */
    private void startBuild() throws Exception {
        do {
            String branchRole = readInput("#BUILD_SELECT", "请选择构建分支({})", SideOpt.getPrompt());
            if (SideOpt.RETURN.getCode().equals(branchRole)) {
                break;
            }
            SideOpt sideOpt = SideOpt.ofCode(branchRole);
            if (sideOpt != null) {
                startBuild(sideOpt);
            }
        } while (true);
    }

    private void startBuild(SideOpt sideOpt) throws Exception {
        CodeBuilder codeBuilder = CodeBuilder.newInstance(config.getJavaHomePath(), config.getMavenHomePath());
        String projectPath = context.getProjectPath(sideOpt);
        if (StrUtil.isEmpty(projectPath)) {
            String projectName = readInput("@BUILD_PROJECT_NAME", "请输入项目名称");
            context.setProjectInfo(projectName);
            projectPath = context.getProjectPath(sideOpt);
        }
        startBuild(codeBuilder, projectPath, sideOpt);
    }

    private void startBuild(CodeBuilder codeBuilder, String projectPath, SideOpt sideOpt) throws Exception {
        codeBuilder.build(projectPath, "clean package -DskipTests");
        if (!codeBuilder.isSuccess()) {
            return;
        }
        while (true) {
            String projectFilePath = readInput("@MOVE_" + sideOpt + "_FILE", "请输入比较文件路径");
            if (StrUtil.isNotEmpty(projectFilePath)) {
                String absoluteProjectFilePath = projectPath + FileUtil.FILE_SEPARATOR + projectFilePath;
                if (FileUtil.exist(absoluteProjectFilePath)) {
                    context.setProjectFilePath(projectFilePath);
                    // 将构建完成的文件复制到根目录下
                    String toDir = config.getDir(sideOpt);
                    FileUtil.copy(Paths.get(absoluteProjectFilePath), Paths.get(toDir), StandardCopyOption.REPLACE_EXISTING);
                    PumaPrintStream.logInfo("复制比较文件: {}", absoluteProjectFilePath);
                    PumaPrintStream.logInfo("复制到目录: {}", toDir);
                    break;
                } else {
                    PumaPrintStream.logWarn("文件不存在: {}", absoluteProjectFilePath);
                }
            }
        }
    }

    private void startCompare() {
        String sourceProjectFile = checkProjectPath(SideOpt.SOURCE);
        String targetProjectFile = checkProjectPath(SideOpt.TARGET);
        String includeExpressionInput = readInput("@COMPARE_INCLUDE_PATH", "包括比较路径");
        String excludeExpressionInput = readInput("@COMPARE_EXCLUDE_PATH", "排除比较路径");
        Comparator comparator = Comparator.newInstance(sourceProjectFile, targetProjectFile);
        comparator.setIncludeExpression(includeExpressionInput);
        comparator.setExcludeExpression(excludeExpressionInput);
        comparator.compare();
    }

    private String checkProjectPath(SideOpt sideOpt) {
        String path = context.getFilePath(sideOpt);
        while (true) {
            if (isValid(path)) {
                context.setFilePath(sideOpt, path);
                break;
            }
            path = readInput("@COMPARE_" + sideOpt + "_FILE_PATH", "请输入{}比较文件路径", sideOpt.getDesc());
        }
        return path;
    }

    private boolean isValid(String path) {
        if (StrUtil.isEmpty(path)) {
            return false;
        }
        if (!FileUtil.exist(path)) {
            PumaPrintStream.logWarn("文件不存在");
            return false;
        }
        return true;
    }

    /**
     * 读取输入
     *
     * @param inputId  输入id，主要用作历史记录命令记录使用，所以必须保证唯一性
     * @param template 输入提示模板
     * @param params   输入提示参数
     * @return 输入内容
     */
    private String readInput(String inputId, String template, Object... params) {
        String promptContent = StrUtil.format(template, params);
        String prompt = StrUtil.format("{} {}: ", INPUT_PREFIX, promptContent);
        // 以@表示使用缓存
        String line;
        if (inputId.contains("@")) {
            String historyInput = context.getInput(inputId);
            boolean tip = StrUtil.isNotEmpty(historyInput);
            if (tip) {
                PumaPrintStream.logInfo(PumaPrintStream.formatStr(StrUtil.format("历史输入记录: {}", historyInput), Ansi.Color.MAGENTA));
            }
            line = lineReader.readLine(prompt);
            if (tip && StrUtil.isEmpty(line)) {
                line = historyInput;
                PumaPrintStream.logInfo(PumaPrintStream.formatStr(StrUtil.format("使用历史记录"), Ansi.Color.MAGENTA));
            }
            context.putInput(inputId, line);
            return line;
        }
        line = lineReader.readLine(prompt);
        return line;
    }
}
