package com.lachesis.puma.console;

import cn.hutool.core.io.FileUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.lachesis.puma.core.common.SideOpt;
import com.lachesis.puma.core.util.CommonUtil;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class ConsoleContext {

    private static volatile ConsoleContext context;
    private JSONObject inputs;
    // D:\\IdeaProjects\\mine\\puma\\data\\input.json
    private String inputFilePath;
    // D:\\IdeaProjects\\mine\\puma\\data\\source
    private String sourceDir;
    // D:\\IdeaProjects\\mine\\puma\\data\\target
    private String targetDir;

    // git@10.2.3.111:backend_group/data_sync/data_sync.git
    private String gitUrl;
    // data_sync
    private String projectName;

    // data-sync-web\\target\\WRMSSync.jar
    private String projectFilePath;
    // WRMSSync.jar
    private String projectFileName;
    // fix_master_wpb_test
    private String sourceBranch;
    // master
    private String targetBranch;
    // D:\\IdeaProjects\\mine\\puma\\data\\source\\data_sync
    private String sourceProjectPath;
    // D:\\IdeaProjects\\mine\\puma\\data\\target\\data_sync
    private String targetProjectPath;
    // D:\\IdeaProjects\\mine\\puma\\data\\source\\data_sync\\data-sync-web\\target\\WRMSSync.jar
    private String sourceProjectFilePath;
    // D:\\IdeaProjects\\mine\\puma\\data\\target\\data_sync\\data-sync-web\\target\\WRMSSync.jar
    private String targetProjectFilePath;
    // D:\\IdeaProjects\\mine\\puma\\data\\source\\WRMSSync.jar
    private String sourceFilePath;
    // D:\\IdeaProjects\\mine\\puma\\data\\target\\WRMSSync.jar
    private String targetFilePath;

    public ConsoleContext(ConsoleConfig config) {
        this.sourceDir = config.getDir(SideOpt.SOURCE);
        this.targetDir = config.getDir(SideOpt.TARGET);
        this.inputFilePath = config.getDir() + FileUtil.FILE_SEPARATOR + "input.json";
    }

    public static ConsoleContext getInstance(ConsoleConfig config) {
        synchronized (ConsoleContext.class) {
            if (context == null) {
                synchronized (ConsoleContext.class) {
                    if (context == null) {
                        context = new ConsoleContext(config);
                    }
                }
            }
        }
        return context;
    }

    public void setGitUrl(String gitUrl) {
        this.gitUrl = gitUrl;
        setProjectInfo(CommonUtil.getProjectName(gitUrl));
    }

    public void setProjectInfo(String projectName) {
        this.projectName = projectName;
        this.sourceProjectPath = sourceDir + FileUtil.FILE_SEPARATOR + projectName;
        this.targetProjectPath = targetDir + FileUtil.FILE_SEPARATOR + projectName;
    }

    public void setBranch(String branch, SideOpt sideOpt) {
        if (SideOpt.SOURCE.equals(sideOpt)) {
            sourceBranch = branch;
        } else {
            targetBranch = branch;
        }
    }

    public void setProjectFilePath(String projectFilePath) {
        this.projectFilePath = projectFilePath;
        this.projectFileName = projectFilePath.substring(projectFilePath.lastIndexOf(FileUtil.FILE_SEPARATOR) + 1);
        this.sourceProjectFilePath = sourceProjectPath + FileUtil.FILE_SEPARATOR + projectFilePath;
        this.targetProjectFilePath = targetProjectPath + FileUtil.FILE_SEPARATOR + projectFilePath;
        this.sourceFilePath = sourceDir + FileUtil.FILE_SEPARATOR + projectFileName;
        this.targetFilePath = targetDir + FileUtil.FILE_SEPARATOR + projectFileName;
    }

    public String getProjectPath(SideOpt sideOpt) {
        if (SideOpt.SOURCE.equals(sideOpt)) {
            return sourceProjectPath;
        } else {
            return targetProjectPath;
        }
    }

    public String getFilePath(SideOpt sideOpt) {
        if (SideOpt.SOURCE.equals(sideOpt)) {
            return sourceFilePath;
        } else {
            return targetFilePath;
        }
    }

    public Map<String, Object> getInputs() {
        return inputs;
    }

    public String getGitUrl() {
        return gitUrl;
    }

    public String getProjectName() {
        return projectName;
    }

    public String getSourceDir() {
        return sourceDir;
    }

    public String getTargetDir() {
        return targetDir;
    }

    public String getProjectFilePath() {
        return projectFilePath;
    }

    public String getProjectFileName() {
        return projectFileName;
    }

    public String getSourceBranch() {
        return sourceBranch;
    }

    public String getTargetBranch() {
        return targetBranch;
    }

    public String getSourceProjectPath() {
        return sourceProjectPath;
    }

    public String getTargetProjectPath() {
        return targetProjectPath;
    }

    public String getSourceProjectFilePath() {
        return sourceProjectFilePath;
    }

    public String getTargetProjectFilePath() {
        return targetProjectFilePath;
    }

    public void setSourceFilePath(String sourceFilePath) {
        this.sourceFilePath = sourceFilePath;
    }

    public String getSourceFilePath() {
        return sourceFilePath;
    }

    public void setTargetFilePath(String targetFilePath) {
        this.targetFilePath = targetFilePath;
    }

    public String getTargetFilePath() {
        return targetFilePath;
    }

    public void putInput(String inputId, String line) {
        inputs.set(inputId, line);
    }

    public void loadInput() {
        if (FileUtil.exist(inputFilePath)) {
            String readString = FileUtil.readString(inputFilePath, StandardCharsets.UTF_8);
            inputs = JSONUtil.parseObj(readString);
        } else {
            inputs = new JSONObject();
        }
    }

    public void saveInput() {
        File file = FileUtil.newFile(inputFilePath);
        if (!file.exists() || file.delete()) {
            FileUtil.writeString(JSONUtil.toJsonStr(inputs), file, StandardCharsets.UTF_8);
        }
    }

    public String getInput(String inputId) {
        return inputs.getStr(inputId);
    }

    public void setFilePath(SideOpt sideOpt, String path) {
        if (SideOpt.SOURCE.equals(sideOpt)) {
            this.sourceFilePath = path;
        } else {
            this.targetFilePath = path;
        }
    }

    public void clearSession() {
        gitUrl = null;
        projectName = null;
        projectFilePath = null;
        projectFileName = null;
        sourceBranch = null;
        targetBranch = null;
        sourceProjectPath = null;
        targetProjectPath = null;
        sourceProjectFilePath = null;
        targetProjectFilePath = null;
        sourceFilePath = null;
        targetFilePath = null;
        inputs.clear();
    }
}
