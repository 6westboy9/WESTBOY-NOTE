package com.lachesis.puma.console;


import org.fusesource.jansi.AnsiConsole;

public class ConsoleMain {

    public static void main(String[] args) {
        AnsiConsole.systemInstall();
        ConsoleBootstrap bootstrap = ConsoleBootstrap.getInstance();
        if (bootstrap.init(args)) {
            Runtime.getRuntime().addShutdownHook(
                new Thread(() -> {
                    bootstrap.shutdown();
                    AnsiConsole.systemUninstall();
                })
            );
            bootstrap.start();
        }
    }
}
