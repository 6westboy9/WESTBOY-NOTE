package com.lachesis.puma;

import me.tongfei.progressbar.ProgressBar;
import org.junit.jupiter.api.Test;

import java.util.concurrent.TimeUnit;

class ProgressBarTest {

    @Test
    void test1() {
        try (ProgressBar pb = new ProgressBar("Test", 10)) { // name, initial max
            // Use ProgressBar("Test", 100, ProgressBarStyle.ASCII) if you want ASCII output style
            for (int i = 1; i <= 10; i++) {
                // pb.step(); // step by 1
                TimeUnit.SECONDS.sleep(1);
                pb.stepBy(1); // step by n
                // pb.stepTo(); // step directly to n
                // if (i == 100) {
                //     pb.maxHint(100);
                // }

                // reset the max of this progress bar as n. This may be useful when the program
                // gets new information about the current progress.
                // Can set n to be less than zero: this means that this progress bar would become
                // indefinite: the max would be unknown.
                pb.setExtraMessage("Reading..."); // Set extra message to display at the end of the bar
            }
        } //
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
