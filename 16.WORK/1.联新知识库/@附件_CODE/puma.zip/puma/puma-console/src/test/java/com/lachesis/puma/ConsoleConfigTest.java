package com.lachesis.puma;

import com.lachesis.puma.console.ConsoleConfig;
import org.junit.jupiter.api.Test;

class ConsoleConfigTest {

    @Test
    void init() {
        ConsoleConfig.getInstance().init(null);
    }
}