package com.lachesis.puma.server.controller;

import cn.hutool.json.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@Controller
@RequestMapping("/")
public class IndexController {

    @RequestMapping("fileUpload")
    @ResponseBody
    public JSONObject upload(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
        JSONObject result = new JSONObject();
        if (file.isEmpty()) {
            result.set("state", "文件为空");
        } else {
            result.set("state", "上传成功");
        }
        result.set("filename", file.getOriginalFilename());
        result.set("size", file.getSize());
        log.info("后台接受到的上传文件[{}]大小: {}", file.getOriginalFilename(), file.getSize());
        return result;
    }

}
