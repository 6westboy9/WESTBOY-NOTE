package com.lachesis.puma.server.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InfoVO {
    private Integer bookId;
    private Integer userId;
    private String bookName;
    private String img;
    private String author;
}
