package com.lachesis.puma.protocol.network;

public enum SegmentRefType {

    /**
     * 跨进程
     */
    CROSS_PROCESS(0),
    /**
     * 跨线程
     */
    CROSS_THREAD(1);

    private final int type;

    SegmentRefType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }
}
