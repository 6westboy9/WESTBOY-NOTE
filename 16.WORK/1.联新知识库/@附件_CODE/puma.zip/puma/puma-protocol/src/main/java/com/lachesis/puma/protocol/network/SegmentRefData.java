package com.lachesis.puma.protocol.network;

public class SegmentRefData {

    private SegmentRefType refType;
    private String traceId;
    private String parentTraceSegmentId;
    private int parentSpanId;
    private String parentService;
    private String parentServiceInstance;
    private String parentEndpoint;
    private String networkAddressUsedAtPeer;

    public SegmentRefType getRefType() {
        return refType;
    }

    public void setRefType(SegmentRefType refType) {
        this.refType = refType;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getParentTraceSegmentId() {
        return parentTraceSegmentId;
    }

    public void setParentTraceSegmentId(String parentTraceSegmentId) {
        this.parentTraceSegmentId = parentTraceSegmentId;
    }

    public int getParentSpanId() {
        return parentSpanId;
    }

    public void setParentSpanId(int parentSpanId) {
        this.parentSpanId = parentSpanId;
    }

    public String getParentService() {
        return parentService;
    }

    public void setParentService(String parentService) {
        this.parentService = parentService;
    }

    public String getParentServiceInstance() {
        return parentServiceInstance;
    }

    public void setParentServiceInstance(String parentServiceInstance) {
        this.parentServiceInstance = parentServiceInstance;
    }

    public String getParentEndpoint() {
        return parentEndpoint;
    }

    public void setParentEndpoint(String parentEndpoint) {
        this.parentEndpoint = parentEndpoint;
    }

    public String getNetworkAddressUsedAtPeer() {
        return networkAddressUsedAtPeer;
    }

    public void setNetworkAddressUsedAtPeer(String networkAddressUsedAtPeer) {
        this.networkAddressUsedAtPeer = networkAddressUsedAtPeer;
    }
}
