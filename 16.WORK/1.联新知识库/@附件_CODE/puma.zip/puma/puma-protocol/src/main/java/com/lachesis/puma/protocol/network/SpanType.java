package com.lachesis.puma.protocol.network;

public enum SpanType {

    ENTRY(0),
    EXIT(1),
    LOCAL(2);

    private final int id;

    SpanType(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
