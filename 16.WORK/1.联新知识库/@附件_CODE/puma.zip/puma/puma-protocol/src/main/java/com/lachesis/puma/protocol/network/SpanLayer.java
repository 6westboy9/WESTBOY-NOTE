package com.lachesis.puma.protocol.network;

public enum SpanLayer {

    CODE(0),
    DB(1),
    RPC(2),
    HTTP(3),
    MQ(4),
    CACHE(5),
    ;

    private final int id;

    SpanLayer(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
