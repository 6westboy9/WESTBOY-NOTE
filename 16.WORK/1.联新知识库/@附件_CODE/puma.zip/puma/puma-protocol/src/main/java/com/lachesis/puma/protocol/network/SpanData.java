package com.lachesis.puma.protocol.network;

import java.util.LinkedList;
import java.util.List;

public class SpanData {

    private int spanId;
    private int parentSpanId;
    private long startTime;
    private long endTime;
    private List<SegmentRefData> refs = new LinkedList<>();
    private String opName;
    private String peer;
    private SpanType spanType;
    private SpanLayer spanLayer;
    private long componentId;
    private boolean isError;
    private List<StrKeyValuePair> tags = new LinkedList<>();
    private List<LogData> logs = new LinkedList<>();

    public int getSpanId() {
        return spanId;
    }

    public void setSpanId(int spanId) {
        this.spanId = spanId;
    }

    public int getParentSpanId() {
        return parentSpanId;
    }

    public void setParentSpanId(int parentSpanId) {
        this.parentSpanId = parentSpanId;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public List<SegmentRefData> getRefs() {
        return refs;
    }

    public void setRefs(List<SegmentRefData> refs) {
        this.refs = refs;
    }

    public void addRef(SegmentRefData ref) {
        refs.add(ref);
    }

    public String getOpName() {
        return opName;
    }

    public void setOpName(String opName) {
        this.opName = opName;
    }

    public String getPeer() {
        return peer;
    }

    public void setPeer(String peer) {
        this.peer = peer;
    }

    public SpanType getSpanType() {
        return spanType;
    }

    public void setSpanType(SpanType spanType) {
        this.spanType = spanType;
    }

    public SpanLayer getSpanLayer() {
        return spanLayer;
    }

    public void setSpanLayer(SpanLayer spanLayer) {
        this.spanLayer = spanLayer;
    }

    public long getComponentId() {
        return componentId;
    }

    public void setComponentId(long componentId) {
        this.componentId = componentId;
    }

    public boolean isError() {
        return isError;
    }

    public void setError(boolean error) {
        isError = error;
    }

    public List<StrKeyValuePair> getTags() {
        return tags;
    }

    public void setTags(List<StrKeyValuePair> tags) {
        this.tags = tags;
    }

    public void addTag(StrKeyValuePair tag) {
        tags.add(tag);
    }

    public List<LogData> getLogs() {
        return logs;
    }

    public void setLogs(List<LogData> logs) {
        this.logs = logs;
    }

    public void addLog(LogData log) {
        logs.add(log);
    }
}
