package com.lachesis.puma.protocol.network;

import java.util.LinkedList;
import java.util.List;

public class LogData {

    private long time;
    private List<StrKeyValuePair> data = new LinkedList<>();

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public List<StrKeyValuePair> getData() {
        return data;
    }

    public void setData(List<StrKeyValuePair> data) {
        this.data = data;
    }

    public void addData(StrKeyValuePair data) {
        this.data.add(data);
    }
}
