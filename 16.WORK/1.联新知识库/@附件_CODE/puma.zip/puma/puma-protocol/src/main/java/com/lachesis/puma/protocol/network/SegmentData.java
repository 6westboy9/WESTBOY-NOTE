package com.lachesis.puma.protocol.network;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class SegmentData implements Serializable {

    private String traceId;
    private String traceSegmentId;
    private List<SpanData> spans = new LinkedList<>();
    private String service;
    private String serviceInstance;

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getTraceSegmentId() {
        return traceSegmentId;
    }

    public void setTraceSegmentId(String traceSegmentId) {
        this.traceSegmentId = traceSegmentId;
    }

    public List<SpanData> getSpans() {
        return spans;
    }

    public void setSpans(List<SpanData> spans) {
        this.spans = spans;
    }

    public void addSpan(SpanData spanData) {
        spans.add(spanData);
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getServiceInstance() {
        return serviceInstance;
    }

    public void setServiceInstance(String serviceInstance) {
        this.serviceInstance = serviceInstance;
    }
}
