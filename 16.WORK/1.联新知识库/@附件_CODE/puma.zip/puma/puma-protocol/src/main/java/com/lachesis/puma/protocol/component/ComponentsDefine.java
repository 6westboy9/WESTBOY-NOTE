/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.lachesis.puma.protocol.component;

public class ComponentsDefine {

    public static final Component CODE = new Component(0, "Code");
    public static final Component TOMCAT = new Component(1, "Tomcat");
    public static final Component HTTPCLIENT = new Component(2, "HttpClient");
    public static final Component DUBBO = new Component(3, "Dubbo");
    public static final Component SPRING_MVC = new Component(4, "SpringMvc");
    public static final Component MONGO_DRIVER = new Component(5, "mongodb-driver");
    public static final Component RABBITMQ_PRODUCER = new Component(6, "rabbitmq-producer");
    public static final Component RABBITMQ_CONSUMER = new Component(7, "rabbitmq-consumer");
    public static final Component ZOOKEEPER = new Component(8, "Zookeeper");
    public static final Component MYSQL_DRIVER = new Component(9, "mysql-connector-driver");
    public static final Component MSSQL_JDBC_DRIVER = new Component(10, "mssql-jdbc-driver");
    public static final Component ORACLE_DRIVER = new Component(11, "ojdbc");
    public static final Component POSTGRESQL_DRIVER = new Component(12, "postgresql-jdbc-driver");
    public static final Component MYBATIS = new Component(13, "MyBatis");
    public static final Component JDK_THREAD = new Component(14, "JdkThread");

}
