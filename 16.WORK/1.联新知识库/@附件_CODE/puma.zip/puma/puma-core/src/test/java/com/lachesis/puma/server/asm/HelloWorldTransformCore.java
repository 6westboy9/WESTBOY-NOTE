package com.lachesis.puma.server.asm;

import cn.hutool.core.io.FileUtil;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;

import java.io.File;

public class HelloWorldTransformCore {

    public static void main(String[] args) {
        String filepath = "D:\\IdeaProjects\\mine\\puma\\puma-server\\target\\classes\\com\\lachesis\\puma\\server\\test\\HelloWord.class";
        File file = FileUtil.file(filepath);
        byte[] bytes1 = FileUtil.readBytes(file);

        ClassReader cr = new ClassReader(bytes1);
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES);

        int api = Opcodes.ASM9;
        ClassVisitor cv = new InfoClassVisitor(api, cw);

        int parsingOptions = ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES;
        cr.accept(cv, parsingOptions);

        byte[] bytes2 = cw.toByteArray();

        String filepath1 = file.getParent()
            + FileUtil.FILE_SEPARATOR + "generated"
            + FileUtil.FILE_SEPARATOR + file.getName();
        FileUtil.writeBytes(bytes2, filepath1);
    }
}
