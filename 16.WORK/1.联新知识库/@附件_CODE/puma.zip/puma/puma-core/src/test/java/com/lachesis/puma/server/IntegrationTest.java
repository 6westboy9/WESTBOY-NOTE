package com.lachesis.puma.server;

import cn.hutool.core.io.FileUtil;
import com.lachesis.puma.core.builder.CodeBuilder;
import com.lachesis.puma.core.compare.Comparator;
import com.lachesis.puma.core.compare.CompareResultCollector;
import com.lachesis.puma.core.repo.CodeRepoManager;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import static cn.hutool.core.io.FileUtil.FILE_SEPARATOR;

@Slf4j
class IntegrationTest {

    /**
     * 一般为开发分支
     */
    private final String sourceDir = "D:\\IdeaProjects\\mine\\puma\\data\\source";
    /**
     * 一般为主线分支
     */
    private final String targetDir = "D:\\IdeaProjects\\mine\\puma\\data\\target";
    private final String projectName = "data_sync";
    private final String projectFile = "data-sync-web\\target\\WRMSSync.jar";
    private final String projectFileName = projectFile.substring(projectFile.lastIndexOf(FILE_SEPARATOR) + 1);

    private final String sourceBranch = "fix_master_wpb_test";
    private final String targetBranch = "master";

    private final String gitUrl = "git@10.2.3.111:backend_group/data_sync/data_sync.git";
    private final String sshPrivateKeyPath = "~\\.ssh\\id_rsa";

    /**
     * 配置
     */
    private final String mavenHomePath = "D:\\Program Files\\apache-maven-3.8.8";
    private final String javaHomePath = "D:\\Program Files\\Java\\jdk1.8.0_202";

    /**
     * 项目克隆指定的目录路径
     * <ul>
     *     <li>D:\IdeaProjects\mine\puma\data\source\data_sync</li>
     *     <li>D:\IdeaProjects\mine\puma\data\target\data_sync</li>
     * </ul>
     */
    private String sourceCloneProjectPath = sourceDir + FILE_SEPARATOR + projectName;
    private String targetCloneProjectPath = targetDir + FILE_SEPARATOR + projectName;
    /**
     * 项目构建完成后指定的待比较文件路径
     * <ul>
     *     <li>D:\IdeaProjects\mine\puma\data\source\data_sync\data-sync-web\target\WRMSSync.jar</li>
     *     <li>D:\IdeaProjects\mine\puma\data\target\data_sync\data-sync-web\target\WRMSSync.jar</li>
     * </ul>
     */
    private String sourceBuildProjectFile = sourceCloneProjectPath + FILE_SEPARATOR + projectFile;
    private String targetBuildProjectFile = targetCloneProjectPath + FILE_SEPARATOR + projectFile;

    /**
     * 待比较文件路径（在构建完成之后，会将待比较文件复制至此）
     * <ul>
     *     <li>D:\IdeaProjects\mine\puma\data\source\WRMSSync.jar</li>
     *     <li>D:\IdeaProjects\mine\puma\data\target\WRMSSync.jar</li>
     * </ul>
     */
    private String sourceCompareProjectFile = sourceDir + FILE_SEPARATOR + projectFileName;
    private String targetCompareProjectFile = targetDir + FILE_SEPARATOR + projectFileName;

    @Test
    void test() {
        log.info("{}", FILE_SEPARATOR);
        log.info("{}", sourceCompareProjectFile);
        log.info("{}", targetCompareProjectFile);
    }

    @Test
    void testClone() throws Exception {
        CodeRepoManager manager = CodeRepoManager.newInstance(gitUrl, sshPrivateKeyPath);
        manager.clone(sourceBranch, sourceDir);
        manager.clone(targetBranch, targetDir);
    }

    @Test
    void testClean() throws Exception {
        CodeBuilder codeBuilder = CodeBuilder.newInstance(javaHomePath, mavenHomePath);
        codeBuilder.build(checkAndGetPomPath(sourceCloneProjectPath), "clean");
        codeBuilder.build(checkAndGetPomPath(targetCloneProjectPath), "clean");
    }

    @Test
    void testBuild() throws Exception {
        CodeBuilder codeBuilder = CodeBuilder.newInstance(javaHomePath, mavenHomePath);
        codeBuilder.build(checkAndGetPomPath(sourceCloneProjectPath), "clean package -DskipTests");
        codeBuilder.build(checkAndGetPomPath(targetCloneProjectPath), "clean package -DskipTests");
        move(sourceBuildProjectFile, sourceDir);
        move(targetBuildProjectFile, targetDir);
    }

    @Test
    void testCompare() {
        Comparator comparator = Comparator.newInstance(sourceCompareProjectFile, targetCompareProjectFile);
        comparator.setIncludeExpression("*.class:*/data-sync-controller-2.1.1.jar:*/data-sync-service-2.1.1.jar");
        comparator.setExcludeExpression("org/*");
        comparator.compare();
        CompareResultCollector collector = comparator.getCollector();
        collector.printLog(true);
    }

    private void move(String from, String to) {
        FileUtil.copy(Paths.get(from), Paths.get(to), StandardCopyOption.REPLACE_EXISTING);
    }

    private String checkAndGetPomPath(String projectPath) throws FileNotFoundException {
        String pomPath = projectPath + FILE_SEPARATOR + "pom.xml";
        if (!FileUtil.exist(pomPath)) {
            throw new FileNotFoundException(pomPath);
        }
        return pomPath;
    }
}
