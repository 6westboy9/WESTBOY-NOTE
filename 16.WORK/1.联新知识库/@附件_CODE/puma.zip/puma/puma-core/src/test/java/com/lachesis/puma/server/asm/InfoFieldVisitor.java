package com.lachesis.puma.server.asm;

import org.objectweb.asm.FieldVisitor;

public class InfoFieldVisitor extends FieldVisitor {

    public InfoFieldVisitor(int api, FieldVisitor fieldVisitor) {
        super(api, fieldVisitor);
    }

    @Override
    public void visitEnd() {
        System.out.println("    FieldVisitor.visitEnd();");
        super.visitEnd();
    }
}
