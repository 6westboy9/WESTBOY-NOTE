package com.lachesis.puma.server.util;

import org.fusesource.jansi.Ansi;

public class JLineColorTest {
    public static void main(String[] args) {
        // try {
        //     Terminal terminal = TerminalBuilder.builder().system(true).build();
        //     AttributedString redText = new AttributedString("This text is red.", AttributedStyle.DEFAULT.foreground(AttributedStyle.RED));
        //     AttributedString greenText = new AttributedString("This text is green.", AttributedStyle.DEFAULT.foreground(AttributedStyle.GREEN));
        //     AttributedString defaultText = new AttributedString("This text is back to default color.", AttributedStyle.DEFAULT);
        //     terminal.writer().append(redText.toAnsi()).append("\n");
        //     terminal.writer().append(greenText.toAnsi()).append("\n");
        //     terminal.writer().append(defaultText.toAnsi()).append("\n");
        //
        //     terminal.writer().println(ConsoleColorHelper.toAnsi("A", FontColorEnum.BLACK));
        //     terminal.writer().println(ConsoleColorHelper.toAnsi("A", FontColorEnum.RED));
        //     terminal.writer().println(ConsoleColorHelper.toAnsi("A", FontColorEnum.GREEN));
        //     terminal.writer().println(ConsoleColorHelper.toAnsi("A", FontColorEnum.YELLOW));
        //     terminal.writer().println(ConsoleColorHelper.toAnsi("A", FontColorEnum.MAGENTA));
        //     terminal.writer().println(ConsoleColorHelper.toAnsi("A", FontColorEnum.BLUE));
        //     terminal.writer().println(ConsoleColorHelper.toAnsi("A", FontColorEnum.CYAN));
        //
        //     terminal.flush();
        //     terminal.close();
        // } catch (Exception e) {
        //     e.printStackTrace();
        // }

        output("A", Ansi.Color.BLACK);
        output("A", Ansi.Color.RED);
        output("A", Ansi.Color.GREEN);
        output("A", Ansi.Color.YELLOW);
        output("A", Ansi.Color.MAGENTA);
        output("A", Ansi.Color.BLUE);
        output("A", Ansi.Color.CYAN);
    }

    public static Ansi formatStr(String content, Ansi.Color colour) {
        return Ansi.ansi().fg(colour).a(content);
    }

    public static void output(String content, Ansi.Color colour) {
        System.out.println(formatStr(content, colour).toString());
    }
}
