package com.lachesis.puma.server.pull;

import com.lachesis.puma.core.repo.CodeRepoManager;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CodeRepoManagerTest {

    private CodeRepoManager manager;

    @BeforeEach
    void init() {
        String sshPriKeyPath = "~\\.ssh\\id_rsa";
        String gitUrl = "git@10.2.3.111:backend_group/data_sync/data_sync.git";
        manager = CodeRepoManager.newInstance(gitUrl, sshPriKeyPath);
    }

    // git clone git@10.2.3.111:backend_group/data_sync/data_sync.git
    // git remote -v
    // git remote add origin git@10.2.3.111:backend_group/data_sync/data_sync.git
    // git fetch origin bug_master_hcy_25395:bug_master_hcy_25395
    // git checkout bug_master_hcy_25395
    // git diff bug_master_hcy_25395 master

    @Test
    void cloneWithSsh() throws GitAPIException {
        manager.clone("master", "D:\\IdeaProjects\\mine\\puma\\data\\jgit");
    }

    @Test
    void diff() {
        // git diff bug_master_hcy_25395 master
        // manager.diff("bug_master_hcy_25395", "master", "D:\\IdeaProjects\\tmp");
    }
}