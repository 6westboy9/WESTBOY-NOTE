package com.lachesis.puma.server.builder;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.core.builder.CodeBuilder;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.PrintStream;

class CodeBuilderTest {

    @Test
    void operationMavenOrder() throws Exception {
        String mavenHomePath = "D:\\Program Files\\apache-maven-3.8.8";
        String javaHomePath = "D:\\Program Files\\Java\\jdk1.8.0_202";
        String path = "D:\\IdeaProjects\\mine\\puma\\data\\jgit\\data_sync";
        String mavenOrder = "clean package -DskipTests";
        String dateStr = DateUtil.format(DateUtil.date(), "yyyyMMddHHmmss");
        File logFile = FileUtil.newFile(StrUtil.format("D:\\IdeaProjects\\mine\\puma\\data\\log\\build-{}.log", dateStr));
        if (!logFile.exists()) {
            FileUtil.touch(logFile);
        }
        CodeBuilder codeBuilder = CodeBuilder.newInstance(javaHomePath, mavenHomePath);
        codeBuilder.build(path, mavenOrder);
    }
}