package com.lachesis.puma.server.compare;


import com.lachesis.puma.core.util.WildcardMatcher;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class WildcardMatcherTest {

    @Test
    void matches_01() {
        WildcardMatcher matcher = new WildcardMatcher("*.class");
        boolean res = matcher.matches("a.class");
        Assertions.assertTrue(res);
    }

    @Test
    void matches_11() {
        WildcardMatcher matcher = new WildcardMatcher("*.class:*/data-sync-controller-2.1.1.jar");
        boolean res = matcher.matches("BOOT-INF/lib/data-sync-controller-2.1.1.jar");
        Assertions.assertTrue(res);
    }

    @Test
    void matches_12() {
        WildcardMatcher matcher = new WildcardMatcher("*.class:data-sync-controller-2.1.1.jar");
        boolean res = matcher.matches("BOOT-INF/lib/data-sync-controller-2.1.1.jar");
        Assertions.assertFalse(res);
    }

}