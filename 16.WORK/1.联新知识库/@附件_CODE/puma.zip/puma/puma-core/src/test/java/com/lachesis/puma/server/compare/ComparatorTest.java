package com.lachesis.puma.server.compare;

import cn.hutool.core.io.FileUtil;
import cn.hutool.json.JSONUtil;
import com.lachesis.puma.core.compare.Comparator;
import com.lachesis.puma.core.compare.asm.CompareVisitor;
import com.lachesis.puma.core.compare.model.CompareClass;
import com.lachesis.puma.core.util.PumaPrintStream;
import org.junit.jupiter.api.Test;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.util.Textifier;
import org.objectweb.asm.util.TraceClassVisitor;

import java.io.File;
import java.io.PrintWriter;

class ComparatorTest {

    @Test
    void print() {
        byte[] bytes = FileUtil.readBytes(new File("D:\\IdeaProjects\\mine\\puma\\data\\asm\\TlogConfig.class"));
        ClassReader reader = new ClassReader(bytes);
        Textifier printer = new Textifier();
        TraceClassVisitor visitor = new TraceClassVisitor(null, printer, new PrintWriter(System.out));
        reader.accept(visitor, 0);
    }

    @Test
    void buildClass() {
        byte[] bytes = FileUtil.readBytes(new File("D:\\IdeaProjects\\mine\\puma\\puma-server\\target\\classes\\com\\lachesis\\puma\\server\\test\\HelloWord.class"));
        ClassReader reader = new ClassReader(bytes);
        CompareVisitor visitor = new CompareVisitor();
        reader.accept(visitor, ClassReader.SKIP_FRAMES);
        CompareClass compareClass = visitor.getCompareClass();
        PumaPrintStream.logInfo("{}", JSONUtil.toJsonStr(compareClass));
    }

    @Test
    void compare() {
        String source = "D:\\IdeaProjects\\mine\\puma\\data\\source\\WRMSSync.jar";
        String target = "D:\\IdeaProjects\\mine\\puma\\data\\target\\WRMSSync.jar";
        Comparator comparator = Comparator.newInstance(source, target);
        comparator.setIncludeExpression("*.class:*/data-sync-controller-2.1.1.jar:*/data-sync-service-2.1.1.jar");
        comparator.setExcludeExpression("org/*");
        comparator.compare();
    }
}