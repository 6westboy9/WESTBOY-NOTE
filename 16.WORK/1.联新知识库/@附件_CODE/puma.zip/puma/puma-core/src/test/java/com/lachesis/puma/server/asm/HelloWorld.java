package com.lachesis.puma.server.asm;

public class HelloWorld {

    public int intValue;

    public String strValue;

    public int add(int a, int b) {
        return a + b;
    }

    public int sub(int a, int b) {
        return a - b;
    }
}
