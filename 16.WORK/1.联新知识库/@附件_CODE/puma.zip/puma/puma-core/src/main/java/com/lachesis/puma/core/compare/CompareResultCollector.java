package com.lachesis.puma.core.compare;

import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.core.common.ChangeType;
import com.lachesis.puma.core.compare.model.ClassResult;
import com.lachesis.puma.core.compare.model.MethodResult;
import com.lachesis.puma.core.util.PumaPrintStream;
import org.fusesource.jansi.Ansi;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class CompareResultCollector {

    private static final String TAB = "├──";
    private static final String LAST_TAB = "└──";
    private static final String PIPE = "│";
    private final Map<String /* filename */, Map<ChangeType, List<ClassResult>>> classResultMap;

    private CompareResultCollector() {
        this.classResultMap = new LinkedHashMap<>();
    }

    public static CompareResultCollector newInstance() {
        return new CompareResultCollector();
    }

    public void addClassResult(ClassResult classResult) {
        ChangeType changeType = classResult.getChangeType();
        if (!ChangeType.UNCHANGED.equals(classResult.getChangeType())) {
            String fileName = classResult.getFilename();
            Map<ChangeType, List<ClassResult>> map = classResultMap.getOrDefault(fileName, new LinkedHashMap<>());
            List<ClassResult> list = map.getOrDefault(changeType, new ArrayList<>());
            list.add(classResult);
            map.put(changeType, list);
            classResultMap.put(fileName, map);
        }
    }

    public void printLog(boolean includeMethod) {
        classResultMap.forEach((path, map) -> {
            List<String> changePrintItems = new ArrayList<>();
            AtomicInteger packageSize = new AtomicInteger();
            map.forEach(((changeType, classResults) -> {
                changePrintItems.add(StrUtil.format("{}类文件{}个", changeType.getName(), classResults.size()));
                packageSize.addAndGet(classResults.size());
            }));
            // String changeInfo = StrUtil.join("|", changePrintItems);
            PumaPrintStream.logInfo(PumaPrintStream.formatStr(path, Ansi.Color.CYAN));
            // PumaStream.logInfo("比较统计:{}", changePrintInfo);
            AtomicInteger packageCount = new AtomicInteger(1);
            map.forEach((classChangeType, results) -> results.forEach(result -> {
                ChangeType changeType = result.getChangeType();
                String classChangeName = getChangeNameWithColor(changeType);
                String classPrefix = packageCount.getAndIncrement() == packageSize.get() ? LAST_TAB : TAB;
                PumaPrintStream.logInfo("{} [{}] {}", classPrefix, classChangeName, result.getEntryName());
                if (includeMethod) {
                    Map<ChangeType, List<MethodResult>> methodResultMap = result.getMethodResultMap();
                    AtomicInteger methodCount = new AtomicInteger(1);
                    int methodSize = result.getAllMethodSize();
                    methodResultMap.forEach((methodChangeType, methodResults) -> {
                        methodResults.forEach(methodResult -> {
                            String methodPrefix = methodCount.getAndIncrement() == methodSize ? LAST_TAB : TAB;
                            String methodBefore = LAST_TAB.equals(classPrefix) ? " " : PIPE;
                            String methodChangeName = getChangeNameWithColor(methodChangeType);
                            PumaPrintStream.logInfo("{} {} [{}] {}{}", methodBefore, methodPrefix,
                                methodChangeName, methodResult.getName(), methodResult.getDesc());
                        });
                    });
                }
            }));
        });
    }

    private String getChangeNameWithColor(ChangeType changeType) {
        Ansi.Color color;
        switch (changeType) {
            case ADD:
                color = Ansi.Color.GREEN;
                break;
            case DELETE:
                color = Ansi.Color.RED;
                break;
            case MODIFY:
                color = Ansi.Color.YELLOW;
                break;
            default:
                color = Ansi.Color.DEFAULT;
        }
        return PumaPrintStream.formatStr(changeType.getName(), color);
    }
}
