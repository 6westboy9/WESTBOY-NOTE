package com.lachesis.puma.core.compare.model;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.StrUtil;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipEntries {

    private final ZipFile zipFile;
    // 绝对路径
    // D:\IdeaProjects\mine\puma\data\source\WRMSSync.jar
    private final String absolutePath;
    // WRMSSync.jar
    private final String name;
    // WRMSSync
    private final String mainName;
    // "jar"
    private final String extName;
    private final File parentFile;
    // D:\IdeaProjects\mine\puma\data\source
    private final String parentAbsolutePath;
    // 解压文件目录：D:\IdeaProjects\mine\puma\data\source\WRMSSync
    private final String unzipDir;
    private final Map<String /* entryName */, ZipEntry> map;
    private final Map<String /* entryName */, ZipEntries> subEntriesMap;

    public ZipEntries(ZipFile zipFile) {
        File file = FileUtil.newFile(zipFile.getName());
        this.absolutePath = file.getAbsolutePath();
        this.zipFile = zipFile;
        this.name = file.getName();
        this.mainName = FileUtil.mainName(file);
        this.extName = FileUtil.extName(file);
        this.parentFile = file.getParentFile();
        this.parentAbsolutePath = parentFile.getPath();
        this.unzipDir = StrUtil.concat(true, parentAbsolutePath, FileUtil.FILE_SEPARATOR, mainName);
        this.map = new TreeMap<>(String::compareTo);
        this.subEntriesMap = new TreeMap<>(String::compareTo);
    }

    public void addEntry(ZipEntry entry) {
        map.put(entry.getName(), entry);
    }

    public void addSubEntriesMap(String zipEntryName, ZipEntries zipEntries) {
        this.subEntriesMap.put(zipEntryName, zipEntries);
    }

    public byte[] getContent(String entryName) throws IOException {
        ZipEntry zipEntry = map.get(entryName);
        InputStream inputStream = zipFile.getInputStream(zipEntry);
        return IoUtil.readBytes(inputStream, true);
    }

    public ZipFile getZipFile() {
        return zipFile;
    }

    public String getAbsolutePath() {
        return absolutePath;
    }

    public String getName() {
        return name;
    }

    public String getMainName() {
        return mainName;
    }

    public String getExtName() {
        return extName;
    }

    public File getParentFile() {
        return parentFile;
    }

    public String getParentAbsolutePath() {
        return parentAbsolutePath;
    }

    public String getUnzipDir() {
        return unzipDir;
    }

    public Map<String, ZipEntry> getMap() {
        return map;
    }

    public Map<String, ZipEntries> getSubEntriesMap() {
        return subEntriesMap;
    }

    public void close() {
        IoUtil.close(zipFile);
        subEntriesMap.forEach((name, entries) -> entries.close());
    }
}
