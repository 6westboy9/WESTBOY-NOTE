package com.lachesis.puma.core.compare.model;

import com.lachesis.puma.core.common.ChangeType;

public class MethodResult {
    private String name;
    private String desc;
    private ChangeType changeType;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public ChangeType getChangeType() {
        return changeType;
    }

    public void setChangeType(ChangeType changeType) {
        this.changeType = changeType;
    }
}
