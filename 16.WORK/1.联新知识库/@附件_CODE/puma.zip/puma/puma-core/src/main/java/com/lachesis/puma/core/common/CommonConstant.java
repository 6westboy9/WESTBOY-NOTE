package com.lachesis.puma.core.common;

public class CommonConstant {
    public static final String YES = "Y";
    public static final String NOE = "N";
    public static final String INPUT_SELECT_TEMPLATE = "{}:{}";
    public static final String INPUT_SELECT_SEPARATOR = "|";
}
