package com.lachesis.puma.core.compare.model;

import com.lachesis.puma.core.common.ChangeType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ClassResult {

    private final String filename;
    private final String fileAbsolutePath;
    private final String entryName;
    private final Map<ChangeType, List<MethodResult>> methodResultMap;
    private ChangeType changeType;

    private ClassResult(String filename, String fileAbsolutePath, String entryName, ChangeType changeType) {
        this.filename = filename;
        this.fileAbsolutePath = fileAbsolutePath;
        this.entryName = entryName;
        this.changeType = changeType;
        this.methodResultMap = new LinkedHashMap<>();
    }

    public static ClassResult newInstance(String filename, String absolutePath, String entryName, ChangeType type) {
        return new ClassResult(filename, absolutePath, entryName, type);
    }

    public String getFilename() {
        return filename;
    }

    public String getFileAbsolutePath() {
        return fileAbsolutePath;
    }

    public String getEntryName() {
        return entryName;
    }

    public Map<ChangeType, List<MethodResult>> getMethodResultMap() {
        return methodResultMap;
    }

    public ChangeType getChangeType() {
        return changeType;
    }

    public void setChangeType(ChangeType changeType) {
        this.changeType = changeType;
    }

    public void attachMethodResult(CompareMethod method, ChangeType changeType) {
        MethodResult methodResult = new MethodResult();
        methodResult.setName(method.getName());
        methodResult.setDesc(method.getDesc());
        methodResult.setChangeType(changeType);
        List<MethodResult> list = methodResultMap.getOrDefault(changeType, new ArrayList<>());
        list.add(methodResult);
        methodResultMap.put(changeType, list);
    }

    public int getAllMethodSize() {
        return methodResultMap.values().stream().map(List::size).reduce(0, Integer::sum);
    }
}
