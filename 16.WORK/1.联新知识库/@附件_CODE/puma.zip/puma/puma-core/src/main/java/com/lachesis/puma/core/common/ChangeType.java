package com.lachesis.puma.core.common;

public enum ChangeType {

    ADD("新增"),
    DELETE("删除"),
    MODIFY("修改"),
    UNCHANGED("相同");

    private final String name;

    ChangeType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
