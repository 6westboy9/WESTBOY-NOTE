package com.lachesis.puma.core.common.color;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.jline.utils.AttributedStyle;

@Getter
@AllArgsConstructor
public enum FontStyleEnum {

    DEFAULT(AttributedStyle.DEFAULT, ""),
    BOLD(AttributedStyle.BOLD, "\\u001B[1m");

    private final AttributedStyle windowsAttributedStyle;
    private final String linuxPrefix;
}
