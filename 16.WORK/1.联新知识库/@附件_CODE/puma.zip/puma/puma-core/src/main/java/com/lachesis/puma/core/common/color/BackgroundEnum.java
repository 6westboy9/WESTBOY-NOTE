package com.lachesis.puma.core.common.color;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.jline.utils.AttributedStyle;

@Getter
@AllArgsConstructor
public enum BackgroundEnum {

    BLACK(AttributedStyle.BLACK, "\\u001B[40m"),
    RED(AttributedStyle.RED, "\\u001B[41m"),
    GREEN(AttributedStyle.GREEN, "\\u001B[42m"),
    YELLOW(AttributedStyle.YELLOW, "\\u001B[43m"),
    MAGENTA(AttributedStyle.MAGENTA, "\\u001B[44m"),
    BLUE(AttributedStyle.BLUE, "\\u001B[45m"),
    CYAN(AttributedStyle.CYAN, "\\u001B[46m"),
    WHITE(AttributedStyle.WHITE, "\\u001B[47m");

    private final int windowsAttributedStyle;
    private final String linuxPrefix;
}
