package com.lachesis.puma.core.compare;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.core.common.ChangeType;
import com.lachesis.puma.core.compare.asm.CompareVisitor;
import com.lachesis.puma.core.compare.model.ClassResult;
import com.lachesis.puma.core.compare.model.CompareClass;
import com.lachesis.puma.core.compare.model.CompareMethod;
import com.lachesis.puma.core.compare.model.ZipEntries;
import com.lachesis.puma.core.util.PumaPrintStream;
import com.lachesis.puma.core.util.WildcardMatcher;
import org.objectweb.asm.ClassReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import static cn.hutool.core.io.FileUtil.FILE_SEPARATOR;

/**
 * 代码比较器
 */
public class Comparator {

    private final String sourceFilePath;
    private final String targetFilePath;
    private final CompareResultCollector collector;
    private String includeExpression = "*.class";
    private String excludeExpression = "package-info.class";
    private boolean includeMethod = true;

    private Comparator(String sourceFilePath, String targetFilePath) {
        this.sourceFilePath = sourceFilePath;
        this.targetFilePath = targetFilePath;
        this.collector = CompareResultCollector.newInstance();
    }

    public static Comparator newInstance(String sourceFilePath, String targetFilePath) {
        return new Comparator(sourceFilePath, targetFilePath);
    }

    public void setIncludeExpression(String includeExpression) {
        this.includeExpression = includeExpression;
    }

    public void setExcludeExpression(String excludeExpression) {
        this.excludeExpression = excludeExpression;
    }

    public void setIncludeMethod(boolean includeMethod) {
        this.includeMethod = includeMethod;
    }

    public CompareResultCollector getCollector() {
        return collector;
    }

    public void compare() {
        ZipEntries sourceEntries = null;
        ZipEntries targetEntries = null;
        try {
            ZipFile sourceFile = new ZipFile(sourceFilePath);
            ZipFile targetFile = new ZipFile(targetFilePath);
            sourceEntries = new ZipEntries(sourceFile);
            targetEntries = new ZipEntries(targetFile);

            clean(sourceEntries.getUnzipDir());
            clean(targetEntries.getUnzipDir());

            collectZipEntries(sourceEntries, true);
            collectZipEntries(targetEntries, true);

            compareEntries(sourceEntries, targetEntries);
            collector.printLog(includeMethod);
        } catch (IOException e) {
            throw new RuntimeException("比较失败", e);
        } finally {
            if (sourceEntries != null) {
                sourceEntries.close();
            }
            if (targetEntries != null) {
                targetEntries.close();
            }
        }
    }

    private void compareEntries(ZipEntries sourceEntries, ZipEntries targetEntries) throws IOException {
        Map<String, ZipEntry> sourceEntryMap = sourceEntries.getMap();
        Map<String, ZipEntry> targetEntryMap = targetEntries.getMap();
        Set<String> sourceEntryNames = CollUtil.newHashSet(sourceEntryMap.keySet());
        Set<String> targetEntryNames = CollUtil.newHashSet(targetEntryMap.keySet());

        String targetFilename = targetEntries.getName();
        String targetAbsolutePath = targetEntries.getAbsolutePath();
        for (String targetEntryName : targetEntryNames) {
            if (sourceEntryNames.contains(targetEntryName)) {
                byte[] sourceBytes = sourceEntries.getContent(targetEntryName);
                byte[] targetBytes = targetEntries.getContent(targetEntryName);
                // 1.比较
                ClassResult classResult = handleCompare(targetFilename, targetAbsolutePath, targetEntryName, sourceBytes, targetBytes);
                collector.addClassResult(classResult);
                sourceEntryNames.remove(targetEntryName);
            } else {
                byte[] targetBytes = targetEntries.getContent(targetEntryName);
                // 2.删除
                ClassResult classResult = generateResult(targetFilename, targetAbsolutePath, targetEntryName, targetBytes, ChangeType.DELETE);
                collector.addClassResult(classResult);
            }
        }

        String sourceFilename = sourceEntries.getName();
        String sourceAbsolutePath = sourceEntries.getAbsolutePath();
        for (String sourceEntryName : sourceEntryNames) {
            byte[] sourceBytes = sourceEntries.getContent(sourceEntryName);
            // 3.新增
            ClassResult classResult = generateResult(sourceFilename, sourceAbsolutePath, sourceEntryName, sourceBytes, ChangeType.ADD);
            collector.addClassResult(classResult);
        }

        Map<String, ZipEntries> sourceSubEntriesMap = sourceEntries.getSubEntriesMap();
        Map<String, ZipEntries> targetSubEntriesMap = targetEntries.getSubEntriesMap();
        for (Map.Entry<String, ZipEntries> entry : targetSubEntriesMap.entrySet()) {
            String targetSubEntryName = entry.getKey();
            ZipEntries targetSubZipEntries = entry.getValue();
            if (sourceSubEntriesMap.containsKey(targetSubEntryName)) {
                ZipEntries sourceSubZipEntries = sourceSubEntriesMap.get(targetSubEntryName);
                compareEntries(sourceSubZipEntries, targetSubZipEntries);
            } else {
                PumaPrintStream.logInfo("源文件存在但目标文件不存在:{}", targetSubEntryName);
            }
        }
    }

    private ClassResult generateResult(String filename, String fileAbsolutePath, String entryName, byte[] bytes, ChangeType changeType) {
        CompareClass compareClass = buildClass(bytes);
        Map<String, CompareMethod> compareMethodMap = compareClass.getMethodMap();
        ClassResult classResult = ClassResult.newInstance(filename, fileAbsolutePath, entryName, changeType);
        compareMethodMap.forEach((id, sourceMethod) -> classResult.attachMethodResult(sourceMethod, changeType));
        return classResult;
    }

    private ClassResult handleCompare(String filename, String fileAbsolutePath, String entryName, byte[] sourceBytes, byte[] targetBytes) {
        // TODO 后续优化工作：先通过JGit比较缩小比较文件范围，再进行字节码比较得到详细差异
        if (Arrays.equals(sourceBytes, targetBytes)) {
            return ClassResult.newInstance(filename, fileAbsolutePath, entryName, ChangeType.UNCHANGED);
        }
        CompareClass sourceClass = buildClass(sourceBytes);
        CompareClass targetClass = buildClass(targetBytes);
        Map<String, CompareMethod> sourceMethodMap = sourceClass.getMethodMap();
        Map<String, CompareMethod> targetMethodMap = targetClass.getMethodMap();
        ClassResult classResult = ClassResult.newInstance(filename, fileAbsolutePath, entryName, ChangeType.MODIFY);
        AtomicBoolean change = new AtomicBoolean(false);
        targetMethodMap.forEach((id, targetMethod) -> {
            try {
                if (sourceMethodMap.containsKey(id)) {
                    CompareMethod sourceMethod = sourceMethodMap.get(id);
                    // 当是abstract/native方法时，body为null
                    if (targetMethod.getBody() != null && !sourceMethod.getBody().equals(targetMethod.getBody())) {
                        classResult.attachMethodResult(targetMethod, ChangeType.MODIFY);
                        change.compareAndSet(false, true);
                    }
                    sourceMethodMap.remove(id);
                } else {
                    classResult.attachMethodResult(targetMethod, ChangeType.DELETE);
                    change.compareAndSet(false, true);
                }
            } catch (Exception e) {
                PumaPrintStream.logError(e, "比较异常:{}#{}", entryName, id);
                throw e;
            }
        });

        // TODO 很奇怪，源码一样，字节码长度一样，并且自己码指令也一样，但是字节码数组中存在不一样的情况，暂时先这么处理~
        if (!change.get() && MapUtil.isEmpty(sourceMethodMap)) {
            classResult.setChangeType(ChangeType.UNCHANGED);
        }
        sourceMethodMap.forEach((id, sourceMethod) -> classResult.attachMethodResult(sourceMethod, ChangeType.ADD));
        return classResult;
    }

    private CompareClass buildClass(byte[] bytes) {
        ClassReader reader = new ClassReader(bytes);
        CompareVisitor visitor = new CompareVisitor();
        reader.accept(visitor, ClassReader.SKIP_FRAMES);
        return visitor.getCompareClass();
    }

    private void collectZipEntries(ZipEntries zipEntries, boolean unzipAll) throws IOException {
        ZipFile zipFile = zipEntries.getZipFile();
        Enumeration<? extends ZipEntry> entries = zipFile.entries();
        WildcardMatcher includeMatcher = new WildcardMatcher(includeExpression);
        WildcardMatcher excludeMatcher = new WildcardMatcher(excludeExpression);
        ZipEntry zipEntry;
        String unzipDir = zipEntries.getUnzipDir();
        while (entries.hasMoreElements()) {
            zipEntry = entries.nextElement();
            String zipEntryName = zipEntry.getName();
            String absolutePath = getFilePath(unzipDir, zipEntryName);
            if (zipEntry.isDirectory()) {
                if (unzipAll) {
                    FileUtil.mkdir(absolutePath);
                }
                continue;
            }

            if (unzipAll) {
                touch(zipFile, zipEntry, absolutePath);
            }

            if (!includeMatcher.matches(zipEntryName)) {
                continue;
            }

            if (excludeMatcher.matches(zipEntryName)) {
                continue;
            }

            if (zipEntryName.endsWith(".jar")) {
                if (!unzipAll) {
                    touch(zipFile, zipEntry, absolutePath);
                }
                ZipFile subZipFile = new ZipFile(absolutePath);
                ZipEntries subZipEntries = new ZipEntries(subZipFile);
                collectZipEntries(subZipEntries, unzipAll);
                zipEntries.addSubEntriesMap(zipEntryName, subZipEntries);
                continue;
            }
            zipEntries.addEntry(zipEntry);
        }
    }

    private void clean(String unzipDir) {
        if (FileUtil.del(unzipDir)) {
            PumaPrintStream.logInfo("清空历史数据: {}", unzipDir);
        }
    }

    private void touch(ZipFile zipFile, ZipEntry zipEntry, String path) throws IOException {
        if (!FileUtil.exist(path)) {
            FileUtil.touch(path);
        }
        try (OutputStream os = Files.newOutputStream(Paths.get(path));
             InputStream is = zipFile.getInputStream(zipEntry)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
        }
    }

    private String getFilePath(String parentPath, String entryName) {
        return StrUtil.concat(true, parentPath, FILE_SEPARATOR, entryName.replace("/", FILE_SEPARATOR));
    }

    private static String toVMName(final String srcName) {
        return srcName.replace('.', '/');
    }
}
