package com.lachesis.puma.core.compare.asm;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.map.MapUtil;
import com.lachesis.puma.core.compare.model.CompareClass;
import com.lachesis.puma.core.compare.model.CompareMethod;
import org.objectweb.asm.*;
import org.objectweb.asm.util.Printer;
import org.objectweb.asm.util.Textifier;

import java.util.Collection;
import java.util.Map;

public class CompareVisitor extends ClassVisitor {

    private final Printer printer;
    private CompareClass compareClass;

    public CompareVisitor() {
        super(Opcodes.ASM9, null);
        this.printer = new Textifier();
    }

    public CompareClass getCompareClass() {
        return compareClass;
    }

    @Override
    public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
        printer.visit(version, access, name, signature, superName, interfaces);
        compareClass = new CompareClass();
        compareClass.setVersion(version);
        compareClass.setAccess(access);
        compareClass.setName(name);
        super.visit(version, access, name, signature, superName, interfaces);
    }

    @Override
    public void visitSource(String source, String debug) {
        compareClass.setSource(source);
        super.visitSource(source, debug);
    }

    @Override
    public void visitOuterClass(String owner, String name, String desc) {
        // printer.visitOuterClass(owner, name, desc);
        super.visitOuterClass(owner, name, desc);
    }


    @Override
    public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
        return super.visitAnnotation(descriptor, visible);
    }

    @Override
    public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
        return super.visitTypeAnnotation(typeRef, typePath, descriptor, visible);
    }

    @Override
    public void visitAttribute(Attribute attribute) {
        // printer.visitClassAttribute(attribute);
        super.visitAttribute(attribute);
    }

    @Override
    public void visitInnerClass(String name, String outerName, String innerName, int access) {
        // printer.visitInnerClass(name, outerName, innerName, access);
        super.visitInnerClass(name, outerName, innerName, access);
    }

    @Override
    public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
        // Printer printer = this.printer.visitField(access, name, descriptor, signature, value);
        return super.visitField(access, name, descriptor, signature, value);
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        Printer p = printer.visitMethod(access, name, descriptor, signature, exceptions);
        MethodVisitor mv = cv == null ? null : cv.visitMethod(access, name, descriptor, signature, exceptions);
        CompareMethod compareMethod = new CompareMethod();
        compareMethod.setAccess(access);
        compareMethod.setName(name);
        compareMethod.setDesc(descriptor);
        // 初始化时text为空，传递的是List对象，后续在CompareAdapter中会进行text元素添加操作
        compareMethod.setText(p.getText());
        compareClass.addMethod(compareMethod);
        return new CompareAdapter(mv, p);
    }

    @Override
    public void visitEnd() {
        printer.visitClassEnd();
        super.visitEnd();
        setMethodBody();
    }

    private void setMethodBody() {
        Map<String, CompareMethod> methodMap = compareClass.getMethodMap();
        if (MapUtil.isEmpty(methodMap)) {
            return;
        }
        Collection<CompareMethod> methods = methodMap.values();
        methods.forEach(method -> {
            if (CollUtil.isEmpty(method.getText())) {
                return;
            }
            StringBuilder sb = new StringBuilder();
            method.getText().forEach(sb::append);
            method.setBody(sb.toString());
        });
    }
}
