package com.lachesis.puma.core.util;

import cn.hutool.core.util.StrUtil;

public class CommonUtil {

    public static String getProjectName(String gitUrl) {
        return StrUtil.sub(gitUrl, gitUrl.lastIndexOf("/") + 1, gitUrl.indexOf(".git"));
    }

}
