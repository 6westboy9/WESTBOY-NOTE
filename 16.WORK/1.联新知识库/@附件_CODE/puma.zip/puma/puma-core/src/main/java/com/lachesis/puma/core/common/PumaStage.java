package com.lachesis.puma.core.common;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.lachesis.puma.core.common.CommonConstant.INPUT_SELECT_SEPARATOR;
import static com.lachesis.puma.core.common.CommonConstant.INPUT_SELECT_TEMPLATE;

@Getter
@AllArgsConstructor
public enum PumaStage {

    CLONE("1", "克隆"),
    BUILD("2", "构建"),
    COMPARE("3", "比较"),
    EXIST("4", "结束"),
    CLEAR_SESSION("5", "清空会话");

    private final String order;
    private final String desc;

    public static PumaStage of(String order) {
        return Arrays.stream(PumaStage.values())
            .filter(step -> step.getOrder().equalsIgnoreCase(order))
            .findFirst()
            .orElse(null);
    }

    public static String getPrompt() {
        List<String> list = Arrays.stream(PumaStage.values())
            .map(step -> StrUtil.format(INPUT_SELECT_TEMPLATE, step.getOrder(), step.getDesc()))
            .collect(Collectors.toList());
        return CollUtil.join(list, INPUT_SELECT_SEPARATOR);
    }
}
