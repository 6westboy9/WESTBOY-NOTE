package com.lachesis.puma.core.common.color;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.jline.utils.AttributedStyle;

@Getter
@AllArgsConstructor
public enum FontColorEnum {

    BLACK(AttributedStyle.BLACK, "\u001B[30m"),
    RED(AttributedStyle.RED, "\u001B[31m"),
    GREEN(AttributedStyle.GREEN, "\u001B[32m"),
    YELLOW(AttributedStyle.YELLOW, "\u001B[33m"),
    MAGENTA(AttributedStyle.MAGENTA, "\u001B[34m"),
    BLUE(AttributedStyle.BLUE, "\u001B[35m"),
    CYAN(AttributedStyle.CYAN, "\u001B[36m"),
    WHITE(AttributedStyle.WHITE, "\u001B[37m");

    private final int windowsAttributedStyle;
    private final String linuxColor;
}
