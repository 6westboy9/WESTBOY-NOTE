package com.lachesis.puma.core.builder;

import com.lachesis.puma.core.util.PumaPrintStream;
import org.apache.maven.shared.invoker.InvocationOutputHandler;

import java.util.concurrent.atomic.AtomicBoolean;

public class ConsoleOutputHandler implements InvocationOutputHandler {

    private final AtomicBoolean mark = new AtomicBoolean(false);

    public void consumeLine(String line) {
        if (line == null) {
            PumaPrintStream.logInfo("MAVEN ");
        } else {
            PumaPrintStream.logInfo("MAVEN " + line);
            if (!mark.get() && line.indexOf("[ERROR]") == 0) {
                mark.set(true);
            }
        }
    }

    public boolean hasMarked() {
        return mark.get();
    }
}
