package com.lachesis.puma.core.util;

public class ClassHelper {

    /**
     * 将类文件的路径名转换为类的全限定名
     *
     * @param classFilePath class文件路径名
     * @return 类的全限定名
     */
    public static String getClassname(String classFilePath) {
        // if (classFilePath.endsWith(".class")) {
        //     classFilePath = classFilePath.substring(0, classFilePath.length() - 6);
        // }
        // return classFilePath.replace('/', '.');
        return classFilePath;
    }

}
