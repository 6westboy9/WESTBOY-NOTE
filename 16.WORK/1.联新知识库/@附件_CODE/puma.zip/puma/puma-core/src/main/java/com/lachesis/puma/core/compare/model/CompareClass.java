package com.lachesis.puma.core.compare.model;

import cn.hutool.json.JSONUtil;
import com.lachesis.puma.core.util.PumaPrintStream;

import java.util.LinkedHashMap;
import java.util.Map;

public class CompareClass {

    private int version;
    private int access;
    private String name;
    private String source;
    private final Map<String /* methodName + methodDesc */, CompareMethod> methodMap = new LinkedHashMap<>();

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getAccess() {
        return access;
    }

    public void setAccess(int access) {
        this.access = access;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void addMethod(CompareMethod method) {
        String methodId = method.getName() + method.getDesc();
        if (methodMap.containsKey(methodId)) {
            // 正常情况下不会存在重复方法
            CompareMethod oldMethod = methodMap.get(methodId);
            PumaPrintStream.logInfo("相同[{}]方法: {}", oldMethod.getName(), JSONUtil.toJsonStr(oldMethod));
            PumaPrintStream.logInfo("相同[{}]方法: {}", method.getName(), JSONUtil.toJsonStr(method));
        }
        methodMap.put(methodId, method);
    }

    public Map<String, CompareMethod> getMethodMap() {
        return methodMap;
    }
}
