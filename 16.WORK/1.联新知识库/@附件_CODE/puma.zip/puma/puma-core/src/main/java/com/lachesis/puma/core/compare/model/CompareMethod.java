package com.lachesis.puma.core.compare.model;

import java.util.List;


public class CompareMethod {
    /**
     * 访问标识
     */
    private int access;
    /**
     * 方法名
     */
    private String name;
    /**
     * 方法描述符
     */
    private String desc;
    /**
     * 方法体指令字符串
     */
    private String body;
    /**
     * 方法体指令数组
     */
    private List<Object> text;

    public int getAccess() {
        return access;
    }

    public void setAccess(int access) {
        this.access = access;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public List<Object> getText() {
        return text;
    }

    public void setText(List<Object> text) {
        this.text = text;
    }
}
