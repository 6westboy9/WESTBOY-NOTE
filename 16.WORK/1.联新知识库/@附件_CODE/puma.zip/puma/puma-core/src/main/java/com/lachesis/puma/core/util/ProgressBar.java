package com.lachesis.puma.core.util;

import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

public class ProgressBar {

    private final int total;
    private StringBuilder stringBuilder = new StringBuilder();
    private static final char BACK_GROUND = '░';
    private static final char FRONT_GROUND = '█';

    public ProgressBar(int total) {
        this.total = total;
        Stream.generate(() -> BACK_GROUND).limit(total).forEach(stringBuilder::append);
    }

    public void step(int i) {
        stringBuilder.replace(i, i + 1, String.valueOf(FRONT_GROUND));
        String bar = "\r" + stringBuilder;
        String percent = " " + (1 + i) + "%";
        System.out.print(ProgressBar.ColorEnum.WHITE.getValue() + bar + percent);
    }

    public static void main(String[] args) throws InterruptedException {
        ProgressBar pb = new ProgressBar(10);
        for (int i = 0; i < 10; i++) {
            pb.step(i);
            // 防止打印太快，方便观察
            TimeUnit.SECONDS.sleep(1);
        }
    }


    /**
     * 颜色枚举
     */
    enum ColorEnum {

        /**
         * 白色
         */
        WHITE("\33[0m"),

        /**
         * 红色
         */
        RED("\33[1m\33[31m"),

        /**
         * 绿色
         */
        GREEN("\33[1m\33[32m"),

        /**
         * 黄色
         */
        YELLOW("\33[1m\33[33m"),

        /**
         * 蓝色
         */
        BLUE("\33[1m\33[34m"),

        /**
         * 粉色
         */
        PINK("\33[1m\33[35m"),

        /**
         * 青色
         */
        CYAN("\33[1m\33[36m");

        /**
         * 颜色值
         */
        private String value;

        ColorEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

    }
}
