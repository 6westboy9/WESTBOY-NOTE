package com.lachesis.puma.core.repo;

import cn.hutool.core.util.StrUtil;
import com.lachesis.puma.core.util.PumaPrintStream;
import org.eclipse.jgit.lib.BatchingProgressMonitor;

public class ProgressMonitor extends BatchingProgressMonitor {

    @Override
    protected void onUpdate(String taskName, int workCurr) {
        StringBuilder builder = new StringBuilder();
        format(builder, taskName, workCurr);
        write(builder);
    }

    @Override
    protected void onEndTask(String taskName, int workCurr) {
        StringBuilder builder = new StringBuilder();
        format(builder, taskName, workCurr);
        builder.append("\n");
        write(builder);
    }

    private void format(StringBuilder builder, String taskName, int workCurr) {
        builder.append("\r");
        builder.append(PumaPrintStream.OUTPUT_PREFIX + " GIT ");
        builder.append(StrUtil.upperFirst(taskName));
        builder.append(": ");
        while (builder.length() < 25) {
            builder.append(' ');
        }
        builder.append(workCurr);
    }

    @Override
    protected void onUpdate(String taskName, int cmp, int totalWork, int pcnt) {
        StringBuilder s = new StringBuilder();
        format(s, taskName, cmp, totalWork, pcnt);
        write(s);
    }

    @Override
    protected void onEndTask(String taskName, int cmp, int totalWork, int pcnt) {
        StringBuilder buffer = new StringBuilder();
        format(buffer, taskName, cmp, totalWork, pcnt);
        buffer.append("\n");
        write(buffer);
    }

    private void format(StringBuilder builder, String taskName, int cmp, int totalWork, int pcnt) {
        builder.append("\r");
        builder.append(PumaPrintStream.OUTPUT_PREFIX + " GIT ");
        builder.append(StrUtil.upperFirst(taskName));
        builder.append(": ");
        while (builder.length() < 25) {
            builder.append(' ');
        }

        String endStr = String.valueOf(totalWork);
        StringBuilder curStr = new StringBuilder(String.valueOf(cmp));
        while (curStr.length() < endStr.length()) {
            curStr.insert(0, " ");
        }
        if (pcnt < 100) {
            builder.append(' ');
        }
        if (pcnt < 10) {
            builder.append(' ');
        }
        builder.append(pcnt);
        builder.append("% (");
        builder.append(curStr);
        builder.append("/");
        builder.append(endStr);
        builder.append(")");
    }

    private void write(StringBuilder builder) {
        PumaPrintStream.outPrint.print(builder.toString());
    }
}
