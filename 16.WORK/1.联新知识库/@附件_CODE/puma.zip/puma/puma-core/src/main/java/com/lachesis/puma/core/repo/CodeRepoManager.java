package com.lachesis.puma.core.repo;

import cn.hutool.core.io.FileUtil;
import com.lachesis.puma.core.common.PumaStage;
import com.lachesis.puma.core.util.CommonUtil;
import com.lachesis.puma.core.util.PumaPrintStream;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Repository;

import java.io.File;

@Slf4j
public class CodeRepoManager {

    private final String sshPriKeyPath;
    private final String gitUrl;

    private CodeRepoManager(String gitUrl, String sshPriKeyPath) {
        this.gitUrl = gitUrl;
        this.sshPriKeyPath = sshPriKeyPath;
    }

    public static CodeRepoManager newInstance(String gitUrl, String sshPriKeyPath) {
        return new CodeRepoManager(gitUrl, sshPriKeyPath);
    }

    public void clone(String branch, String dir) throws GitAPIException {
        mkdirDirIfNotExists(dir);
        String projectPath = dir + FileUtil.FILE_SEPARATOR + CommonUtil.getProjectName(gitUrl);
        deleteHistoryData(projectPath);
        CloneCommand cloneCommand = Git.cloneRepository()
            .setURI(gitUrl)
            .setBranch(branch)
            .setDirectory(new File(projectPath))
            .setProgressMonitor(new ProgressMonitor());
        long start = System.currentTimeMillis();
        long consume;
        Repository repository;
        PumaPrintStream.logInfo("{}分支: {}", PumaStage.CLONE.getDesc(), branch);
        try (Git git = cloneCommand.call()) {
            consume = System.currentTimeMillis() - start;
            repository = git.getRepository();
        }
        PumaPrintStream.logInfo("{}完成: {}ms",  PumaStage.CLONE.getDesc(), consume);
    }

    // public void diff(String newRevstr, String oldRevstr, String dir) {
    //     String projectPath = dir + FileUtil.FILE_SEPARATOR + CommonUtil.parseProjectName(gitUrl);
    //     try {
    //         Repository repository;
    //         List<DiffEntry> diffEntries;
    //         try (Git git = Git.open(FileUtil.newFile(projectPath))) {
    //             repository = git.getRepository();
    //             diffEntries = git.diff()
    //                 .setNewTree(prepareTreeParser(repository, repository.resolve(newRevstr)))
    //                 .setOldTree(prepareTreeParser(repository, repository.resolve(oldRevstr)))
    //                 .call();
    //         }
    //         for (DiffEntry diffEntry : diffEntries) {
    //             try (ByteArrayOutputStream out = new ByteArrayOutputStream();
    //                  DiffFormatter diffFormatter = new DiffFormatter(out)) {
    //
    //                 diffFormatter.setRepository(repository);
    //                 diffFormatter.format(diffEntry);
    //
    //                 DiffEntry.ChangeType changeType = diffEntry.getChangeType();
    //
    //                 String diffContent = out.toString("UTF-8");
    //                 // 打印差异代码
    //                 System.out.println("Diff for file: " + diffEntry.getNewPath());
    //                 System.out.println(diffContent);
    //
    //                 if (!diffEntry.getNewPath().endsWith(".java")) {
    //                     continue;
    //                 }
    //
    //                 // CompilationUnit compilationUnit = StaticJavaParser.parse(diffContent);
    //                 String absolutePath = projectPath + File.separator + diffEntry.getNewPath().replace("/", File.separator);
    //                 System.out.println("类名: " + diffEntry.getNewPath());
    //                 File file = FileUtil.newFile(absolutePath);
    //                 CompilationUnit cu = StaticJavaParser.parse(file);
    //                 cu.findAll(MethodDeclaration.class)
    //                     .forEach(methodDeclaration -> {
    //                         String methodName = methodDeclaration.getNameAsString();
    //                         String packageName = cu.getPackageDeclaration()
    //                             .map(NodeWithName::getNameAsString)
    //                             .orElse("");
    //                         // 打印类名和包名
    //                         System.out.println("Package: " + packageName);
    //                         // 打印方法
    //                         System.out.println("methodName: " + methodName);
    //                         // 进一步分析类的其他信息
    //                         // 例如，类的字段、方法等
    //                     });
    //             }
    //         }
    //     } catch (Exception e) {
    //         ConsoleUtil.error(e, "代码比较异常");
    //     }
    // }

    // private static AbstractTreeIterator prepareTreeParser(Repository repository, ObjectId objectId) throws IOException {
    //     try (RevWalk walk = new RevWalk(repository)) {
    //         RevCommit commit = walk.parseCommit(objectId);
    //         ObjectId treeId = commit.getTree().getId();
    //         try (ObjectReader reader = repository.newObjectReader()) {
    //             return new CanonicalTreeParser(null, reader, treeId);
    //         }
    //     }
    // }

    private void mkdirDirIfNotExists(String dir) {
        boolean exist = FileUtil.exist(dir);
        if (!exist) {
            FileUtil.mkdir(dir);
            PumaPrintStream.logInfo("分支目录: {}", dir);
        }
    }

    private void deleteHistoryData(String projectPath) {
        boolean exist = FileUtil.exist(projectPath);
        if (exist) {
            FileUtil.del(projectPath);
            PumaPrintStream.logInfo("删除历史数据: {}", projectPath);
        }
    }

    public boolean checkGitUrl() {
        // TODO 暂时先返回true
        return true;
    }

    // private String calculate(long milliseconds) {
    //     // 将毫秒转换为秒
    //     long totalSeconds = milliseconds / 1000;
    //     // 计算小时、分钟、秒和毫秒
    //     long hours = totalSeconds / 3600;
    //     long minutes = (totalSeconds % 3600) / 60;
    //     long seconds = totalSeconds % 60;
    //     long remainingMilliseconds = milliseconds % 1000;
    //     return StrUtil.format("{}:{}:{}.{}", hours, minutes, seconds, remainingMilliseconds);
    // }

}
