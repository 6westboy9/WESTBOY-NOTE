package com.lachesis.puma.core.util;

import cn.hutool.core.util.StrUtil;
import org.fusesource.jansi.Ansi;

import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public class PumaPrintStream {

    public static final String INPUT_PREFIX = formatStr(">>>", Ansi.Color.YELLOW);
    public static final String OUTPUT_PREFIX = formatStr(">>>", Ansi.Color.BLUE);
    public static final String charset = "utf-8";
    public static final InputStream in = System.in;
    public static final PrintStream out = System.out;
    public static final PrintStream err = System.out;

    public static final PrintStream outPrint;
    public static final PrintStream errPrint;
    private static final boolean autoFlush = true;
    public static PrintWriter printWriter;

    static {
        try {
            outPrint = new PrintStream(out, autoFlush, charset);
            errPrint = new PrintStream(err, autoFlush, charset);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public static void setPrintWriter(PrintWriter printWriter) {
        PumaPrintStream.printWriter = printWriter;
    }

    public static void logInfo(String msgTemplate, Object... values) {
        outPrint.println(setPrefix(StrUtil.format(msgTemplate, values)));
    }

    public static void logWarn(String msgTemplate, Object... values) {
        outPrint.println(setPrefix(StrUtil.format(msgTemplate, values)));
    }

    public static void logError(String msgTemplate, Object... values) {
        outPrint.println(setPrefix(StrUtil.format(msgTemplate, values)));
    }

    public static void logError(Exception e, String msgTemplate, Object... values) {
        outPrint.println(setPrefix(StrUtil.format(msgTemplate, values)));
        if (e != null) {
            e.printStackTrace(outPrint);
        }
    }

    private static String setPrefix(String msgTemplate) {
        return StrUtil.format("{} {}", OUTPUT_PREFIX, msgTemplate);
    }

    public static String formatStr(String content, Ansi.Color colour) {
        return Ansi.ansi().fg(colour)
            .a(content)
            .bold()
            .reset()
            .toString();
    }
}
