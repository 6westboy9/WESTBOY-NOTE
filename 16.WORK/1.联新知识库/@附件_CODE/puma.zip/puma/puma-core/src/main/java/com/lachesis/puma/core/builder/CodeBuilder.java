package com.lachesis.puma.core.builder;

import cn.hutool.core.io.FileUtil;
import com.lachesis.puma.core.common.PumaStage;
import com.lachesis.puma.core.util.PumaPrintStream;
import org.apache.maven.shared.invoker.*;

import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;

public class CodeBuilder {

    private final String javaHomePath;
    private final String mavenPath;
    private final ConsoleOutputHandler outputHandler;
    private final ConsoleErrorHandler errorHandler;

    private CodeBuilder(String javaHomePath, String mavenPath) {
        this.javaHomePath = javaHomePath;
        this.mavenPath = mavenPath;
        this.outputHandler = new ConsoleOutputHandler();
        this.errorHandler = new ConsoleErrorHandler();
    }

    public static CodeBuilder newInstance(String javaHomePath, String mavenPath) {
        return new CodeBuilder(javaHomePath, mavenPath);
    }

    public void build(String path, String mavenOrder) throws Exception {
        PumaPrintStream.logInfo("{}目录: {}", PumaStage.BUILD.getDesc(), path);
        PumaPrintStream.logInfo("{}命令: {}", PumaStage.BUILD.getDesc(), mavenOrder);
        long begin = System.currentTimeMillis();
        String pomPath = checkAndGetPomPath(path);
        PumaPrintStream.logInfo("{}POM文件路径: {}", PumaStage.BUILD.getDesc(), pomPath);

        InvocationRequest request = new DefaultInvocationRequest();
        request.setBatchMode(true);
        request.setJavaHome(FileUtil.file(javaHomePath));
        request.setPomFile(FileUtil.file(pomPath));
        request.setGoals(Collections.singletonList(mavenOrder));

        Invoker invoker = new DefaultInvoker();
        invoker.setMavenHome(FileUtil.file(mavenPath));
        invoker.setOutputHandler(outputHandler);
        invoker.setErrorHandler(errorHandler);
        InvocationResult invocationResult = invoker.execute(request);
        if (invocationResult.getExecutionException() != null) {
            PumaPrintStream.logError(invocationResult.getExecutionException(), "构建异常");
        }
        if (outputHandler.hasMarked() || errorHandler.hasMarked()) {
            PumaPrintStream.logError("{}失败: {}ms", PumaStage.BUILD.getDesc(), (System.currentTimeMillis() - begin));
        } else {
            PumaPrintStream.logInfo("{}完成: {}ms", PumaStage.BUILD.getDesc(), (System.currentTimeMillis() - begin));
        }
    }

    public boolean isSuccess() {
        return errorHandler.hasMarked();
    }

    private String checkAndGetPomPath(String projectPath) throws FileNotFoundException {
        String pomPath = projectPath + FileUtil.FILE_SEPARATOR + "pom.xml";
        if (!FileUtil.exist(pomPath)) {
            throw new FileNotFoundException(pomPath);
        }
        return pomPath;
    }
}
