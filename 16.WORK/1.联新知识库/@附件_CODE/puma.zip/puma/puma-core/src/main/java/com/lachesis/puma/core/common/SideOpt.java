package com.lachesis.puma.core.common;

import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.lachesis.puma.core.common.CommonConstant.INPUT_SELECT_SEPARATOR;
import static com.lachesis.puma.core.common.CommonConstant.INPUT_SELECT_TEMPLATE;

@Getter
@AllArgsConstructor
public enum SideOpt {

    SOURCE("1", "源"),
    TARGET("2", "目标"),
    RETURN("3", "返回");

    private final String code;
    private final String desc;

    public static String getPrompt() {
        List<String> list = Arrays.stream(SideOpt.values())
            .map(sideOpt -> StrUtil.format(INPUT_SELECT_TEMPLATE, sideOpt.getCode(), sideOpt.getDesc()))
            .collect(Collectors.toList());
        return StrUtil.join(INPUT_SELECT_SEPARATOR, list);
    }

    public static SideOpt ofCode(String code) {
        return Arrays.stream(SideOpt.values())
            .filter(sideOpt -> String.valueOf(sideOpt.getCode()).equals(code))
            .findFirst()
            .orElse(null);

    }

    public String getLowerCaseName() {
        return name().toLowerCase();
    }
}
