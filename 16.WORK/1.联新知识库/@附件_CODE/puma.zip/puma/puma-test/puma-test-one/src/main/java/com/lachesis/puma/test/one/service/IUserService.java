package com.lachesis.puma.test.one.service;

import com.lachesis.puma.test.one.domain.User;

public interface IUserService {

    User selectById(Integer id);

    boolean insert(User user);

    boolean update(User user);

    boolean deleteById(Integer id);

}
