package com.lachesis.puma.test.one;

import cn.hutool.extra.spring.SpringUtil;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.time.Duration;

@Slf4j
@MapperScan(basePackages = "com.lachesis.puma.test.one.mapper")
@SpringBootApplication
public class PumaTestOneApplication implements ApplicationRunner {

    public static void main(String[] args) {
        SpringApplication.run(PumaTestOneApplication.class);
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        String datasourceType = SpringUtil.getProperty("spring.datasource.type");
        String driverClassName = SpringUtil.getProperty("spring.datasource.driver-class-name");
        log.info("datasourceType:{}", datasourceType);
        log.info("driverClassName:{}", driverClassName);
    }
}
