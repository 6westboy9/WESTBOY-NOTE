package com.lachesis.puma.test.one.controller;

import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum SyncLife {

    /**
     * 推送时
     */
    PARSE("数据解析"),
    /**
     * 拉取时
     */
    PULL("拉取数据"),

    /**
     * 推送时：数据解析 -> 字段映射 -> 参数填充 -> 对象转换 -> 对象存储<br>
     * 拉取时：拉取数据 -> 数据解析 -> 字段映射 -> 参数填充 -> 对象转换 -> 对象存储
     */
    MAPPING("字段映射"),
    FILL("参数填充"),
    CONVERT("对象转换"),
    STORE("对象存储");

    private final String desc;

    public String start() {
        return start(null);
    }

    public String start(String template, Object... params) {
        return getString("开始", template, params);
    }

    public String finish() {
        return finish(null);
    }

    public String finish(String template, Object... params) {
        return getString("结束", template, params);
    }

    public String throwExp() {
        return throwExp(null);
    }

    public String throwExp(String template, Object... params) {
        return getString("异常", template, params);
    }

    private String getString(String tag, String template, Object[] params) {
        String tpl = StrUtil.format("- {}_{}", desc, tag);
        if (StrUtil.isNotBlank(template)) {
            tpl = StrUtil.format("{} {}", tpl, template);
        }
        return StrUtil.format(tpl, params);
    }

}
