package com.lachesis.puma.test.one.controller;

public class UserHelper {

    public void doHelp() {
        System.out.println("哈哈哈");
    }

}
