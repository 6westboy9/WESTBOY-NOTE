package com.lachesis.puma.test.one.controller;

import com.lachesis.puma.test.one.domain.User;
import com.lachesis.puma.test.one.service.IUserService;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

@Slf4j
public class GerUserRunnable implements Runnable {

    private final int id;
    private final IUserService userService;

    public GerUserRunnable(int id, IUserService userService) {
        this.id = id;
        this.userService = userService;
    }

    @Override
    public void run() {
        try {
            int i = 3;
            log.info("等待{}秒后执行...", i);
            TimeUnit.SECONDS.sleep(i);
            User user1 = userService.selectById(id);
            log.info("执行完成");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
