package com.lachesis.puma.test.one.domain;

public class ResultBuilder {

    private static final int success = 0;
    private static final int fail = -1;

    public static <T> Result<T> success(T data) {
        Result<T> result = new Result<>();
        result.setCode(success);
        result.setMessage("success");
        result.setData(data);
        return result;
    }

    public static  <T> Result<T> fail(String message) {
        Result<T> result = new Result<>();
        result.setCode(fail);
        result.setMessage(message);
        return result;
    }
}
