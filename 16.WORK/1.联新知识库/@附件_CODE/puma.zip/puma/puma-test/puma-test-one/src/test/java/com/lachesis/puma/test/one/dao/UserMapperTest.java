package com.lachesis.puma.test.one.dao;

import com.lachesis.puma.test.one.PumaTestOneApplication;
import com.lachesis.puma.test.one.domain.User;
import com.lachesis.puma.test.one.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = PumaTestOneApplication.class)
class UserMapperTest {

    @Autowired
    private UserMapper userMapper;

    @Test
    void insert() {
    }

    @Test
    void insertBatch() {
    }

    @Test
    void updateById() {
    }

    @Test
    void deleteById() {
    }

    @Test
    void selectById() {
        User user = userMapper.selectById(1);
        System.out.println(user);
    }

    @Test
    void selectByUsername() {
    }

    @Test
    void selectByIds() {
    }
}