package com.lachesis.puma.test.one.domain;

import lombok.Data;

import java.util.Date;

@Data
public class User {
    private Long id;
    private String username;
    private Integer age;
    private Date birthDate;
    private Long createTime;
    private Long updateTime;
}
