package com.lachesis.puma.test.one.controller;

public class Demo {

    public Demo(int i) {
    }
}
