package com.lachesis.puma.test.one.mapper;

import com.lachesis.puma.test.one.domain.User;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;
import java.util.List;

public interface UserMapper {

    int insert(User user);

    void insertBatch(@Param("users") Collection<User> users);

    int updateById(User user);

    int deleteById(@Param("id") Integer id);

    User selectById(@Param("id") Integer id);

    User selectByUsername(@Param("username") String username);

    List<User> selectByIds(@Param("ids") Collection<Integer> ids);

}
