package com.lachesis.puma.test.one.controller;

import com.lachesis.puma.test.one.domain.Result;
import com.lachesis.puma.test.one.domain.ResultBuilder;
import com.lachesis.puma.test.one.domain.User;
import com.lachesis.puma.test.one.service.IUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private IUserService userService;

    @GetMapping("/sync/{id}")
    public User getUserSync(@PathVariable Integer id) {
        test1();
        test2();
        test3();
        test4();
        new InnerClass().test();
        return userService.selectById(id);
    }

    class InnerClass {
        void test() {

        }
    }

    private void test4() {
        // System.out.println(1/0);
    }

    private void test3() {
        test31();
        test32();
    }

    private void test32() {

    }

    private void test31() {

    }

    private void test2() {

    }

    private void test1() {
        UserHelper userHelper = new UserHelper();
        userHelper.doHelp();
        test11();
    }

    private void test11() {

    }

    @GetMapping("/async1/{id}")
    public User getUserAsync1(@PathVariable Integer id) {
        User user = userService.selectById(id);
        new Thread(() -> {
            try {
                int i = 3;
                log.info("等待{}秒后执行...", i);
                TimeUnit.SECONDS.sleep(i);
                User user1 = userService.selectById(id);
                log.info("执行完成");
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }).start();
        return user;
    }

    @GetMapping("/async2/{id}")
    public User getUserAsync2(@PathVariable Integer id) {
        User user = userService.selectById(id);
        SyncLife syncLife = SyncLife.CONVERT;
        new Demo(1);
        GerUserRunnable runnable = new GerUserRunnable(id, userService);
        new Thread(runnable).start();
        return user;
    }

    @PostMapping
    public Result<Boolean> add(@RequestBody User user) {
        boolean ok = userService.insert(user);
        return ResultBuilder.success(ok);
    }

    @PutMapping
    public Result<Boolean> update(@RequestBody User user) {
        boolean ok = userService.update(user);
        return ResultBuilder.success(ok);
    }

    @DeleteMapping("/{id}")
    public Result<Boolean> delete(@PathVariable Integer id) {
        boolean ok = userService.deleteById(id);
        return ResultBuilder.success(ok);
    }

    @GetMapping("/test/{id}")
    public void test(@PathVariable Integer id) {
        List<UserInfo> list = new ArrayList<>();
        if (id == 1) {
            list.add(new UserInfo(1, "a1", 18));
            list.add(new UserInfo(2, "a2", 19));
            list.add(new UserInfo(3, "a3", 20));
        } else {
            list.add(new UserInfo(1, "b1", 18));
            list.add(new UserInfo(2, "b2", 19));
            list.add(new UserInfo(3, "b3", 20));
        }
        // get(list);
    }

    // public static void main(String[] args) {
    //     List<UserInfo> list = new ArrayList<>();
    //     UserInfo userInfo = new UserInfo(1, "a", 18);
    //     System.out.println(list != null || userInfo != null && userInfo.getAge() == 18);
    //     System.out.println(list != null || (userInfo != null && userInfo.getAge() == 18));
    // }

    // public void get(List<UserInfo> list) {
    //     System.out.println(list);
    // }

    static class UserInfo {
        private int id;
        private String name;
        private int age;

        public UserInfo(int id, String name, int age) {
            this.id = id;
            this.name = name;
            this.age = age;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }
    }
}
