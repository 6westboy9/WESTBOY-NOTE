package com.lachesis.puma.test.one.domain.subdomain;

public class UserSubDomain {

    public void test() {

    }
}
