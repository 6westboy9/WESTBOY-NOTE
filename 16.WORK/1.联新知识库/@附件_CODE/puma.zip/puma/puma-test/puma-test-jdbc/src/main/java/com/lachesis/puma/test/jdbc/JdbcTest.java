package com.lachesis.puma.test.jdbc;

import java.sql.*;

public class JdbcTest {
    public static void main(String[] args) throws SQLException {
        String DB_URL = "jdbc:mysql://10.2.6.43:3306/test?characterEncoding=utf8&allowMultiQueries=true&serverTimezone=Asia/Shanghai";
        String USER = "user";
        String PASS = "Lachesis-mh_1024";
        Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT id, username, age, birth_date, create_time, update_time FROM user_info WHERE id = 1");
        while (rs.next()) {
            int id = rs.getInt(1);
            String username = rs.getString(2);
            int age = rs.getInt(3);
            Date birthDate = rs.getDate(4);
            long createTime = rs.getLong(5);
            long updateTime = rs.getLong(6);

            System.out.println(id);
            System.out.println(username);
            System.out.println(age);
            System.out.println(birthDate);
            System.out.println(createTime);
            System.out.println(updateTime);
        }
    }
}
