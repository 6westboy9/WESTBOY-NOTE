package com.lachesis.mapper.router.starter.biz;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatInfo implements Serializable {

    /**
     * 患者住院号
     */
    private String inhosCode;
    /**
     * 变更前的患者基础信息
     */
    private SimpleRecord sourceRecord;
    /**
     * 变更后的患者基础信息
     */
    private SimpleRecord targetRecord;

    public PatInfo(SimpleRecord sourceRecord, SimpleRecord targetRecord) {
        this.inhosCode = sourceRecord.getInhosCode();
        this.sourceRecord = sourceRecord;
        this.targetRecord = targetRecord;
    }
}
