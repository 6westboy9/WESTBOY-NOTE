package com.lachesis.mapper.router.starter.constant;

public enum ParamType {
    INHOS_CODE
}
