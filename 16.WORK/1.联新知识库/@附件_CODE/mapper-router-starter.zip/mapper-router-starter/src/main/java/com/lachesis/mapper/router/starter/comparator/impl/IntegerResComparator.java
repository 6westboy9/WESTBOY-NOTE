package com.lachesis.mapper.router.starter.comparator.impl;

import com.lachesis.mapper.router.starter.comparator.AbstractResComparator;
import com.lachesis.mapper.router.starter.comparator.CompareResult;
import com.lachesis.mapper.router.starter.constant.CompareErrEnum;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class IntegerResComparator extends AbstractResComparator<Integer> {

    @Override
    public Integer castAndClone(Object res) {
        return (Integer) res;
    }

    @Override
    public CompareResult doCompare(MapperRouterContext context, @NonNull Integer oldRes, @NonNull Integer newRes) {
        if (!oldRes.equals(newRes)) {
            return CompareResult.newFail(CompareErrEnum.RES_NE, oldRes, newRes);
        }
        return CompareResult.newSuccess();
    }
}
