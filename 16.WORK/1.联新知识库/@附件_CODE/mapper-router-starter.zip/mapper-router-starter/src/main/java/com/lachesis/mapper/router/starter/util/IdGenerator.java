package com.lachesis.mapper.router.starter.util;

import cn.hutool.core.util.StrUtil;

import java.util.UUID;

public class IdGenerator {

    private static final String PROCESS_ID = UUID.randomUUID().toString().replaceAll("-", "");
    private static final ThreadLocal<IDContext> THREAD_ID_SEQUENCE = ThreadLocal.withInitial(() -> new IDContext(System.currentTimeMillis(), (short) 0));

    /**
     * 生成一个新的id由三部分组成
     * <ul>
     *     <li>第一部分表示应用实例的id</li>
     *     <li>第二部分表示线程id</li>
     *     <li>第三部分包含两部分：一个毫秒级的时间戳+一个当前线程里的序号(0-9999不断循环)</li>
     * </ul>
     *
     * @return id
     */
    public static String generate() {
        return StrUtil.join(
            ".",
            PROCESS_ID,
            String.valueOf(Thread.currentThread().getId()),
            String.valueOf(THREAD_ID_SEQUENCE.get().nextSeq())
        );
    }

    private static class IDContext {

        // 暂时不考虑时间回拨的问题
        private long lastTimestamp;
        private short threadSeq;

        private IDContext(long lastTimestamp, short threadSeq) {
            this.lastTimestamp = lastTimestamp;
            this.threadSeq = threadSeq;
        }

        private long nextSeq() {
            return timestamp() * 10000 + nextThreadSeq();
        }

        private long timestamp() {
            lastTimestamp = System.currentTimeMillis();
            return lastTimestamp;
        }

        private short nextThreadSeq() {
            if (threadSeq == 10000) {
                threadSeq = 0;
            }
            return threadSeq++;
        }
    }
}
