package com.lachesis.mapper.router.starter.core.handler.newhandler.executor;

import com.lachesis.mapper.router.starter.MapperRouterProperties;
import com.lachesis.mapper.router.starter.constant.InnerVariable;
import com.lachesis.mapper.router.starter.core.CachedExpParser;
import com.lachesis.mapper.router.starter.core.ExpEvalContext;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;
import lombok.Getter;
import lombok.Setter;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
public class ExecuteContext {

    private final MapperRouterInvocation invocation;
    private final MapperRouterProperties properties;
    private final MapperRouterMethodAnno methodAnno;
    private final CachedExpParser expParser;
    private final ExecuteLog executeLog;

    /**
     * 为可变对象
     */
    private final ExpEvalContext evalContext;
    private final Map<String, Object> innerVars;

    @Setter
    private ExecuteCase executeCase;
    @Setter
    private String item;
    @Setter
    private List<String> items;
    @Setter
    private List<String> unknownItems;

    public ExecuteContext(MapperRouterInvocation invocation, MapperRouterProperties properties, MapperRouterMethodAnno methodAnno, CachedExpParser expParser) {
        this.invocation = invocation;
        this.properties = properties;
        this.methodAnno = methodAnno;
        this.expParser = expParser;
        this.evalContext = expParser.createEvalContext(invocation);
        this.innerVars = new HashMap<>();
        this.executeLog = new ExecuteLog();
    }

    public void setInnerVar(InnerVariable innerVariable, Object value) {
        evalContext.setVariable(innerVariable.getInnerName(), value);
        innerVars.put(innerVariable.getInnerName(), value);
    }

    public List<String> getUnknownItemsElseEmpty() {
        return unknownItems == null ? Collections.emptyList() : unknownItems;
    }

    public void startParseParamExp() {
        executeLog.setParamParseStartTime(System.currentTimeMillis());
    }

    public void finishParseParamExp() {
        executeLog.setParamParseFinishTime(System.currentTimeMillis());
    }

    public void addExecuteItemLog(ExecuteItemLog executeItemLog) {
        executeLog.addExecuteItemLog(executeItemLog);
    }
}
