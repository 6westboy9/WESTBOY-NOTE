package com.lachesis.mapper.router.starter.core.handler.oldhandler;

import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import com.lachesis.mapper.router.starter.core.handler.IMapperHandler;
import com.lachesis.mapper.router.starter.monitor.Stage;
import org.springframework.stereotype.Component;

@Component
public class OldMapperHandler implements IMapperHandler {

    @Override
    public Object handle(MapperRouterContext context) throws Throwable {
        context.begin(Stage.HANDLE_WITH_OLD_MODE);
        try {
            MapperRouterInvocation invocation = context.getInvocation();
            Object result = invocation.doInvoke();
            context.end(Stage.HANDLE_WITH_OLD_MODE);
            return result;
        } catch (Throwable throwable) {
            context.error(Stage.HANDLE_WITH_OLD_MODE, throwable);
            throw throwable;
        }
    }
}
