package com.lachesis.mapper.router.starter.biz.newhandler.executor;

import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBizShardingExecutor;

public interface IMultipleBizShardingExecutor extends IBizShardingExecutor {
}
