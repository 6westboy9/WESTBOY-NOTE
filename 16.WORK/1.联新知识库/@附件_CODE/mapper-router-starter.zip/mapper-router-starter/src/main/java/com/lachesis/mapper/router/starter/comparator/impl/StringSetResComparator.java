package com.lachesis.mapper.router.starter.comparator.impl;

import com.lachesis.mapper.router.starter.comparator.CompareResult;
import com.lachesis.mapper.router.starter.comparator.IResultComparator;
import com.lachesis.mapper.router.starter.constant.CompareErrEnum;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

@Slf4j
@Component
@Setter(onMethod_ = @Autowired)
public class StringSetResComparator implements IResultComparator {

    @Override
    public CompareResult compare(MapperRouterContext context, @NonNull Object oldRes, @NonNull Object newRes) {
        Set<String> oldSet = (Set<String>) oldRes;
        Set<String> newSet = (Set<String>) newRes;
        if (oldSet.size() != newSet.size()) {
            return CompareResult.newFail(CompareErrEnum.SIZE_NE, oldSet.size(), newSet.size());
        }
        if (!oldSet.containsAll(newSet)) {
            return CompareResult.newFail(CompareErrEnum.RES_NE, oldSet.toString(), newSet.toString());
        }
        return CompareResult.newSuccess();
    }
}
