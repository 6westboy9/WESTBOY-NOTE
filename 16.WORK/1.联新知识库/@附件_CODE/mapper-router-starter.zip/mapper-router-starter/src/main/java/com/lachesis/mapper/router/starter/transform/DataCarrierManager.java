package com.lachesis.mapper.router.starter.transform;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.lachesis.mapper.router.starter.biz.PatInfo;
import com.lachesis.mapper.router.starter.biz.PatInfos;
import com.lachesis.mapper.router.starter.biz.SplitResult;
import com.lachesis.mapper.router.starter.storage.ILogDataStorage;
import com.lachesis.mapper.router.starter.storage.mongo.data.PatDataCarrierLogInfo;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Slf4j
@Component
public class DataCarrierManager {

    private ExecutorService executorService;
    @Setter(onMethod_ = @Autowired)
    private ILogDataStorage logDataStorage;
    private final Map<DataCarrierAction, List<IDataCarrier>> dataCarrierMap = new HashMap<>();

    @PostConstruct
    public void init() {
        executorService = Executors.newFixedThreadPool(2, ThreadUtil.newNamedThreadFactory("MRDataCarrier-", false));
    }

    @Autowired
    public DataCarrierManager(List<IDataCarrier> dataCarriers) {
        if (CollUtil.isNotEmpty(dataCarriers)) {
            for (IDataCarrier dataCarrier : dataCarriers) {
                List<IDataCarrier> dataCarrierList = dataCarrierMap.getOrDefault(dataCarrier.action(), new ArrayList<>());
                dataCarrierList.add(dataCarrier);
                dataCarrierMap.put(dataCarrier.action(), dataCarrierList);
            }
        }
    }

    /**
     * 扩展：提供通过日志id补偿处理逻辑
     */
    public void transPatDataByLogIds(List<String> logIds, String entry) {
        List<PatDataCarrierLogInfo> carrierLogs = logDataStorage.listDataCarrierLogs(logIds);
        if (CollUtil.isEmpty(carrierLogs)) {
            log.info("未查询到需要补偿处理的数据");
            return;
        }
        PatInfos patInfos = PatInfos.newInstance();
        carrierLogs.forEach(carrierLog -> {
            // 注意取的是当时日志记录的状态变更
            patInfos.add(carrierLog.getPatInfo());
        });
        // 补偿处理
        transPatData(patInfos, entry);
    }

    /**
     * 核心：迁移处理逻辑
     */
    public void transPatData(PatInfos patInfos, String entry) {
        Map<String, PatInfo> map = patInfos.getMap();
        if (map.isEmpty()) {
            return;
        }

        SplitResult result = patInfos.splitByStatus();
        PatInfos inPatInfos = result.getInPatInfos();
        PatInfos outPatInfos = result.getOutPatInfos();

        // 在院患者需要将可能存在的出院数据迁移至在院表
        if (!inPatInfos.isEmpty()) {
            DataCarrierContext context = new DataCarrierContext(inPatInfos, entry);
            DataCarrierTask task = new DataCarrierTask(context, DataCarrierAction.FROM_OUT_TO_IN);
            executorService.submit(task);
        }

        // 出院患者需要将可能存在的在院数据迁移至出院表
        if (!outPatInfos.isEmpty()) {
            DataCarrierContext context = new DataCarrierContext(outPatInfos, entry);
            DataCarrierTask task = new DataCarrierTask(context, DataCarrierAction.FROM_IN_TO_OUT);
            executorService.submit(task);
        }
    }

    private void transform(DataCarrierContext context, DataCarrierAction action) {
        List<IDataCarrier> dataCarriers = dataCarrierMap.get(action);
        if (CollUtil.isNotEmpty(dataCarriers)) {
            dataCarriers.forEach(dataCarrier -> dataCarrier.transform(context));
        }
    }

    private class DataCarrierTask implements Runnable {

        private final DataCarrierContext context;
        private final DataCarrierAction action;

        private DataCarrierTask(DataCarrierContext context, DataCarrierAction action) {
            this.context = context;
            this.action = action;
        }

        @Override
        public void run() {
            try {
                transform(context, action);
                saveLog();
            } catch (Exception e) {
                log.error("数据迁移任务执行异常", e);
            }
        }

        private void saveLog() {
            List<PatDataCarrierLog> carrierLogs = context.getCarrierLogs();
            if (CollUtil.isNotEmpty(carrierLogs)) {
                List<List<PatDataCarrierLog>> lists = CollUtil.split(carrierLogs, 1000);
                for (List<PatDataCarrierLog> list : lists) {
                    List<PatDataCarrierLogInfo> carrierLogDataList = list.stream()
                        .map(PatDataCarrierLog::transform)
                        .collect(Collectors.toList());
                    logDataStorage.asyncSaveBatch(carrierLogDataList);
                }
            }
        }
    }
}
