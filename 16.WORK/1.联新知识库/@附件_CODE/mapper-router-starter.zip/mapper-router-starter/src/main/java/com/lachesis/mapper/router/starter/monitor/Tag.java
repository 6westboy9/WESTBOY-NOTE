package com.lachesis.mapper.router.starter.monitor;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Tag {
    BEGIN("开始"),
    ERROR("异常"),
    END("结束");
    private final String tagName;
}
