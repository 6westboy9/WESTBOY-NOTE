package com.lachesis.mapper.router.starter.core;

import lombok.Getter;
import org.springframework.context.expression.MethodBasedEvaluationContext;
import org.springframework.core.ParameterNameDiscoverer;

@Getter
public class ExpEvalContext extends MethodBasedEvaluationContext {

    private final MapperRouterInvocation invocation;

    public ExpEvalContext(MapperRouterInvocation invocation, ParameterNameDiscoverer parameterNameDiscoverer) {
        super(invocation.getMapperProxy(), invocation.getMethod(), invocation.getArgs(), parameterNameDiscoverer);
        this.invocation = invocation;
    }

}
