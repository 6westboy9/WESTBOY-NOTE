package com.lachesis.mapper.router.starter.comparator;

public interface IMRComparator {

    void compare(Object t1, Object t2);


}
