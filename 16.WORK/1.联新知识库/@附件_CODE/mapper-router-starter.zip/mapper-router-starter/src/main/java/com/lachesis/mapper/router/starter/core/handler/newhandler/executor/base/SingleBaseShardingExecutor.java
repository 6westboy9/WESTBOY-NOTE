package com.lachesis.mapper.router.starter.core.handler.newhandler.executor.base;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.lang.Validator;
import com.lachesis.mapper.router.starter.constant.ParamType;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteCase;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBaseShardingExecutor;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBizShardingExecutor;
import com.lachesis.mapper.router.starter.biz.newhandler.executor.ISingleBizShardingExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class SingleBaseShardingExecutor implements IBaseShardingExecutor {

    private final Map<ParamType, ISingleBizShardingExecutor> map = new HashMap<>();

    @Autowired
    public SingleBaseShardingExecutor(List<ISingleBizShardingExecutor> shardingExecutorList) {
        if (CollUtil.isEmpty(shardingExecutorList)) {
            return;
        }
        shardingExecutorList.forEach(shardingExecutor -> map.put(shardingExecutor.paramType(), shardingExecutor));
    }

    @Override
    public ExecuteCase getCase() {
        return ExecuteCase.SINGLE;
    }

    @Override
    public Object execute(ExecuteContext context) throws Exception {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        String item = context.getItem();
        Validator.validateNotEmpty(item, "item参数不能为空");
        IBizShardingExecutor bizShardingExecutor = map.get(methodAnno.getParamType());
        return bizShardingExecutor.execute(context);
    }
}
