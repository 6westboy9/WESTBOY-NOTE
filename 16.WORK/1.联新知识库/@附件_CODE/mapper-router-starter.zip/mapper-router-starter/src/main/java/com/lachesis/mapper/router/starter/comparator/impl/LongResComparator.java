package com.lachesis.mapper.router.starter.comparator.impl;

import com.lachesis.mapper.router.starter.comparator.AbstractResComparator;
import com.lachesis.mapper.router.starter.comparator.CompareResult;
import com.lachesis.mapper.router.starter.constant.CompareErrEnum;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class LongResComparator extends AbstractResComparator<Long> {

    @Override
    public Long castAndClone(Object res) {
        return (Long) res;
    }

    @Override
    public CompareResult doCompare(MapperRouterContext context, @NonNull Long oldRes, @NonNull Long newRes) {
        if (!oldRes.equals(newRes)) {
            return CompareResult.newFail(CompareErrEnum.RES_NE, oldRes, newRes);
        }
        return CompareResult.newSuccess();
    }
}
