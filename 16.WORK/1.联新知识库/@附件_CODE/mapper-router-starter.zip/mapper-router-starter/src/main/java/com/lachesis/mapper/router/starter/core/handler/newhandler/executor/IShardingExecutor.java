package com.lachesis.mapper.router.starter.core.handler.newhandler.executor;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.mapper.router.starter.MapperRouterProperties;
import com.lachesis.mapper.router.starter.constant.InnerVariable;
import com.lachesis.mapper.router.starter.constant.ShardingUnknownLogic;
import com.lachesis.mapper.router.starter.core.CachedExpParser;
import com.lachesis.mapper.router.starter.core.ExpEvalContext;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;

public interface IShardingExecutor {

    Object execute(ExecuteContext context) throws Exception;

    /**
     * 对于出院表的话，目前为分片表
     */
    default Object executeOutExpWhenUnknown(ExecuteContext context) {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        ShardingUnknownLogic unknownLogic = methodAnno.getUnknownLogic();
        if (ShardingUnknownLogic.IN_AND_RECENTLY_OUT.equals(unknownLogic)) {
            preExecuteRecentlyOutExpWhenUnknown(context);
        } else {
            preExecuteOutExpWhenUnknown(context);
        }
        String preCheckExp = methodAnno.getOutPreCheckExp();
        String exp = methodAnno.getOutExpWhenUnknown();
        return doExecute(context, preCheckExp, exp, "executeOutExpWhenUnknown");
    }

    /**
     * 对于在院表的话，目前仅单表
     */
    default Object executeInExpWhenUnknown(ExecuteContext context) {
        preExecuteInExpWhenUnknown(context);
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        String preCheckExp = methodAnno.getInPreCheckExp();
        String exp = methodAnno.getInExpWhenUnknown();
        return doExecute(context, preCheckExp, exp, "executeInExpWhenUnknown");
    }

    default Object executeOutExpWhenNoConfig(ExecuteContext context) {
        setOutRangeInnerVariable(context);
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        String preCheckExp = methodAnno.getOutPreCheckExp();
        String exp = methodAnno.getOutExp();
        return doExecute(context, preCheckExp, exp, "executeOutExpWhenNoConfig");
    }

    default Object executeOutExp(ExecuteContext context) {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        String preCheckExp = methodAnno.getOutPreCheckExp();
        String exp = methodAnno.getOutExp();
        return doExecute(context, preCheckExp, exp, "executeOutExp");
    }

    default Object executeInExp(ExecuteContext context) {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        String preCheckExp = methodAnno.getInPreCheckExp();
        String exp = methodAnno.getInExp();
        return doExecute(context, preCheckExp, exp, "executeInExp");
    }

    default Object doUnknown(ExecuteContext context) throws Exception {
        Object finalRes = null;
        Object inRes;
        Object outRes;
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        MapperRouterInvocation invocation = context.getInvocation();
        ShardingUnknownLogic unknownLogic = methodAnno.getUnknownLogic();
        switch (unknownLogic) {
            case ONLY_IN:
                inRes = executeInExpWhenUnknown(context);
                finalRes = aggregateRes(invocation, finalRes, inRes);
                break;
            case ONLY_OUT:
                outRes = executeOutExpWhenUnknown(context);
                finalRes = aggregateRes(invocation, finalRes, outRes);
                break;
            case IN_AND_RECENTLY_OUT:
            case ALL:
                Future<Object> inResFuture = AsyncShardingExecutor.submit(() -> executeInExpWhenUnknown(context));
                Future<Object> outResFuture = AsyncShardingExecutor.submit(() -> executeOutExpWhenUnknown(context));
                inRes = inResFuture.get();
                outRes = outResFuture.get();
                finalRes = aggregateRes(invocation, finalRes, inRes);
                finalRes = aggregateRes(invocation, finalRes, outRes);
                break;
            case IGNORE:
        }
        return finalRes;
    }

    /**
     * 配置了参数解析表达式，患者状态未知时，执行inExp之前的前置处理
     */
    default void preExecuteInExpWhenUnknown(ExecuteContext context) {

    }

    /**
     * 配置了参数解析表达式，患者状态未知时，执行outExp之前的前置处理（全表操作）
     */
    default void preExecuteOutExpWhenUnknown(ExecuteContext context) {

    }

    /**
     * 配置了参数解析表达式，患者状态未知时，执行outExp之前的前置处理（指定范围操作）
     * <p>
     * 可看做是preExecuteOutExpWhenUnknown的特殊情况，preExecuteOutExpWhenUnknown在处理时，会进行全表操作
     */
    default void preExecuteRecentlyOutExpWhenUnknown(ExecuteContext context) {

    }

    /**
     * 指定出院分片表出院时间范围操作
     * <p>
     * 此处仅设置内部变量，需要在表达式中使用，才会生效！
     */
    default void setOutRangeInnerVariable(ExecuteContext context) {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        int recentlyOutMonths = getRecentlyOutMonths(context, methodAnno);
        // 当前月
        Date maxOutDate = DateUtil.date();
        // 因为是包含当前月的，所以需要-1
        DateTime minOutDate = DateUtil.offsetMonth(maxOutDate, -(recentlyOutMonths - 1));
        context.setInnerVar(InnerVariable.MIN_OUT_DATE, minOutDate);
        context.setInnerVar(InnerVariable.MAX_OUT_DATE, maxOutDate);
    }

    /**
     * 最底层最核心的方法
     */
    default Object doExecute(ExecuteContext context, String preCheckExp, String exp, String source) {
        CachedExpParser expParser = context.getExpParser();
        ExpEvalContext evalContext = context.getEvalContext();
        boolean checkRes = true;
        if (StrUtil.isNotEmpty(preCheckExp)) {
            checkRes = expParser.parse(evalContext, preCheckExp, Boolean.class);
        }
        if (!checkRes) {
            return null;
        }
        if (StrUtil.isEmpty(exp)) {
            return null;
        }

        ExecuteItemLog executeItemLog = new ExecuteItemLog();
        executeItemLog.setSource(source);
        executeItemLog.setStartTime(System.currentTimeMillis());
        executeItemLog.setSuccess(true);
        executeItemLog.setExp(exp);
        executeItemLog.setInnerVars(context.getInnerVars());
        try {
            return expParser.parse(evalContext, exp);
        } catch (Exception e) {
            executeItemLog.setSuccess(false);
            executeItemLog.setThrowable(e);
            throw e;
        } finally {
            executeItemLog.setEndTime(System.currentTimeMillis());
            context.addExecuteItemLog(executeItemLog);
        }
    }

    /**
     * 聚合两个操作结果
     *
     * @param res1 操作结果1
     * @param res2 操作结果2
     */
    @SuppressWarnings({"unchecked"})
    default Object aggregateRes(MapperRouterInvocation invocation, Object res1, Object res2) {
        if (res1 == null && res2 == null) {
            return null;
        }

        if (res1 != null && res2 == null) {
            return res1;
        }

        if (res1 == null) {
            return res2;
        }

        if (invocation.isVoid()) {
            return null;
        } else if (invocation.isList()) {
            List<Object> list1 = (List<Object>) res1;
            List<Object> list2 = (List<Object>) res2;
            list1.addAll(list2);
            return list1;
        } else if (invocation.isSet()) {
            Set<Object> set1 = (Set<Object>) res1;
            Set<Object> set2 = (Set<Object>) res2;
            set1.addAll(set2);
            return set1;
        } else if (invocation.isInteger()) {
            int i1 = (int) res1;
            int i2 = (int) res2;
            return i1 + i2;
        } else if (invocation.isLong()) {
            long l1 = (long) res1;
            long l2 = (long) res2;
            return l1 + l2;
        }
        return null;
    }

    default int getRecentlyOutMonths(ExecuteContext context, MapperRouterMethodAnno methodAnno) {
        MapperRouterProperties properties = context.getProperties();

        // 这里只是上下问参数设置
        // 如果没有配置（即注解上的配置unknownRecentlyOutMonths）：设置为最近2个月（即全局配置handler-unknown-recently-out-months）
        // 如果有配置，取配置值
        // 但是，有参数不一定会在执行时生效，必须在调用接口上使用该才是才会生效，否则仍然是走全表！！！
        // 但是，有参数不一定会在执行时生效，必须在调用接口上使用该才是才会生效，否则仍然是走全表！！！
        // 但是，有参数不一定会在执行时生效，必须在调用接口上使用该才是才会生效，否则仍然是走全表！！！

        // 默认是-1，如果是-1取全局配置
        int recentlyOutMonths = methodAnno.getUnknownRecentlyOutMonths();
        if (recentlyOutMonths == -1) {
            // 为默认值时，取全局配置
            recentlyOutMonths = properties.getHandlerUnknownRecentlyOutMonths();
        }
        return recentlyOutMonths;
    }
}
