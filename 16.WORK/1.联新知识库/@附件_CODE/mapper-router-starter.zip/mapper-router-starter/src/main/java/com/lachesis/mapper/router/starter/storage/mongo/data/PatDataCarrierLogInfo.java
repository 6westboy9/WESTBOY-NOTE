package com.lachesis.mapper.router.starter.storage.mongo.data;

import com.lachesis.mapper.router.starter.biz.PatInfo;
import lombok.Data;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@Document(collection = "mapperRouterPatDataCarrierLog")
public class PatDataCarrierLogInfo {
    /**
     * 患者号
     */
    @Indexed(name = "inhosCodeIndex")
    private String inhosCode;
    private PatInfo patInfo;
    private String carrierId;
    /**
     * 业务类型
     */
    private String biz;
    private String action;
    private int sourceNum;
    private int targetNum;
    private boolean success;
    private String errorMsg;
    private String starTime;
    private String endTime;
    private long consume;
    /**
     * 默认过期时间为3天
     */
    @Indexed(name = "createTimeIndex", expireAfterSeconds = 259200)
    private Date createTime;
}
