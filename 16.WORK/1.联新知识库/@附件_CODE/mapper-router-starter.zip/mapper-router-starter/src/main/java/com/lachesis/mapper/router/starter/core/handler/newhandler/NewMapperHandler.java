package com.lachesis.mapper.router.starter.core.handler.newhandler;

import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import com.lachesis.mapper.router.starter.core.handler.IMapperHandler;
import com.lachesis.mapper.router.starter.monitor.Stage;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Setter(onMethod_ = @Autowired)
public class NewMapperHandler implements IMapperHandler {

    private SingleMapperHandler singleMapperHandler;
    private ShardingMapperHandler shardingMapperHandler;

    @Override
    public Object handle(MapperRouterContext context) throws Throwable {
        Object result;
        context.begin(Stage.HANDLE_WITH_NEW_MODE);
        try {
            if (context.isSharding()) {
                result = shardingMapperHandler.handle(context);
            } else {
                result = singleMapperHandler.handle(context);
            }
            context.end(Stage.HANDLE_WITH_NEW_MODE);
            return result;
        } catch (Throwable throwable) {
            context.error(Stage.HANDLE_WITH_NEW_MODE, throwable);
            throw throwable;
        }
    }
}
