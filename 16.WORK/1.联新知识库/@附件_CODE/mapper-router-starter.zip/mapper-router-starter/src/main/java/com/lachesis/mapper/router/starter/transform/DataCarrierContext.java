package com.lachesis.mapper.router.starter.transform;

import com.lachesis.mapper.router.starter.biz.PatInfo;
import com.lachesis.mapper.router.starter.biz.PatInfos;
import com.lachesis.mapper.router.starter.util.IdGenerator;
import com.yomahub.tlog.context.TLogContext;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Getter
public class DataCarrierContext {

    private final String carrierId;
    private final String entry;
    private final PatInfos patInfos;
    private final List<PatDataCarrierLog> carrierLogs;

    public DataCarrierContext(PatInfos patInfos, String entry) {
        this.carrierId = Optional.ofNullable(TLogContext.getTraceId()).orElse(IdGenerator.generate());
        this.entry = entry;
        this.patInfos = patInfos;
        this.carrierLogs = new ArrayList<>(patInfos.patNum());
    }

    public Map<String, PatInfo> getPatMap() {
        return patInfos.getMap();
    }

    public void addCarrierLog(PatDataCarrierLog carrierLog) {
        carrierLogs.add(carrierLog);
    }

}
