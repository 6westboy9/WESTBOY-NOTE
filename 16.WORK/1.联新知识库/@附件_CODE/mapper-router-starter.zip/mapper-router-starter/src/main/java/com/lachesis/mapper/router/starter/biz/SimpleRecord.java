package com.lachesis.mapper.router.starter.biz;

import cn.hutool.json.JSONUtil;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class SimpleRecord implements Serializable {

    private String inhosCode;
    private Date outDate;
    private String status;

    public static SimpleRecord fromJSONStr(String str) {
        return JSONUtil.toBean(str, SimpleRecord.class);
    }

    public static String toJSONStr(SimpleRecord record) {
        return JSONUtil.toJsonStr(record);
    }

    public boolean isOut() {
        return "0".equals(status) && outDate != null;
    }

}