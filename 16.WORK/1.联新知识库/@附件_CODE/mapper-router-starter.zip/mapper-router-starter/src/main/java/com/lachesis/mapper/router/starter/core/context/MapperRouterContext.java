package com.lachesis.mapper.router.starter.core.context;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.lachesis.mapper.router.starter.MapperRouterProperties;
import com.lachesis.mapper.router.starter.comparator.CompareResult;
import com.lachesis.mapper.router.starter.constant.RouterMode;
import com.lachesis.mapper.router.starter.core.CachedExpParser;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;
import com.lachesis.mapper.router.starter.core.annotation.RoutingMethod;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteLog;
import com.lachesis.mapper.router.starter.monitor.*;
import com.lachesis.mapper.router.starter.storage.mongo.data.MapperRouterLogInfo;
import com.lachesis.mapper.router.starter.util.IdGenerator;
import com.yomahub.tlog.context.TLogContext;
import lombok.Getter;

import java.lang.reflect.Method;
import java.util.Optional;

@Getter
public class MapperRouterContext {

    private final MapperRouterInvocation invocation;
    private final MapperRouterProperties properties;
    private final MapperRouterMethodAnno methodAnno;
    private CachedExpParser expressionParser;
    private LogDataStorageController logDataStorageController;
    private MapperRouterLog mapperRouterLog;

    private MapperRouterContext(MapperRouterInvocation invocation, MapperRouterProperties properties) {
        this.invocation = invocation;
        this.properties = properties;
        this.methodAnno = getAnnoMetadata(invocation);
    }

    public static MapperRouterContext newInstance(MapperRouterInvocation invocation, MapperRouterProperties properties) {
        return new MapperRouterContext(invocation, properties);
    }

    /**
     * 有必要的情况下才生成解析器，比如走在院+出院分片表时，对于单表就不需要生产解析器
     */
    public void init() {
        if (methodAnno != null) {
            expressionParser = CachedExpParser.newInstance(invocation);
        }
        if (properties.isMonitorEnable()) {
            logDataStorageController = SpringUtil.getBean(LogDataStorageController.class);
        }
    }

    public RouterMode getRoutingStrategy() {
        return properties.getMode();
    }

    public boolean isSharding() {
        return methodAnno != null;
    }

    private MapperRouterMethodAnno getAnnoMetadata(MapperRouterInvocation invocation) {
        RoutingMethod routingMethod = getAnno(invocation.getMethod());
        return MapperRouterMethodAnno.of(routingMethod);
    }

    /**
     * 当前仅支持单个注解
     */
    private RoutingMethod getAnno(Method method) {
        RoutingMethod[] annotations = method.getAnnotationsByType(RoutingMethod.class);
        return ArrayUtil.get(annotations, 0);
    }

    public ExecuteContext newExecuteContext() {
        return new ExecuteContext(invocation, properties, methodAnno, expressionParser);
    }

    public void createLog() {
        if (properties.isMonitorEnable()) {
            MapperRouterLog routerLog = new MapperRouterLog();
            routerLog.setMapperName(invocation.getMapperClassName());
            routerLog.setMethodName(invocation.getMethod().getName());
            routerLog.setMode(properties.getMode().name());
            routerLog.setSource(properties.getUser());
            routerLog.setTLogId(Optional.ofNullable(TLogContext.getTraceId()).orElse(IdGenerator.generate()));
            routerLog.setSuccess(true);
            routerLog.setTimeline(MapperRouterTimeline.newInstance());
            routerLog.setStartTime(System.currentTimeMillis());
            this.mapperRouterLog = routerLog;
        }
    }

    public synchronized void begin(Stage stage) {
        if (properties.isMonitorEnable()) {
            mapperRouterLog.addTimeline(stage, Tag.BEGIN);
        }
    }

    public synchronized void end(Stage stage) {
        if (properties.isMonitorEnable()) {
            mapperRouterLog.addTimeline(stage, Tag.END);
        }
    }

    public synchronized void error(Stage stage, Throwable throwable) {
        if (properties.isMonitorEnable()) {
            mapperRouterLog.addTimeline(stage, Tag.ERROR, throwable);
        }
    }

    public void setCompareResult(CompareResult compareResult) {
        if (properties.isMonitorEnable()) {
            mapperRouterLog.setCompareResult(compareResult);
        }
    }

    public void setExecuteLog(ExecuteLog executeLogs) {
        if (properties.isMonitorEnable()) {
            mapperRouterLog.setExecuteLog(executeLogs);
        }
    }

    public void saveLog() {
        if (properties.isMonitorEnable()) {
            mapperRouterLog.setEndTime(System.currentTimeMillis());
            boolean doSave = !mapperRouterLog.isSuccess() || mapperRouterLog.getConsume() > properties.getMonitorLongtime();
            // 异常或者超过配置时间
            if (doSave) {
                mapperRouterLog.setArgs(invocation.getArgs());
                boolean timelineEnable = properties.isMonitorTimelineEnable();
                int errorMsgMaxLength = properties.getMonitorErrorMsgMaxLength();
                MapperRouterLogInfo logData = mapperRouterLog.transform(timelineEnable, errorMsgMaxLength);
                logDataStorageController.saveLog(logData);
            }
        }
    }
}