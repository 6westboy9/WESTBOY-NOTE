package com.lachesis.mapper.router.starter.monitor;

import lombok.Data;

import java.util.Map;

@Data
public class ExecuteItemLogInfo {
    private String source;
    private String exp;
    private Map<String, Object> innerVars;
    private boolean success;
    private long consume;
}
