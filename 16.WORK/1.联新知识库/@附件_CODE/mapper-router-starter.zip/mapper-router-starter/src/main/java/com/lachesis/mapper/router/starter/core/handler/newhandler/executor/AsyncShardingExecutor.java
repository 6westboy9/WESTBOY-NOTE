package com.lachesis.mapper.router.starter.core.handler.newhandler.executor;

import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.extra.spring.SpringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.*;
import java.util.function.Supplier;

@Slf4j
@Component
public class AsyncShardingExecutor {

    private static final ExecutorService EXECUTOR_SERVICE = new ThreadPoolExecutor(10, 50, 60, TimeUnit.MILLISECONDS,
        new ArrayBlockingQueue<>(1000),
        ThreadUtil.newNamedThreadFactory("MRShardingExecutor-", false), (r, executor) -> {
        log.info("执行异步任务饱和被拒绝由当前线程执行");
        r.run();
    });

    public static Future<Object> submit(Supplier<Object> supplier) {
        return SpringUtil.getBean(AsyncShardingExecutor.class).doSubmit(supplier);
    }

    private Future<Object> doSubmit(Supplier<Object> supplier) {
        return EXECUTOR_SERVICE.submit(supplier::get);
    }

}
