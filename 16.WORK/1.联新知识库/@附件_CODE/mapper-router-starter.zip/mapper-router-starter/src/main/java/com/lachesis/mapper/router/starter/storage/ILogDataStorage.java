package com.lachesis.mapper.router.starter.storage;

import com.lachesis.mapper.router.starter.storage.mongo.data.MapperRouterLogInfo;
import com.lachesis.mapper.router.starter.storage.mongo.data.PatDataCarrierLogInfo;

import java.util.List;

public interface ILogDataStorage {

    void asyncSave(MapperRouterLogInfo logData);

    void asyncSaveBatch(List<PatDataCarrierLogInfo> carrierLogDataList);

    List<PatDataCarrierLogInfo> listDataCarrierLogs(List<String> logIds);
}
