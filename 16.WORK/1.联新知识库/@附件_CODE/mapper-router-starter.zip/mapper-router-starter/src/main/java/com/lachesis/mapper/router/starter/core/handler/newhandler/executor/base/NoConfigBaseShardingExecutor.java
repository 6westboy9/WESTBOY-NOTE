package com.lachesis.mapper.router.starter.core.handler.newhandler.executor.base;

import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteCase;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBaseShardingExecutor;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.AsyncShardingExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.Future;

@Slf4j
@Component
public class NoConfigBaseShardingExecutor implements IBaseShardingExecutor {

    @Override
    public ExecuteCase getCase() {
        return ExecuteCase.NO_CONFIG;
    }

    @Override
    public Object execute(ExecuteContext context) throws Exception {
        Object finalRes = null;
        MapperRouterInvocation invocation = context.getInvocation();
        Future<Object> inResFuture = AsyncShardingExecutor.submit(() -> executeInExp(context));
        Future<Object> outResFuture = AsyncShardingExecutor.submit(() -> executeOutExpWhenNoConfig(context));
        Object inRes = inResFuture.get();
        Object outRes = outResFuture.get();
        finalRes = aggregateRes(invocation, finalRes, inRes);
        finalRes = aggregateRes(invocation, finalRes, outRes);
        return finalRes;
    }
}
