package com.lachesis.mapper.router.starter.storage.mongo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.lachesis.mapper.router.starter.storage.ILogDataStorage;
import com.lachesis.mapper.router.starter.storage.mongo.data.MapperRouterLogInfo;
import com.lachesis.mapper.router.starter.storage.mongo.data.PatDataCarrierLogInfo;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
@Setter(onMethod_ = @Autowired)
public class MongoLogDataStorage implements ILogDataStorage {

    private static final ExecutorService EXECUTOR_SERVICE =
        new ThreadPoolExecutor(5, 10, 60, TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(1000),
            ThreadUtil.newNamedThreadFactory("MRLogStorage-", false), (r, executor) -> {
            log.info("执行异步日志存储任务饱和被拒绝由当前线程执行");
            r.run();
        });

    /**
     * 暂时依赖应用中申明的MongoTemplate
     */
    private MongoTemplate mongoTemplate;

    @Override
    public void asyncSave(MapperRouterLogInfo logData) {
        EXECUTOR_SERVICE.submit(() -> {
            try {
                mongoTemplate.save(logData);
            } catch (Exception e) {
                log.error("MR日志数据存储异常", e);
            }
        });
    }

    @Override
    public void asyncSaveBatch(List<PatDataCarrierLogInfo> carrierLogDataList) {
        if (CollUtil.isEmpty(carrierLogDataList)) {
            return;
        }
        EXECUTOR_SERVICE.submit(() -> {
            try {
                mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, PatDataCarrierLogInfo.class)
                    .insert(carrierLogDataList)
                    .execute();
            } catch (Exception e) {
                log.error("MR日志数据存储异常", e);
            }
        });
    }

    @Override
    public List<PatDataCarrierLogInfo> listDataCarrierLogs(List<String> logIds) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").in(logIds));
        return mongoTemplate.find(query, PatDataCarrierLogInfo.class);
    }
}
