package com.lachesis.mapper.router.starter.core;

import com.lachesis.mapper.router.starter.core.annotation.RoutingMethod;
import com.lachesis.mapper.router.starter.constant.ParamNum;
import com.lachesis.mapper.router.starter.constant.ParamType;
import com.lachesis.mapper.router.starter.constant.ShardingUnknownLogic;
import com.lachesis.mapper.router.starter.comparator.IResultComparator;
import lombok.Data;

@Data
public class MapperRouterMethodAnno {

    private ShardingUnknownLogic unknownLogic;
    private ParamType paramType;
    private String paramExp;
    private ParamNum paramNum;
    private String inExp;
    private String outExp;
    private String inExpWhenUnknown;
    private String outExpWhenUnknown;
    private String inPreCheckExp;
    private String outPreCheckExp;
    private Class<? extends IResultComparator> comparatorClass;
    private int unknownRecentlyOutMonths;

    public static MapperRouterMethodAnno of(RoutingMethod routingMethod) {
        if (routingMethod == null) {
            return null;
        }
        MapperRouterMethodAnno methodAnno = new MapperRouterMethodAnno();
        methodAnno.setUnknownLogic(routingMethod.unknownLogic());
        methodAnno.setParamType(routingMethod.paramType());
        methodAnno.setParamExp(routingMethod.paramExp());
        methodAnno.setParamNum(routingMethod.paramNum());
        methodAnno.setInExp(routingMethod.inExp());
        methodAnno.setOutExp(routingMethod.outExp());
        methodAnno.setInExpWhenUnknown(routingMethod.inExpWhenUnknown());
        methodAnno.setOutExpWhenUnknown(routingMethod.outExpWhenUnknown());
        methodAnno.setInPreCheckExp(routingMethod.inPreCheckExp());
        methodAnno.setOutPreCheckExp(routingMethod.outPreCheckExp());
        methodAnno.setComparatorClass(routingMethod.comparatorClass());
        methodAnno.setUnknownRecentlyOutMonths(routingMethod.unknownRecentlyOutMonths());
        return methodAnno;
    }
}
