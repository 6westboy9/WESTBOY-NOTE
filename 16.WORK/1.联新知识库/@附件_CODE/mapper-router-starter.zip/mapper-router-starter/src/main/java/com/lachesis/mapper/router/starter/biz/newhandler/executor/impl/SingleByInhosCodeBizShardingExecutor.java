package com.lachesis.mapper.router.starter.biz.newhandler.executor.impl;

import com.lachesis.mapper.router.starter.biz.newhandler.executor.ISingleBizShardingExecutor;
import com.lachesis.mapper.router.starter.constant.InnerVariable;
import com.lachesis.mapper.router.starter.constant.ParamType;
import com.lachesis.mapper.router.starter.biz.IPatInhosRecordHelper;
import com.lachesis.mapper.router.starter.biz.SimpleRecord;
import com.lachesis.mapper.router.starter.biz.newhandler.executor.IInhosCodeBizShardingExecutor;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Slf4j
@Component
@Setter(onMethod_ = @Autowired)
public class SingleByInhosCodeBizShardingExecutor implements ISingleBizShardingExecutor, IInhosCodeBizShardingExecutor {

    private IPatInhosRecordHelper recordHelper;

    @Override
    public Object execute(ExecuteContext context) throws Exception {
        // 不可能为空
        String inhosCode = context.getItem();
        SimpleRecord record = recordHelper.getByInhosCode(inhosCode);
        if (record == null) {
            log.error("患者不存在[inhosCode={}]", inhosCode);
            return doUnknown(context);
        }

        // 单个患者要么出院要么住院
        if (record.isOut()) {
            Date outDate = record.getOutDate();
            context.setInnerVar(InnerVariable.OUT_DATE, outDate);
            return executeOutExp(context);
        } else {
            return executeInExp(context);
        }
    }

    @Override
    public ParamType paramType() {
        return ParamType.INHOS_CODE;
    }
}
