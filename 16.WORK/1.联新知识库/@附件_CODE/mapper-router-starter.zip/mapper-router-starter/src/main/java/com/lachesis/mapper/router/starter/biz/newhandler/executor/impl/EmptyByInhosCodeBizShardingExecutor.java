package com.lachesis.mapper.router.starter.biz.newhandler.executor.impl;

import com.lachesis.mapper.router.starter.biz.newhandler.executor.IEmptyBizShardingExecutor;
import com.lachesis.mapper.router.starter.biz.newhandler.executor.IInhosCodeBizShardingExecutor;
import com.lachesis.mapper.router.starter.constant.ParamType;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.AsyncShardingExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.Future;

@Slf4j
@Component
public class EmptyByInhosCodeBizShardingExecutor implements IEmptyBizShardingExecutor, IInhosCodeBizShardingExecutor {

    @Override
    public Object execute(ExecuteContext context) throws Exception {
        Object finalRes = null;
        MapperRouterInvocation invocation = context.getInvocation();
        Future<Object> inResFuture = AsyncShardingExecutor.submit(() -> executeInExpWhenUnknown(context));
        Future<Object> outResFuture = AsyncShardingExecutor.submit(() -> executeOutExpWhenUnknown(context));
        Object inRes = inResFuture.get();
        Object outRes = outResFuture.get();
        finalRes = aggregateRes(invocation, finalRes, inRes);
        finalRes = aggregateRes(invocation, finalRes, outRes);
        return finalRes;
    }

    @Override
    public ParamType paramType() {
        return ParamType.INHOS_CODE;
    }
}
