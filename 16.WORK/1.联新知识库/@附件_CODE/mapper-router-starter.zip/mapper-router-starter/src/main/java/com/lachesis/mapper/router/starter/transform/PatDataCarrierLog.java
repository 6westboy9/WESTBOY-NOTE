package com.lachesis.mapper.router.starter.transform;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.exceptions.ExceptionUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.mapper.router.starter.biz.PatInfo;
import com.lachesis.mapper.router.starter.storage.mongo.data.PatDataCarrierLogInfo;
import lombok.Getter;

import java.util.Date;
import java.util.Optional;

import static cn.hutool.core.date.DatePattern.NORM_DATETIME_MS_FORMATTER;

@Getter
public class PatDataCarrierLog {
    /**
     * 患者号
     */
    private final String inhosCode;
    private final PatInfo patInfo;
    /**
     * 业务类型
     */
    private final IDataCarrierBiz biz;
    private final DataCarrierAction action;
    private final String carrierId;
    private final String entry;
    private int sourceNum;
    private int targetNum;
    private boolean success;
    private Throwable throwable;
    private Date startTime;
    private Date endTime;

    public PatDataCarrierLog(PatInfo patInfo, IDataCarrierBiz biz, DataCarrierAction action, String carrierId, String entry) {
        this.inhosCode = patInfo.getInhosCode();
        this.patInfo = patInfo;
        this.biz = biz;
        this.action = action;
        this.carrierId = carrierId;
        this.entry = entry;
    }

    public void start() {
        this.startTime = DateUtil.date();
    }

    public void success() {
        this.success = true;
        this.endTime = DateUtil.date();
    }

    public void fail(Throwable e) {
        this.success = false;
        this.endTime = DateUtil.date();
        this.throwable = e;
    }

    public void addSourceNum(int n) {
        sourceNum += n;
    }

    public void addTargetNum(int n) {
        targetNum += n;
    }

    public PatDataCarrierLogInfo transform() {
        PatDataCarrierLogInfo logInfo = new PatDataCarrierLogInfo();
        logInfo.setInhosCode(inhosCode);
        logInfo.setPatInfo(patInfo);
        logInfo.setCarrierId(carrierId);
        logInfo.setBiz(Optional.ofNullable(biz).map(IDataCarrierBiz::name).orElse(StrUtil.EMPTY));
        logInfo.setAction(action.name());
        logInfo.setSourceNum(sourceNum);
        logInfo.setTargetNum(targetNum);
        logInfo.setSuccess(success);
        if (throwable != null) {
            logInfo.setErrorMsg(ExceptionUtil.stacktraceToString(throwable, 1000));
        }
        logInfo.setStarTime(DateUtil.format(startTime, NORM_DATETIME_MS_FORMATTER));
        logInfo.setEndTime(DateUtil.format(endTime, NORM_DATETIME_MS_FORMATTER));
        logInfo.setConsume(endTime.getTime() - startTime.getTime());
        logInfo.setCreateTime(DateUtil.date());
        return logInfo;
    }
}
