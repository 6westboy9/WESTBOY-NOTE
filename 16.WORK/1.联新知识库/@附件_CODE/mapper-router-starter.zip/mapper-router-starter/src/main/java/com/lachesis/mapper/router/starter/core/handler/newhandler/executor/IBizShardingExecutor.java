package com.lachesis.mapper.router.starter.core.handler.newhandler.executor;

import com.lachesis.mapper.router.starter.constant.ParamType;

public interface IBizShardingExecutor extends IShardingExecutor {

    ParamType paramType();

}
