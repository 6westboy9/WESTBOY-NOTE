package com.lachesis.mapper.router.starter.transform;

import cn.hutool.json.JSONUtil;
import com.lachesis.mapper.router.starter.biz.PatInfo;
import com.lachesis.mapper.router.starter.biz.SimpleRecord;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public abstract class AbstractPatDataCarrier<SOURCE, TARGET> implements IDataCarrier {

    private static final int MAX_NUM = 1000;

    @Override
    public void transform(DataCarrierContext context) {
        Map<String, PatInfo> patMap = context.getPatMap();
        if (patMap.isEmpty()) {
            return;
        }
        IDataCarrierBiz biz = biz();
        DataCarrierAction action = action();
        // 单个患者为一条记录
        patMap.forEach((inhosCode, patInfo) -> transOneByOne(patInfo, biz, action, context));
    }

    protected abstract BatchResult<SOURCE> getSourceListBatch(SimpleRecord sourceRecord, long startSeqId, int maxNum);

    protected abstract TARGET convert2Target(SimpleRecord targetRecord, SOURCE source);

    protected abstract void insertTargetList(List<TARGET> targetList);

    protected abstract void deleteSourceList(SimpleRecord sourceRecord, List<SOURCE> inhosCodes);

    private void transOneByOne(PatInfo patInfo, IDataCarrierBiz biz, DataCarrierAction action, DataCarrierContext context) {
        String carrierId = context.getCarrierId();
        String entry = context.getEntry();
        PatDataCarrierLog carrierLog = new PatDataCarrierLog(patInfo, biz, action, carrierId, entry);
        try {
            long startSeqId = 0;
            carrierLog.start();
            do {
                // 分页获取待迁移数据，限制为1000条
                SimpleRecord sourceRecord = patInfo.getSourceRecord();
                SimpleRecord targetRecord = patInfo.getTargetRecord();
                BatchResult<SOURCE> sourceResult = getSourceListBatch(sourceRecord, startSeqId, MAX_NUM);
                if (sourceResult.isEmpty()) {
                    break;
                }
                List<SOURCE> sourceList = sourceResult.getData();
                carrierLog.addSourceNum(sourceList.size());

                List<TARGET> targetList = sourceList.stream()
                    .map(source -> convert2Target(targetRecord, source))
                    .collect(Collectors.toList());

                if (targetList.isEmpty()) {
                    break;
                }
                carrierLog.addTargetNum(targetList.size());
                insertTargetList(targetList);
                deleteSourceList(sourceRecord, sourceList);
                startSeqId = sourceResult.getMaxSeqId();
            } while (true);
            carrierLog.success();
            context.addCarrierLog(carrierLog);
        } catch (Exception e) {
            log.error("患者数据迁移 ===> 异常:{}", JSONUtil.toJsonStr(patInfo), e);
            carrierLog.fail(e);
            context.addCarrierLog(carrierLog);
        }
    }
}
