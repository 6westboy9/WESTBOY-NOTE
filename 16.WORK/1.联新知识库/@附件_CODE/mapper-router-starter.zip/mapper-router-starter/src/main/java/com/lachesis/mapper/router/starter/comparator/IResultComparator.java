package com.lachesis.mapper.router.starter.comparator;

import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;

public interface IResultComparator {

    CompareResult compare(MapperRouterContext context, @NonNull Object oldRes, @NonNull Object newRes);

}
