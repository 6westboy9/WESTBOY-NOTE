package com.lachesis.mapper.router.starter.comparator.impl;

import com.lachesis.mapper.router.starter.comparator.AbstractResComparator;
import com.lachesis.mapper.router.starter.comparator.CompareResult;
import com.lachesis.mapper.router.starter.constant.CompareErrEnum;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public abstract class AbstractListResComparator<T> extends AbstractResComparator<List<T>> {

    protected abstract AbstractResComparator<T> getComparator();

    @Override
    public List<T> castAndClone(Object res) {
        List<T> list = (List<T>) res;
        AbstractResComparator<T> comparator = getComparator();
        return list.stream().map(comparator::castAndClone).collect(Collectors.toList());
    }

    @Override
    public CompareResult doCompare(MapperRouterContext context, @NonNull List<T> oldRes, @NonNull List<T> newRes) {
        if (oldRes.size() != newRes.size()) {
            return CompareResult.newFail(CompareErrEnum.SIZE_NE, oldRes.size(), newRes.size());
        }
        AbstractResComparator<T> comparator = getComparator();
        for (int i = 0; i < oldRes.size(); i++) {
            T oldItem = oldRes.get(0);
            T newItem = newRes.get(0);
            CompareResult result = comparator.compare(context, oldItem, newItem);
            if (!result.isSuccess()) {
                return CompareResult.newFail(CompareErrEnum.ITEM_NE, result.getMessage());
            }
        }
        return CompareResult.newSuccess();
    }

}
