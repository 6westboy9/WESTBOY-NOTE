package com.lachesis.mapper.router.starter.monitor;

import lombok.Data;

import java.util.List;

@Data
public class ExecuteLogInfo {
    private long paramParseConsume;
    private List<ExecuteItemLogInfo> executeItemLogInfos;
}
