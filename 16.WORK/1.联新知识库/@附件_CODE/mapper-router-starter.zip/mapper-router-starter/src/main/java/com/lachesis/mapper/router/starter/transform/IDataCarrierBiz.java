package com.lachesis.mapper.router.starter.transform;

public interface IDataCarrierBiz {

    String name();

}
