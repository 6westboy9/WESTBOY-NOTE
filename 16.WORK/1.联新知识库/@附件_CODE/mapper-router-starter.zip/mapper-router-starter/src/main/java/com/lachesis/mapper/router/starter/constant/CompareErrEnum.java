package com.lachesis.mapper.router.starter.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CompareErrEnum {

    SIZE_NE("大小不相同:%s|%s", true),
    RES_NE("数据不相同:%s|%s", true),
    ITEM_NE("存在元素不相同:%s", true),
    OLD_IS_NULL("旧数据为null", false),
    NEW_IS_NULL("新数据为null", false),
    UNKNOWN_EXP("未知异常", false),
    SINGLE_TABLE("单表操作无需比对", false),
    RETURN_VOID("返回类型为void", false),
    ALL_IS_NULL("新旧数据均为null", false);

    private final String message;
    private final boolean needParams;
}
