package com.lachesis.mapper.router.starter.comparator;

import cn.hutool.extra.spring.SpringUtil;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;
import org.springframework.stereotype.Component;

/**
 * 缺点：不会进行深拷贝，对于对象集合比对进进行大小比对，明细不进行比对
 */
@Component
public class DefaultResultComparator implements IResultComparator {

    @Override
    public CompareResult compare(MapperRouterContext context,@NonNull Object oldRes, @NonNull Object newRes) {
        MapperRouterInvocation invocation = context.getInvocation();
        ResComparatorEnum comparatorEnum = invocation.getComparatorEnum();
        Class<? extends IResultComparator> comparatorClass = comparatorEnum.getComparator();
        IResultComparator comparator = SpringUtil.getBean(comparatorClass);
        return comparator.compare(context, oldRes, newRes);
    }
}
