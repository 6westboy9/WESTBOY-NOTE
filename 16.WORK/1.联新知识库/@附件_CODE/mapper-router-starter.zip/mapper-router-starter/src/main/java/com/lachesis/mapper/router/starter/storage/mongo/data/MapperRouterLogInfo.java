package com.lachesis.mapper.router.starter.storage.mongo.data;

import com.lachesis.mapper.router.starter.monitor.ExecuteLogInfo;
import lombok.Data;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@Document(collection = "mapperRouterLog")
public class MapperRouterLogInfo implements Serializable {
    /**
     * Mapper接口名称
     */
    private String mapperName;
    /**
     * Mapper方法名，因为MyBatis中Mapper的方法名不会存在相同情况，所以mapperName和methodName一起可作为唯一标识
     */
    private String methodName;
    /**
     * 唯一方法标识
     */
    @Indexed(name = "mapperMethodIdIndex")
    private String mapperMethodId;
    private String mode;
    /**
     * 操作来源：EMR，DATA_SYNC
     */
    private String source;
    /**
     * TLog的唯一标识
     */
    @Indexed(name = "tLogIdIndex")
    private String tLogId;
    /**
     * 开始时间
     */
    private long startTime;
    /**
     * 结束时间
     */
    private long endTime;
    /**
     * 参数
     */
    private Object[] args;
    /**
     * 是否成功
     */
    private boolean success;
    /**
     * 耗时
     */
    private long consume;
    /**
     * 旧链路耗时
     */
    private long oldConsume;
    /**
     * 新链路耗时
     */
    private long newConsume;
    /**
     * -1.默认；0.失败；1.成功
     */
    private int compareStatus;
    private long compareConsume;
    private String compareMessage;
    private String errorMsg;
    private List<String> timelineList;
    /**
     * 当前仅限分片操作日志
     */
    private ExecuteLogInfo executeLogInfo;

    @Indexed(name = "createTimeIndex", expireAfterSeconds = 7200)
    private Date createTime;
}
