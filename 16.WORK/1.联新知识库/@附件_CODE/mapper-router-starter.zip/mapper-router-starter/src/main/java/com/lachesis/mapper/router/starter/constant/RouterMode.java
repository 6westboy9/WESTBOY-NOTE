package com.lachesis.mapper.router.starter.constant;

/**
 * 路由策略
 */
public enum RouterMode {
    /**
     * 旧方案
     */
    OLD,
    /**
     * 新方案
     */
    NEW,
    /**
     * 新方案+新方案，但是返回旧方案结果
     */
    ALL_RETURN_OLD,
    /**
     * 新方案+新方案，但是返回新方案结果
     */
    ALL_RETURN_NEW,
}
