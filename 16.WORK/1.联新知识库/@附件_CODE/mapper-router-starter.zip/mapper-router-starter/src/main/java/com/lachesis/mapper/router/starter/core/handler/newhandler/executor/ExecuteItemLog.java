package com.lachesis.mapper.router.starter.core.handler.newhandler.executor;

import com.lachesis.mapper.router.starter.monitor.ExecuteItemLogInfo;
import lombok.Data;

import java.util.Map;

@Data
public class ExecuteItemLog {
    private String source;
    private boolean success;
    private String exp;
    private Map<String, Object> innerVars;
    private Throwable throwable;
    private long startTime;
    private long endTime;

    public ExecuteItemLogInfo transform() {
        ExecuteItemLogInfo info = new ExecuteItemLogInfo();
        info.setSource(source);
        info.setExp(exp);
        info.setInnerVars(innerVars);
        info.setSuccess(success);
        info.setConsume(endTime - startTime);
        return info;
    }
}
