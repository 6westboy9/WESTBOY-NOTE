package com.lachesis.mapper.router.starter.monitor;

/**
 * 监控控制器
 */
public class MonitorController {

    public void init() {

        MapperRouterLog mapperRouterLog = new MapperRouterLog();
    }

}
