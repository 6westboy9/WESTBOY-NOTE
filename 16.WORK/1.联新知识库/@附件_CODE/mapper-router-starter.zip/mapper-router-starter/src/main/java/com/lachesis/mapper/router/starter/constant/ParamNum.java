package com.lachesis.mapper.router.starter.constant;

/**
 * 参数个数
 */
public enum ParamNum {

    /**
     * 没有
     */
    NO,
    /**
     * 单个
     */
    SINGLE,
    /**
     * 多个
     */
    MULTIPLE;

}
