package com.lachesis.mapper.router.starter.core.handler.newhandler.executor;

import cn.hutool.core.collection.CollUtil;
import com.lachesis.mapper.router.starter.monitor.ExecuteItemLogInfo;
import com.lachesis.mapper.router.starter.monitor.ExecuteLogInfo;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Data
public class ExecuteLog {
    private long paramParseStartTime;
    private long paramParseFinishTime;
    private final List<ExecuteItemLog> executeItemLogs = new ArrayList<>();

    public void addExecuteItemLog(ExecuteItemLog executeItemLog) {
        executeItemLogs.add(executeItemLog);
    }

    public ExecuteLogInfo transform() {
        ExecuteLogInfo executeLogInfo = new ExecuteLogInfo();
        executeLogInfo.setParamParseConsume(paramParseFinishTime - paramParseStartTime);
        if (CollUtil.isNotEmpty(executeItemLogs)) {
            List<ExecuteItemLogInfo> dataList = executeItemLogs.stream()
                .map(ExecuteItemLog::transform).collect(Collectors.toList());
            executeLogInfo.setExecuteItemLogInfos(dataList);
        }
        return executeLogInfo;
    }
}
