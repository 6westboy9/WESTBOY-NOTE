package com.lachesis.mapper.router.starter.transform;

public interface IDataCarrier {

    void transform(DataCarrierContext context);

    DataCarrierAction action();

    IDataCarrierBiz biz();

}
