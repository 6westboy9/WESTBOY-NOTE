package com.lachesis.mapper.router.starter.core.handler.newhandler;

import cn.hutool.core.util.StrUtil;
import com.lachesis.mapper.router.starter.core.CachedExpParser;
import com.lachesis.mapper.router.starter.core.ExpEvalContext;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import com.lachesis.mapper.router.starter.core.handler.IMapperHandler;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteCase;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBaseShardingExecutor;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IShardingExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class ShardingMapperHandler implements IMapperHandler {

    private final Map<ExecuteCase, IBaseShardingExecutor> executorMap = new ConcurrentHashMap<>();

    @Autowired
    public ShardingMapperHandler(List<IBaseShardingExecutor> shardingExecutorList) {
        shardingExecutorList.forEach(shardingExecutor -> executorMap.put(shardingExecutor.getCase(), shardingExecutor));
    }

    @Override
    public Object handle(MapperRouterContext context) throws Throwable {
        ExecuteContext executeContext = context.newExecuteContext();
        executeContext.startParseParamExp();
        parseParamExp(executeContext);
        executeContext.finishParseParamExp();
        IShardingExecutor shardingExecutor = executorMap.get(executeContext.getExecuteCase());
        Object obj = shardingExecutor.execute(executeContext);
        context.setExecuteLog(executeContext.getExecuteLog());
        return obj;
    }

    private void parseParamExp(ExecuteContext executeContext) {
        CachedExpParser expParser = executeContext.getExpParser();
        MapperRouterMethodAnno methodAnno = executeContext.getMethodAnno();
        String paramExp = methodAnno.getParamExp();
        if (StrUtil.EMPTY.equals(paramExp)) {
            executeContext.setExecuteCase(ExecuteCase.NO_CONFIG);
            return;
        }
        ExpEvalContext evalContext = executeContext.getEvalContext();
        Object paramValue = expParser.parse(evalContext, paramExp);
        if (paramValue == null) {
            // 与NO_CONFIG不同，NO_CONFIG是压根就没有配置参数解析表达式
            // 而EMPTY是配置了解析表达式，只是解析结果为空
            executeContext.setExecuteCase(ExecuteCase.EMPTY);
            return;
        }
        // 多个参数时，仅支持字符串集合，单个时也仅支持字符串
        if (paramValue instanceof List) {
            List<String> items = (List<String>) paramValue;
            if (allIsEmpty(items)) {
                executeContext.setExecuteCase(ExecuteCase.EMPTY);
                return;
            }
            executeContext.setExecuteCase(ExecuteCase.MULTIPLE);
            executeContext.setItems(items);
            return;
        } else if (paramValue instanceof String) {
            String item = (String) paramValue;
            if (StrUtil.isEmpty(item)) {
                executeContext.setExecuteCase(ExecuteCase.EMPTY);
                return;
            }
            executeContext.setExecuteCase(ExecuteCase.SINGLE);
            executeContext.setItem(item);
            return;
        }
        executeContext.setExecuteCase(ExecuteCase.ERROR);
    }

    private boolean allIsEmpty(List<String> items) {
        for (String item : items) {
            if (StrUtil.isNotEmpty(item)) {
                return false;
            }
        }
        return true;
    }
}
