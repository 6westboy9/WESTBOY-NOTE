package com.lachesis.mapper.router.starter.comparator;

import com.lachesis.mapper.router.starter.comparator.impl.*;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ResComparatorEnum {

    INTEGER(IntegerResComparator.class),
    LONG(LongResComparator.class),
    OBJECT(ObjectResComparator.class),
    OBJECT_LIST(ObjectListResComparator.class),
    STRING(StringResComparator.class),
    STRING_LIST(StringListResComparator.class),
    STRING_SET(StringSetResComparator.class);

    private final Class<? extends IResultComparator> comparator;

}
