package com.lachesis.mapper.router.starter.core.annotation;

import com.lachesis.mapper.router.starter.constant.ParamNum;
import com.lachesis.mapper.router.starter.constant.ParamType;
import com.lachesis.mapper.router.starter.constant.ShardingUnknownLogic;
import com.lachesis.mapper.router.starter.comparator.DefaultResultComparator;
import com.lachesis.mapper.router.starter.comparator.IResultComparator;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface RoutingMethod {

    /**
     * 未知患者状态时路由逻辑，兜底策略必填
     */
    ShardingUnknownLogic unknownLogic() default ShardingUnknownLogic.ALL;

    /**
     * 参数类型，代表paramExp中解析结果含义
     */
    ParamType paramType() default ParamType.INHOS_CODE;

    /**
     * 参数解析表达式，可选
     */
    String paramExp() default "";

    /**
     * 参数数量，可选
     */
    ParamNum paramNum() default ParamNum.NO;

    /**
     * 在院分片表操作，必填
     */
    String inExp();

    /**
     * 出院分片表操作，必填
     */
    String outExp() default "";

    /**
     * 未知患者状态时，在院分片表的操作
     */
    String inExpWhenUnknown() default "";

    /**
     * 未知患者状态时，出院分片表的操作
     */
    String outExpWhenUnknown() default "";

    /**
     * 在院分片表操作前置校验
     */
    String inPreCheckExp() default "";

    /**
     * 出院分片表操作前置校验
     */
    String outPreCheckExp() default "";

    /**
     * 结果比较器类
     */
    Class<? extends IResultComparator> comparatorClass() default DefaultResultComparator.class;

    /**
     * 未知患者状态时，查询出院表范围，-1为不限制
     */
    int unknownRecentlyOutMonths() default -1;

}
