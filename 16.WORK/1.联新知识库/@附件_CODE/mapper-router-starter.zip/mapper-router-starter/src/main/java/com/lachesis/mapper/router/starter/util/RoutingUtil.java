package com.lachesis.mapper.router.starter.util;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.CharsetUtil;
import cn.hutool.core.util.StrUtil;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.SystemMetaObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class RoutingUtil {

    private static final String SOURCE_MAPPER_DIR = "D:\\IP1\\workspace\\emr\\windranger-emr-service\\src\\main\\java\\com\\lachesis\\windranger\\emr\\dao";
    private static final String SOURCE_MAPPING_DIR = "D:\\IP1\\workspace\\emr\\windranger-emr-service\\src\\main\\java\\com\\lachesis\\windranger\\emr\\mapping";
    private static final String TARGET_MAPPER_DIR = "D:\\IP1\\workspace\\emr\\windranger-emr-service\\src\\main\\java\\com\\lachesis\\windranger\\emr\\newdao";
    // private static final String TARGET_MAPPER_DIR = "D:\\IP1\\workspace\\emr\\windranger-emr-service\\src\\main\\java";
    private static final String TARGET_MAPPING_DIR = "D:\\IP1\\workspace\\emr\\windranger-emr-service\\src\\main\\java\\com\\lachesis\\windranger\\emr\\newmapping";
    private static final boolean COPY_IS_OVERRIDE = true;
    private static final String OLD_DAO_PACKAGE_PATH = "com.lachesis.windranger.emr.dao";
    private static final String NEW_DAO_PACKAGE_PATH = "com.lachesis.windranger.emr.newdao";
    private static final String OLD_DAO_PATH_TEMPLATE = "com.lachesis.windranger.emr.dao.%s";
    private static final String OLD_DAO_SUFFIX = "Mapper";

    private static final String NEW_SHARDING_DAO_SUFFIX = "ShardingMapper";
    private static final String NEW_SINGLE_DAO_SUFFIX = "SingleMapper";

    private static final List<String> SHARDING_TABLE_NAMES = new ArrayList<>();

    static {
        SHARDING_TABLE_NAMES.add("PatInhosOrderMapper");
        SHARDING_TABLE_NAMES.add("PatInhosOrderMapperExt");
        SHARDING_TABLE_NAMES.add("PatInhosOrderMapperExtV2");
        SHARDING_TABLE_NAMES.add("PatInhosOrderMapperPro");
        SHARDING_TABLE_NAMES.add("PatInhosOrderGroupMapper");
        SHARDING_TABLE_NAMES.add("PatInhosOrderGroupMapperExt");
        SHARDING_TABLE_NAMES.add("PatInhosOrderGroupMapperExtV2");
    }

    private static final Function<String, String> FILE_RENAME_FUNCTION = line -> line.replace(OLD_DAO_SUFFIX,
        containsSharding(line) ? NEW_SHARDING_DAO_SUFFIX : NEW_SINGLE_DAO_SUFFIX);

    private static boolean containsSharding(String line) {
        for (String shardingTableName : SHARDING_TABLE_NAMES) {
            if (line.contains(shardingTableName)) {
                return true;
            }
        }
        return false;
    }

    private static final Function<String, String> PACKAGE_RENAME_FUNCTION = originalName -> originalName.replace(OLD_DAO_PACKAGE_PATH, NEW_DAO_PACKAGE_PATH);

    public static void main(String[] args) throws Exception {
        File sourceMapperDir = fileOfPath(SOURCE_MAPPER_DIR);
        File sourceMappingDir = fileOfPath(SOURCE_MAPPING_DIR);
        File targetMapperDir = fileOfPathAndCreateWhenNotExists(TARGET_MAPPER_DIR, false);
        File targetMappingDir = fileOfPathAndCreateWhenNotExists(TARGET_MAPPING_DIR, false);
        moveV2(sourceMapperDir, targetMapperDir);
        moveV2(sourceMappingDir, targetMappingDir);
    }

    public static String replaceName(String name) {
        return FILE_RENAME_FUNCTION.apply(name);
    }

    public static boolean isShardingMapper(MapperRouterInvocation invocation) {
        return SHARDING_TABLE_NAMES.contains(invocation.getMapperClassName());
    }

    private static <T> T extractName(Object object, String path, Class<T> clazz, T defaultValue) {
        if (StrUtil.isEmpty(path)) {
            return defaultValue;
        }
        if (object == null) {
            return defaultValue;
        }
        String[] pathNodes = StrUtil.split(path, StrUtil.DOT).toArray(new String[0]);
        for (int i = 0; i < pathNodes.length; i++) {
            Object obj = doExtract(object, pathNodes[i]);
            if (i == pathNodes.length - 1) {
                return clazz.cast(obj);
            } else {
                object = obj;
            }
        }
        return defaultValue;
    }

    private static Object doExtract(Object object, String pathNode) {
        MetaObject metaObject = SystemMetaObject.forObject(object);
        return metaObject.getValue(pathNode);
    }

    private static void moveV2(File sourceDir, File targetDir) {
        File[] files = sourceDir.listFiles();
        long start = System.currentTimeMillis();
        // 时间原因，这里写的比较简单，实现功能即可~
        System.out.println("复制源目录文件到目标目录 === > 开始");
        if (ArrayUtil.isNotEmpty(files)) {
            for (File file : files) {
                String extName = FileUtil.extName(file);
                String mainName = FileUtil.mainName(file);
                String targetMainName = FILE_RENAME_FUNCTION.apply(mainName);
                String targetFilename = targetMainName + StrUtil.DOT + extName;
                List<String> lines = FileUtil.readLines(file, CharsetUtil.CHARSET_UTF_8);
                List<String> writeLines = new ArrayList<>();
                List<String> readLines = new ArrayList<>();
                int importEndIndex = 0;
                boolean hasAnno = false;
                for (int i = 0; i < lines.size(); i++) {
                    String line = lines.get(i);
                    readLines.add(line);
                    if (line.startsWith("package")) {
                        line = PACKAGE_RENAME_FUNCTION.apply(line);
                    } else if (line.startsWith("public interface")) {
                        if (!hasAnno && line.contains("ICrudGenericDAO")) {
                            readLines.add(importEndIndex + 1, "import org.springframework.context.annotation.Primary;");
                            readLines.add(i + 1, "@Primary");
                        }
                    } else if (line.contains("namespace=")) {
                        line = PACKAGE_RENAME_FUNCTION.apply(line);
                        if (line.contains(mainName)) {
                            line = line.replace(mainName, targetMainName);
                        }
                    } else if (line.startsWith("import")) {
                        if (line.contains("import org.springframework.context.annotation.Primary;")) {
                            continue;
                        }
                        importEndIndex = i;
                    } else if (line.startsWith("@Primary")) {
                        hasAnno = true;
                        continue;
                    }

                    if (line.contains(OLD_DAO_PACKAGE_PATH)) {
                        line = PACKAGE_RENAME_FUNCTION.apply(line);
                    }

                    // 改名，但前提需保证幂等
                    if (!line.contains(NEW_SINGLE_DAO_SUFFIX) && !line.contains(NEW_SHARDING_DAO_SUFFIX)) {
                        if (line.contains(OLD_DAO_SUFFIX)) {
                            line = FILE_RENAME_FUNCTION.apply(line);
                        }
                    }
                    writeLines.add(line);
                }
                writeLines(writeLines, FileUtil.file(targetDir.getPath(), targetFilename));
                writeLines(readLines, file);
            }
        }
        System.out.printf("复制源目录文件到目标目录 === > 结束:耗时=%sms|数量=%s%n", (System.currentTimeMillis() - start), files.length);
    }

    private static void writeLines(List<String> lines, File file) {
        // 清空
        FileUtil.writeBytes(new byte[]{}, file);
        for (int i = 0; i < lines.size(); i++) {
            String readline = lines.get(i);
            if (i != lines.size() - 1) {
                readline = readline + FileUtil.getLineSeparator();
            }
            FileUtil.appendString(readline, file, CharsetUtil.CHARSET_UTF_8);
        }
    }

    private static void move(File sourceDir, File targetDir) {
        long start = System.currentTimeMillis();
        System.out.println("复制源目录文件到目标目录 === > 开始");
        System.out.printf("SOURCE目录:%s%n", sourceDir.getAbsolutePath());
        System.out.printf("TARGET目录:%s%n", targetDir.getAbsolutePath());
        FileUtil.copyFilesFromDir(sourceDir, targetDir, COPY_IS_OVERRIDE);
        System.out.printf("复制源目录文件到目标目录 === > 结束: 耗时=%sms%n", (System.currentTimeMillis() - start));
    }

    private static File fileOfPath(String dir) throws FileNotFoundException {
        File file = FileUtil.file(dir);
        if (!file.exists()) {
            throw new FileNotFoundException(SOURCE_MAPPER_DIR);
        }
        return file;
    }

    /**
     * 不存在会自动创建，存在，即返回
     *
     * @param dir        文件目录
     * @param isCleanDir 是否清空文件目录下的所有文件
     * @return 文件
     */
    private static File fileOfPathAndCreateWhenNotExists(String dir, boolean isCleanDir) {
        if (isCleanDir) {
            System.out.println("清空目录:" + dir);
            FileUtil.del(dir);
        }
        return FileUtil.mkdir(dir);
    }
}
