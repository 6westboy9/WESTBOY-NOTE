package com.lachesis.mapper.router.starter.core.handler.newhandler.executor.base;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.lang.Validator;
import com.lachesis.mapper.router.starter.biz.newhandler.executor.IEmptyBizShardingExecutor;
import com.lachesis.mapper.router.starter.constant.ParamType;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteCase;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBizShardingExecutor;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBaseShardingExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class EmptyBaseShardingExecutor implements IBaseShardingExecutor {

    private final Map<ParamType, IEmptyBizShardingExecutor> map = new ConcurrentHashMap<>();

    @Autowired
    public EmptyBaseShardingExecutor(List<IEmptyBizShardingExecutor> shardingExecutorList) {
        if (CollUtil.isEmpty(shardingExecutorList)) {
            return;
        }
        shardingExecutorList.forEach(shardingExecutor -> map.put(shardingExecutor.paramType(), shardingExecutor));
    }

    @Override
    public ExecuteCase getCase() {
        return ExecuteCase.EMPTY;
    }

    @Override
    public Object execute(ExecuteContext context) throws Exception {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        Validator.validateNull(context.getItem(), "item参数必须为空");
        Validator.validateNull(context.getItems(), "items参数必须为空");
        IBizShardingExecutor bizShardingExecutor = map.get(methodAnno.getParamType());
        return bizShardingExecutor.execute(context);
    }
}
