package com.lachesis.mapper.router.starter.transform;

public enum DataCarrierAction {
    FROM_OUT_TO_IN,
    FROM_IN_TO_OUT
}
