package com.lachesis.mapper.router.starter.core;

import com.lachesis.mapper.router.starter.comparator.ResComparatorEnum;
import com.lachesis.mapper.router.starter.util.ReturnTypeUtil;
import lombok.Data;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.expression.AnnotatedElementKey;
import sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl;

import java.lang.reflect.Method;
import java.lang.reflect.Type;

@Data
public class MapperRouterInvocation {

    private ProceedingJoinPoint joinPoint;
    private Object mapperProxy;
    private Class<?> mapperClass;
    private String mapperClassName;
    private Method method;
    private String methodId;
    private Object[] args;

    public static MapperRouterInvocation newInstance(ProceedingJoinPoint joinPoint) {
        MapperRouterInvocation invocation = new MapperRouterInvocation();
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();
        Object[] args = joinPoint.getArgs();
        Object target = joinPoint.getTarget();
        invocation.setJoinPoint(joinPoint);
        invocation.setMapperProxy(target);
        invocation.setArgs(args);
        Class<?> declaringClass = method.getDeclaringClass();
        invocation.setMapperClass(declaringClass);
        invocation.setMapperClassName(declaringClass.getSimpleName());
        invocation.setMethod(method);
        invocation.setMethodId(method.toString());
        return invocation;
    }

    public Object doInvoke() throws Throwable {
        return joinPoint.proceed();
    }

    public AnnotatedElementKey getElementKey() {
        return new AnnotatedElementKey(method, mapperClass);
    }

    public boolean isList() {
        return ReturnTypeUtil.isList(method.getReturnType());
    }

    public boolean isSet() {
        return ReturnTypeUtil.isSet(method.getReturnType());
    }

    public boolean isInteger() {
        return ReturnTypeUtil.isInteger(method.getReturnType());
    }

    public boolean isLong() {
        return ReturnTypeUtil.isLong(method.getReturnType());
    }

    public boolean isString() {
        return ReturnTypeUtil.isString(method.getReturnType());
    }

    public boolean isVoid() {
        return ReturnTypeUtil.isVoid(method.getReturnType());
    }

    public boolean genericIsString() {
        Type genericReturnType = method.getGenericReturnType();
        Type actualType = ((ParameterizedTypeImpl) genericReturnType).getActualTypeArguments()[0];
        return actualType == String.class;
    }

    public ResComparatorEnum getComparatorEnum() {
        if (isList()) {
            if (genericIsString()) {
                return ResComparatorEnum.STRING_LIST;
            } else {
                return ResComparatorEnum.OBJECT_LIST;
            }
        } else if (isSet()) {
            if (genericIsString()) {
                return ResComparatorEnum.STRING_SET;
            }
        } else if (isInteger()) {
            return ResComparatorEnum.INTEGER;
        } else if (isLong()) {
            return ResComparatorEnum.LONG;
        } else if (isString()) {
            return ResComparatorEnum.STRING;
        }
        return ResComparatorEnum.OBJECT;
    }
}
