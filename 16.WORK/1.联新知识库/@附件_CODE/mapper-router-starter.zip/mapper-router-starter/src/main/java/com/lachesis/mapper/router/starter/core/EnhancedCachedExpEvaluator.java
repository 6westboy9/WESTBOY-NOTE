package com.lachesis.mapper.router.starter.core;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.context.expression.AnnotatedElementKey;
import org.springframework.context.expression.BeanFactoryResolver;
import org.springframework.context.expression.CachedExpressionEvaluator;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class EnhancedCachedExpEvaluator extends CachedExpressionEvaluator implements BeanFactoryAware {

    private static final Map<ExpressionKey, Expression> KEY_CACHE = new ConcurrentHashMap<>();
    private BeanFactory beanFactory;

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    public ExpEvalContext createEvalContext(MapperRouterInvocation invocation) {
        ExpEvalContext context = new ExpEvalContext(invocation, super.getParameterNameDiscoverer());
        if (beanFactory != null) {
            context.setBeanResolver(new BeanFactoryResolver(beanFactory));
        }
        return context;
    }

    public Object doParseExp(String exp, AnnotatedElementKey methodKey, EvaluationContext evalContext) {
        try {
            Expression expression = getExpression(KEY_CACHE, methodKey, exp);
            return expression.getValue(evalContext);
        } catch (Exception e) {
            log.error("表达式解析异常:expression={},method={}", exp, methodKey.toString(), e);
            throw e;
        }
    }

    public <T> T doParseExp(String exp, AnnotatedElementKey methodKey, EvaluationContext evalContext, Class<T> clazz) {
        try {
            Expression expression = getExpression(KEY_CACHE, methodKey, exp);
            return expression.getValue(evalContext, clazz);
        } catch (Exception e) {
            log.error("表达式解析异常:expression={},method={}", exp, methodKey.toString(), e);
            throw e;
        }
    }
}
