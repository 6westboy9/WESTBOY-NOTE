package com.lachesis.mapper.router.starter.transform;

import cn.hutool.extra.spring.SpringUtil;
import com.lachesis.mapper.router.starter.biz.PatInfo;
import com.lachesis.mapper.router.starter.biz.PatInfos;
import com.lachesis.mapper.router.starter.biz.SplitResult;

import java.util.Map;

public class PatDataCarrierWorker {

    private final PatInfos patInfos;
    private final DataCarrierManager dataCarrierManager;

    public PatDataCarrierWorker(PatInfos patInfos) {
        this.patInfos = patInfos;
        this.dataCarrierManager = SpringUtil.getBean(DataCarrierManager.class);
    }

    public void transDataIfPossible(PatInfos patInfos) {

    }
}
