package com.lachesis.mapper.router.starter.monitor;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.map.MapUtil;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MapperRouterTimeline {

    private static final String LOG_FORMAT1 = "[%s][%s][%s]";
    private static final String LOG_FORMAT2 = "[%s][%s][%s]:consume=%sms";
    private final Map<String, MapperRouterStageLog> logMap = new LinkedHashMap<>();

    public static MapperRouterTimeline newInstance() {
        return new MapperRouterTimeline();
    }

    public void add(Stage stage, Tag tag) {
        MapperRouterStageLog log = new MapperRouterStageLog();
        log.setStage(stage);
        log.setTag(tag);
        DateTime now = DateUtil.date();
        long currentTime = now.getTime();
        log.setTime(currentTime);
        String dateStr = DateUtil.format(now, DatePattern.NORM_DATETIME_MS_PATTERN);
        String desc = "";
        switch (tag) {
            case BEGIN:
                desc = String.format(LOG_FORMAT1, dateStr, stage.getStageName(), tag.getTagName());
                break;
            case END:
            case ERROR:
                MapperRouterStageLog beginLog = logMap.get(keyOf(stage, Tag.BEGIN));
                long consume = currentTime - beginLog.getTime();
                log.setConsume(consume);
                desc = String.format(LOG_FORMAT2, dateStr, stage.getStageName(), tag.getTagName(), consume);

        }
        log.setDesc(desc);
        logMap.put(keyOf(stage, tag), log);
    }

    public List<String> generateTimeLineList() {
        if (MapUtil.isEmpty(logMap)) {
            return Collections.emptyList();
        }
        return logMap.values()
            .stream().map(MapperRouterStageLog::getDesc)
            .collect(Collectors.toList());
    }

    private String keyOf(Stage stage, Tag tag) {
        return String.format("%s:%s", stage.getStageName(), tag.getTagName());
    }

    public long getConsume(Stage stage) {
        MapperRouterStageLog endStageLog = logMap.get(keyOf(stage, Tag.END));
        if (endStageLog != null) {
            return endStageLog.getConsume();
        }
        return -1;
    }
}
