package com.lachesis.mapper.router.starter.core.handler.newhandler.executor;

import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor
public enum ExecuteCase {

    NO_CONFIG("[解析参数前] => 没配置参数"),
    /**
     * 与NO_CONFIG不同，NO_CONFIG是压根就没有配置参数解析表达式，而EMPTY是配置了解析表达式，只是解析结果为空
     */
    EMPTY("[解析参数后] => 参数为空"),
    SINGLE("[解析参数后] => 解析为单个"),
    MULTIPLE("[解析参数后] => 解析为多个"),
    ERROR("除了上述之外的其它情况");

    private final String desc;

}
