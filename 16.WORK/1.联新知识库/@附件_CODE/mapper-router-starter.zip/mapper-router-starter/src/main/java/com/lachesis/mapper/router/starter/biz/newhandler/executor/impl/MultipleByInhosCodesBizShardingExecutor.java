package com.lachesis.mapper.router.starter.biz.newhandler.executor.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.lachesis.mapper.router.starter.biz.IPatInhosRecordHelper;
import com.lachesis.mapper.router.starter.biz.SimpleRecord;
import com.lachesis.mapper.router.starter.biz.newhandler.executor.IInhosCodeBizShardingExecutor;
import com.lachesis.mapper.router.starter.biz.newhandler.executor.IMultipleBizShardingExecutor;
import com.lachesis.mapper.router.starter.constant.InnerVariable;
import com.lachesis.mapper.router.starter.constant.ParamType;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.AsyncShardingExecutor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

@Slf4j
@Component
@Setter(onMethod_ = @Autowired)
public class MultipleByInhosCodesBizShardingExecutor implements IMultipleBizShardingExecutor, IInhosCodeBizShardingExecutor {

    private IPatInhosRecordHelper recordHelper;

    @Override
    public Object execute(ExecuteContext context) throws Exception {
        // 不可能为空
        List<String> inhosCodes = context.getItems();
        List<SimpleRecord> records = recordHelper.listByInhosCodes(inhosCodes);
        if (CollUtil.isEmpty(records)) {
            log.error("患者不存在[inhosCodes={}]", inhosCodes);
            context.setUnknownItems(inhosCodes);
            return doUnknown(context);
        }

        Map<String, SimpleRecord> recordMap = records.stream().collect(Collectors.toMap(SimpleRecord::getInhosCode, r -> r, (r1, r2) -> r1));

        Date minOutDate = null;
        Date maxOutDate = null;
        List<String> outInhosCodes = new ArrayList<>();
        List<String> inInhosCodes = new ArrayList<>();
        List<String> unknownInhosCodes = new ArrayList<>();
        Map<String, Date> outDateMap = new HashMap<>();

        for (String inhosCode : inhosCodes) {
            SimpleRecord record = recordMap.get(inhosCode);
            if (record == null) {
                unknownInhosCodes.add(inhosCode);
                continue;
            }
            if (record.isOut()) {
                outDateMap.put(record.getInhosCode(), record.getOutDate());
                if (minOutDate == null) {
                    minOutDate = record.getOutDate();
                    maxOutDate = record.getOutDate();
                } else {
                    if (DateUtil.compare(record.getOutDate(), minOutDate) < 0) {
                        minOutDate = record.getOutDate();
                    }
                    if (DateUtil.compare(record.getOutDate(), maxOutDate) > 0) {
                        maxOutDate = record.getOutDate();
                    }
                }
                outInhosCodes.add(record.getInhosCode());
            } else {
                inInhosCodes.add(record.getInhosCode());
            }
        }

        Future<Object> outResFuture = null;
        Future<Object> inResFuture = null;
        Object unknownRes = null;
        Object finalRes = null;
        MapperRouterInvocation invocation = context.getInvocation();
        if (CollUtil.isNotEmpty(unknownInhosCodes)) {
            // 暂时对这一部分数据不做处理
            context.setUnknownItems(unknownInhosCodes);
            unknownRes = doUnknown(context);
            finalRes = aggregateRes(invocation, finalRes, unknownRes);
            log.warn("患者不存在[inhosCodes={}]", unknownInhosCodes);
        }

        context.setInnerVar(InnerVariable.OUT_DATE_MAP, outDateMap);

        if (CollUtil.isNotEmpty(outInhosCodes)) {
            context.setInnerVar(InnerVariable.OUT_INHOS_CODES, outInhosCodes);
            context.setInnerVar(InnerVariable.MIN_OUT_DATE, minOutDate);
            context.setInnerVar(InnerVariable.MAX_OUT_DATE, maxOutDate);
            Object outRes = executeOutExp(context);
            finalRes = aggregateRes(invocation, finalRes, outRes);
            // outResFuture = AsyncShardingExecutor.submit(() -> executeOutExp(context));
        }

        if (CollUtil.isNotEmpty(inInhosCodes)) {
            context.setInnerVar(InnerVariable.IN_INHOS_CODES, inInhosCodes);
            Object inRes = executeInExp(context);
            finalRes = aggregateRes(invocation, finalRes, inRes);
            // inResFuture = AsyncShardingExecutor.submit(() -> executeInExp(context));
        }

        // if (outResFuture != null) {
        //     finalRes = aggregateRes(invocation, finalRes, outResFuture.get());
        // }
        // if (inResFuture != null) {
        //     finalRes = aggregateRes(invocation, finalRes, inResFuture.get());
        // }
        return finalRes;
    }

    @Override
    public ParamType paramType() {
        return ParamType.INHOS_CODE;
    }
}
