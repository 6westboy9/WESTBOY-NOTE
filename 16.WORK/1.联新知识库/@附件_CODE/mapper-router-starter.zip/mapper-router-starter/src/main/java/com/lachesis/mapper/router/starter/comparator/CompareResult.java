package com.lachesis.mapper.router.starter.comparator;

import com.lachesis.mapper.router.starter.constant.CompareErrEnum;
import lombok.Data;

@Data
public class CompareResult {

    private boolean success;
    private String message;

    public static CompareResult newSuccess() {
        CompareResult compareResult = new CompareResult();
        compareResult.setSuccess(true);
        return compareResult;
    }

    public static CompareResult newFail(CompareErrEnum errEnum, Object... params) {
        CompareResult compareResult = new CompareResult();
        compareResult.setSuccess(false);
        String message = errEnum.getMessage();
        if (errEnum.isNeedParams()) {
            message = String.format(message, params);
        }
        compareResult.setMessage(message);
        return compareResult;
    }
}
