package com.lachesis.mapper.router.starter.core.handler.newhandler;

import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import com.lachesis.mapper.router.starter.core.handler.IMapperHandler;
import com.lachesis.mapper.router.starter.util.RoutingUtil;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Slf4j
@Component
@Setter(onMethod_ = @Autowired)
public class SingleMapperHandler implements IMapperHandler {

    @Override
    public Object handle(MapperRouterContext context) throws Throwable {
        String mapperClassName = "";
        String singleBeanName = "";
        String methodName = "";
        try {
            MapperRouterInvocation invocation = context.getInvocation();
            mapperClassName = invocation.getMapperClassName();
            singleBeanName = StrUtil.lowerFirst(RoutingUtil.replaceName(mapperClassName));
            Object singleBean = SpringUtil.getBean(singleBeanName);
            Class<?> aClass = singleBean.getClass();
            Method method = invocation.getMethod();
            methodName = method.getName();
            Class<?>[] parameterTypes = method.getParameterTypes();
            Method singleMethod = aClass.getDeclaredMethod(methodName, parameterTypes);
            singleMethod.setAccessible(true);
            return singleMethod.invoke(singleBean, invocation.getArgs());
        } catch (Exception e) {
            log.error("单表执行异常: mapperName={}, beanName={}， methodName={}", mapperClassName, singleBeanName, methodName, e);
            throw e;
        }
    }
}
