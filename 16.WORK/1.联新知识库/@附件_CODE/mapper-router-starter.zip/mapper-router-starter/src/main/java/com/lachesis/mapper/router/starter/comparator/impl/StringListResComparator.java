package com.lachesis.mapper.router.starter.comparator.impl;

import com.lachesis.mapper.router.starter.comparator.AbstractResComparator;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Setter(onMethod_ = @Autowired)
public class StringListResComparator extends AbstractListResComparator<String> {

    private StringResComparator comparator;

    @Override
    public AbstractResComparator<String> getComparator() {
        return comparator;
    }
}
