package com.lachesis.mapper.router.starter.biz;

import lombok.Getter;

@Getter
public class SplitResult {

    private final PatInfos inPatInfos = PatInfos.newInstance();
    private final PatInfos outPatInfos = PatInfos.newInstance();

    public void addIn(PatInfo patInfo) {
        inPatInfos.add(patInfo);
    }

    public void addOut(PatInfo patInfo) {
        outPatInfos.add(patInfo);
    }
}
