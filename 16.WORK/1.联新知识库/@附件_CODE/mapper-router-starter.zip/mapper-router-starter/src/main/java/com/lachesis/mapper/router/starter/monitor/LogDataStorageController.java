package com.lachesis.mapper.router.starter.monitor;

import com.lachesis.mapper.router.starter.storage.mongo.data.MapperRouterLogInfo;
import com.lachesis.mapper.router.starter.storage.mongo.MongoLogDataStorage;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Setter(onMethod_ = @Autowired)
public class LogDataStorageController {

    // 先写死了~
    private MongoLogDataStorage mongoLogDataStorage;

    public void saveLog(MapperRouterLogInfo logData) {
        mongoLogDataStorage.asyncSave(logData);
    }

}
