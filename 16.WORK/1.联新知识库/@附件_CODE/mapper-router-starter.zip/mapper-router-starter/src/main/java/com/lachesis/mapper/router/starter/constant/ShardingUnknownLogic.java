package com.lachesis.mapper.router.starter.constant;

public enum ShardingUnknownLogic {

    /**
     * 仅对在院表进行操作
     */
    ONLY_IN,
    /**
     * 仅对出院表进行操作
     */
    ONLY_OUT,
    /**
     * 对在院和出院表均进行操作，对于返回结果会进行聚合
     */
    ALL,
    /**
     * 对在院和最近两个月出院表均进行操作，对于返回结果会进行聚合
     */
    IN_AND_RECENTLY_OUT,
    /**
     * 忽略
     */
    IGNORE
}
