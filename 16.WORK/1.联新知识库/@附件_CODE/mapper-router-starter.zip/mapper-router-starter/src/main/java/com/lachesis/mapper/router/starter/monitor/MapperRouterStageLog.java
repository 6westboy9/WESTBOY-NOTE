package com.lachesis.mapper.router.starter.monitor;

import lombok.Data;

@Data
public class MapperRouterStageLog {
    private Stage stage;
    private Tag tag;
    /**
     * 记录当前时间
     */
    private long time;
    /**
     * 默认值
     */
    private long consume = -1;
    private String desc;
}
