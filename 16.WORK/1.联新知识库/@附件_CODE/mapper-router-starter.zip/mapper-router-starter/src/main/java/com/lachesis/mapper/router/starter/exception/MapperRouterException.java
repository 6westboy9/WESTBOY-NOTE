package com.lachesis.mapper.router.starter.exception;

public class MapperRouterException extends RuntimeException {

    public MapperRouterException() {
    }

    public MapperRouterException(String message) {
        super(message);
    }

    public MapperRouterException(String message, Throwable cause) {
        super(message, cause);
    }

    public MapperRouterException(Throwable cause) {
        super(cause);
    }

    public MapperRouterException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
