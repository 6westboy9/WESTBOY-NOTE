package com.lachesis.mapper.router.starter.core.handler.newhandler.executor.base;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.lang.Validator;
import com.lachesis.mapper.router.starter.constant.ParamType;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;
import com.lachesis.mapper.router.starter.biz.newhandler.executor.IMultipleBizShardingExecutor;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteCase;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBaseShardingExecutor;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBizShardingExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class MultipleBaseShardingExecutor implements IBaseShardingExecutor {

    private final Map<ParamType, IMultipleBizShardingExecutor> map = new HashMap<>();

    @Autowired
    public MultipleBaseShardingExecutor(List<IMultipleBizShardingExecutor> shardingExecutorList) {
        if (CollUtil.isEmpty(shardingExecutorList)) {
            return;
        }
        shardingExecutorList.forEach(shardingExecutor -> map.put(shardingExecutor.paramType(), shardingExecutor));
    }

    @Override
    public ExecuteCase getCase() {
        return ExecuteCase.MULTIPLE;
    }

    @Override
    public Object execute(ExecuteContext context) throws Exception {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        List<String> items = context.getItems();
        Validator.validateTrue(CollUtil.isNotEmpty(items), "items参数不能为空");
        IBizShardingExecutor bizShardingExecutor = map.get(methodAnno.getParamType());
        return bizShardingExecutor.execute(context);
    }
}
