package com.lachesis.mapper.router.starter.comparator.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.lachesis.mapper.router.starter.comparator.AbstractResComparator;
import com.lachesis.mapper.router.starter.comparator.CompareResult;
import com.lachesis.mapper.router.starter.constant.CompareErrEnum;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.builder.Diff;
import org.apache.commons.lang3.builder.DiffResult;
import org.apache.commons.lang3.builder.ReflectionDiffBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Slf4j
@Component
public class ObjectResComparator extends AbstractResComparator<Object> {

    private static final Set<String> FILTER_FIELDS = new HashSet<>();

    static {
        FILTER_FIELDS.add("beanComparotor");
    }

    @Override
    public Object castAndClone(Object res) {
        return res;
    }

    @Override
    public CompareResult doCompare(MapperRouterContext context, @NonNull Object oldRes, @NonNull Object newRes) {
        ReflectionDiffBuilder diffBuilder = new ReflectionDiffBuilder(oldRes, newRes, ToStringStyle.DEFAULT_STYLE);
        DiffResult diffResult = diffBuilder.build();
        if (CollUtil.isNotEmpty(diffResult.getDiffs())) {
            for (Diff<?> diff : diffResult.getDiffs()) {
                if (FILTER_FIELDS.contains(diff.getFieldName())) {
                    continue;
                }
                return CompareResult.newFail(CompareErrEnum.RES_NE, JSONUtil.toJsonStr(oldRes), JSONUtil.toJsonStr(newRes));
            }
        }
        return CompareResult.newSuccess();
    }
}
