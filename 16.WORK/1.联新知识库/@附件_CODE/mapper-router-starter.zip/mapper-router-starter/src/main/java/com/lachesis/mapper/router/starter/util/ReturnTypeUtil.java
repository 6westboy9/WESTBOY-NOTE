package com.lachesis.mapper.router.starter.util;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Set;

public class ReturnTypeUtil {

    public static boolean isVoid(Class<?> clazz) {
        return clazz.isAssignableFrom(void.class) || clazz.isAssignableFrom(Void.class);
    }

    public static boolean isList(Class<?> clazz) {
        return clazz.isAssignableFrom(List.class);
    }

    public static boolean isSet(Class<?> clazz) {
        return clazz.isAssignableFrom(Set.class);
    }

    public static boolean isLong(Class<?> clazz) {
        return clazz.isAssignableFrom(Long.class) || clazz.isAssignableFrom(long.class);
    }

    public static boolean isInteger(Class<?> clazz) {
        return clazz.isAssignableFrom(Integer.class) || clazz.isAssignableFrom(int.class);
    }

    public static boolean isString(Class<?> clazz) {
        return clazz.isAssignableFrom(String.class);
    }

    public static void main(String[] args) throws NoSuchMethodException {
        {
            Method method = ReturnTypeUtil.class.getMethod("testInt");
            Class<?> returnType = method.getReturnType();
            System.out.println(returnType);
            System.out.println(isInteger(returnType));
        }
        {
            Method method = ReturnTypeUtil.class.getMethod("testInteger");
            Class<?> returnType = method.getReturnType();
            System.out.println(returnType);
            System.out.println(isInteger(returnType));
        }
        {
            Method method = ReturnTypeUtil.class.getMethod("testStrList");
            Class<?> returnType = method.getReturnType();
            System.out.println(returnType);
            System.out.println(isList(returnType));

            Type genericReturnType = method.getGenericReturnType();
            System.out.println(genericReturnType);
            System.out.println(genericReturnType instanceof Class);
        }

    }

    public int testInt() {
        return 1;
    }

    public Integer testInteger() {
        return null;
    }

    public List<String> testStrList() {
        return null;
    }
}
