package com.lachesis.mapper.router.starter.comparator.impl;

import cn.hutool.core.util.StrUtil;
import com.lachesis.mapper.router.starter.comparator.AbstractResComparator;
import com.lachesis.mapper.router.starter.comparator.CompareResult;
import com.lachesis.mapper.router.starter.constant.CompareErrEnum;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class StringResComparator extends AbstractResComparator<String> {

    @Override
    public String castAndClone(Object res) {
        return (String) res;
    }

    @Override
    public CompareResult doCompare(MapperRouterContext context, @NonNull String oldRes, @NonNull String newRes) {
        if (!StrUtil.equals(oldRes, newRes)) {
            return CompareResult.newFail(CompareErrEnum.RES_NE, oldRes, newRes);
        }
        return CompareResult.newSuccess();
    }
}
