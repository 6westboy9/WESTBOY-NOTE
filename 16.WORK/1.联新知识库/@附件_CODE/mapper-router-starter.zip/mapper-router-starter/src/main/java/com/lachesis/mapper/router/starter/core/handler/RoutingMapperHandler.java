package com.lachesis.mapper.router.starter.core.handler;

import cn.hutool.core.thread.ThreadUtil;
import com.lachesis.mapper.router.starter.MapperRouterProperties;
import com.lachesis.mapper.router.starter.comparator.ResultCompareManager;
import com.lachesis.mapper.router.starter.constant.RouterMode;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.NewMapperHandler;
import com.lachesis.mapper.router.starter.core.handler.oldhandler.OldMapperHandler;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.concurrent.*;


@Slf4j
@Component
public class RoutingMapperHandler implements IMapperHandler {

    private ExecutorService executorService;

    @Setter(onMethod_ = @Autowired)
    private OldMapperHandler oldMapperHandler;
    @Setter(onMethod_ = @Autowired)
    private NewMapperHandler newMapperHandler;
    @Setter(onMethod_ = @Autowired)
    private ResultCompareManager resultCompareManager;
    @Setter(onMethod_ = @Autowired)
    private MapperRouterProperties properties;

    @PostConstruct
    public void init() {
        executorService = new ThreadPoolExecutor(properties.getHandlerCorePoolSize(),
            properties.getHandlerMaxPoolSize(),
            properties.getHandlerKeepAliveTime(), TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(properties.getHandlerQueueSize()),
            ThreadUtil.newNamedThreadFactory("MRHandler-", false), (r, executor) -> {
            log.info("执行异步任务饱和被拒绝由当前线程执行");
            r.run();
        });
    }

    @Override
    public Object handle(MapperRouterContext context) throws Throwable {
        Object result;
        HandlerTask oldHandlerTask;
        HandlerTask newHandlerTask;
        RouterMode strategy = context.getRoutingStrategy();
        long timeout = properties.getHandlerTimeout();
        switch (strategy) {
            case NEW:
                newHandlerTask = HandlerTask.newTask(newMapperHandler, context);
                submit(newHandlerTask);
                result = newHandlerTask.getRes(timeout);
                break;
            case ALL_RETURN_NEW:
            case ALL_RETURN_OLD:
                oldHandlerTask = HandlerTask.newTask(oldMapperHandler, context);
                newHandlerTask = HandlerTask.newTask(newMapperHandler, context);
                submit(oldHandlerTask);
                submit(newHandlerTask);
                Object oldRes = oldHandlerTask.getRes(timeout);
                Object newRes = newHandlerTask.getRes(timeout);
                resultCompareManager.compare(context, oldRes, newRes);
                result = RouterMode.ALL_RETURN_OLD.equals(strategy) ? oldRes : newRes;
                break;
            case OLD:
            default:
                oldHandlerTask = HandlerTask.newTask(oldMapperHandler, context);
                submit(oldHandlerTask);
                result = oldHandlerTask.getRes(timeout);
        }
        return result;
    }

    private void submit(HandlerTask task) {
        Future<Object> future = executorService.submit(task);
        task.setFuture(future);
    }
}
