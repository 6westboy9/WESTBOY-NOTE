package com.lachesis.mapper.router.starter.biz.newhandler.executor;

import cn.hutool.core.util.StrUtil;
import com.lachesis.mapper.router.starter.constant.InnerVariable;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBizShardingExecutor;

import java.util.List;

public interface IInhosCodeBizShardingExecutor extends IBizShardingExecutor {

    /**
     * 未知患者状态时，对于在院表前置操作
     *
     * @param context 执行上下文
     */
    @Override
    default void preExecuteInExpWhenUnknown(ExecuteContext context) {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        String inExpWhenUnknown = methodAnno.getInExpWhenUnknown();
        if (StrUtil.isEmpty(inExpWhenUnknown)) {
            inExpWhenUnknown = methodAnno.getInExp();
        }
        switch (methodAnno.getParamNum()) {
            case MULTIPLE:
                List<String> unknownItems = context.getUnknownItemsElseEmpty();
                context.setInnerVar(InnerVariable.UNKNOWN_INHOS_CODES, unknownItems);
                // 多个时，需要提取解析出来未知状态的参数值列表进行设置
                context.setInnerVar(InnerVariable.IN_INHOS_CODES, unknownItems);
                break;
            case NO:
            case SINGLE:
                // 单个时，直接使用解析参数参数就行
            default:
        }
        methodAnno.setInExpWhenUnknown(inExpWhenUnknown);
    }

    /**
     * 未知患者状态时，对于出院表前置操作
     *
     * @param context 执行上下文
     */
    @Override
    default void preExecuteOutExpWhenUnknown(ExecuteContext context) {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        String outExpWhenUnknown = methodAnno.getOutExpWhenUnknown();
        if (StrUtil.isEmpty(outExpWhenUnknown)) {
            outExpWhenUnknown = methodAnno.getOutExp();
        }
        switch (methodAnno.getParamNum()) {
            case SINGLE:
                // 因为ExpEvalContext上下问中设置为null时表示移除该属性，所以只能在表达式上做替换
                outExpWhenUnknown = outExpWhenUnknown.replace(InnerVariable.OUT_DATE.getExpName(), InnerVariable.OUT_DATE.getSpelDefaultValueExp());
                break;
            case MULTIPLE:
                List<String> unknownItems = context.getUnknownItemsElseEmpty();
                context.setInnerVar(InnerVariable.UNKNOWN_INHOS_CODES, unknownItems);
                // 多个时，需要提取解析出来未知状态的参数值列表进行设置
                context.setInnerVar(InnerVariable.OUT_INHOS_CODES, unknownItems);
                // 因为ExpEvalContext上下问中设置为null时表示移除该属性，所以只能在表达式上做替换
                outExpWhenUnknown = outExpWhenUnknown.replace(InnerVariable.MIN_OUT_DATE.getExpName(), InnerVariable.MIN_OUT_DATE.getSpelDefaultValueExp());
                outExpWhenUnknown = outExpWhenUnknown.replace(InnerVariable.MAX_OUT_DATE.getExpName(), InnerVariable.MAX_OUT_DATE.getSpelDefaultValueExp());
                outExpWhenUnknown = outExpWhenUnknown.replace(InnerVariable.OUT_DATE_MAP.getExpName(), InnerVariable.OUT_DATE_MAP.getSpelDefaultValueExp());
                break;
            case NO:
            default:
        }
        methodAnno.setOutExpWhenUnknown(outExpWhenUnknown);
    }

    /**
     * 未知患者状态时，对于出院表前置操作
     *
     * @param context 执行上下文
     */
    @Override
    default void preExecuteRecentlyOutExpWhenUnknown(ExecuteContext context) {
        MapperRouterMethodAnno methodAnno = context.getMethodAnno();
        String outExpWhenUnknown = methodAnno.getOutExpWhenUnknown();
        if (StrUtil.isEmpty(outExpWhenUnknown)) {
            outExpWhenUnknown = methodAnno.getOutExp();
        }

        switch (methodAnno.getParamNum()) {
            case SINGLE:
                // 因为ExpEvalContext上下问中设置为null时表示移除该属性，所以只能在表达式上做替换
                outExpWhenUnknown = outExpWhenUnknown.replace(InnerVariable.OUT_DATE.getExpName(), InnerVariable.OUT_DATE.getSpelDefaultValueExp());
                setOutRangeInnerVariable(context);
                break;
            case MULTIPLE:
                List<String> unknownItems = context.getUnknownItemsElseEmpty();
                context.setInnerVar(InnerVariable.UNKNOWN_INHOS_CODES, unknownItems);
                context.setInnerVar(InnerVariable.OUT_INHOS_CODES, unknownItems);
                setOutRangeInnerVariable(context);
                outExpWhenUnknown = outExpWhenUnknown.replace(InnerVariable.OUT_DATE_MAP.getExpName(), InnerVariable.OUT_DATE_MAP.getSpelDefaultValueExp());
                break;
            case NO:
            default:
        }
        methodAnno.setOutExpWhenUnknown(outExpWhenUnknown);
    }
}