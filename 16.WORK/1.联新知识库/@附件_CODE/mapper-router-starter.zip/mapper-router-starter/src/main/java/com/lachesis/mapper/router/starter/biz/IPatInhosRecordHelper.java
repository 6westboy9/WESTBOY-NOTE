package com.lachesis.mapper.router.starter.biz;

import java.util.Collection;
import java.util.List;

public interface IPatInhosRecordHelper {

    SimpleRecord getByInhosCode(String inhosCode);

    List<SimpleRecord> listByInhosCodes(Collection<String> inhosCodes);

}
