package com.lachesis.mapper.router.starter.monitor;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Stage {

    HANDLE_WITH_OLD_MODE("执行(旧链路)"),
    HANDLE_WITH_NEW_MODE("执行(新链路)"),
    COMPARE("比较");

    private final String stageName;
}
