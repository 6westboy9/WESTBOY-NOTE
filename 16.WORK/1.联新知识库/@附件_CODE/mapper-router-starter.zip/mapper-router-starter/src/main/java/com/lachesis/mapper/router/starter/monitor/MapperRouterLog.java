package com.lachesis.mapper.router.starter.monitor;

import cn.hutool.core.exceptions.ExceptionUtil;
import com.lachesis.mapper.router.starter.comparator.CompareResult;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteLog;
import com.lachesis.mapper.router.starter.storage.mongo.data.MapperRouterLogInfo;
import lombok.Data;

import java.util.Date;

@Data
public class MapperRouterLog {

    /**
     * Mapper接口名称
     */
    private String mapperName;
    /**
     * Mapper方法名，因为MyBatis中Mapper的方法名不会存在相同情况，所以mapperName和methodName一起可作为唯一标识
     */
    private String methodName;
    private String mode;
    /**
     * 操作来源：EMR，DATA_SYNC
     */
    private String source;
    /**
     * TLog的唯一标识
     */
    private String tLogId;
    /**
     * 开始时间
     */
    private long startTime;
    /**
     * 结束时间
     */
    private long endTime;
    /**
     * 耗时
     */
    private long consume;
    /**
     * 是否成功
     */
    private boolean success;
    /**
     * 参数信息
     */
    private Object[] args;
    /**
     * 比对结果
     */
    private CompareResult compareResult;
    /**
     * 异常信息
     */
    private Throwable throwable;
    /**
     * 时间线
     */
    private MapperRouterTimeline timeline;
    /**
     * 执行日志
     */
    private ExecuteLog executeLog;

    public void setEndTime(long endTime) {
        this.endTime = endTime;
        this.consume = endTime - startTime;
    }

    public void addTimeline(Stage stage, Tag tag) {
        timeline.add(stage, tag);
    }

    public void addTimeline(Stage stage, Tag tag, Throwable throwable) {
        if (throwable != null) {
            this.throwable = throwable;
            this.success = false;
        }
        timeline.add(stage, tag);
    }

    public MapperRouterLogInfo transform(boolean timelineEnable, int errorMsgMaxLength) {
        MapperRouterLogInfo logInfo = new MapperRouterLogInfo();
        logInfo.setMapperName(mapperName);
        logInfo.setMethodName(methodName);
        logInfo.setMapperMethodId(mapperName + "." + methodName);
        logInfo.setMode(mode);
        logInfo.setSource(source);
        logInfo.setTLogId(tLogId);
        logInfo.setStartTime(startTime);
        logInfo.setEndTime(endTime);
        logInfo.setConsume(consume);
        logInfo.setNewConsume(timeline.getConsume(Stage.HANDLE_WITH_NEW_MODE));
        logInfo.setOldConsume(timeline.getConsume(Stage.HANDLE_WITH_OLD_MODE));
        logInfo.setSuccess(success);
        logInfo.setArgs(args);
        logInfo.setCompareStatus(-1);
        if (compareResult != null) {
            logInfo.setCompareStatus(compareResult.isSuccess() ? 1 : 0);
            logInfo.setCompareMessage(compareResult.getMessage());
        }
        logInfo.setCompareConsume(timeline.getConsume(Stage.COMPARE));
        if (throwable != null) {
            logInfo.setErrorMsg(ExceptionUtil.stacktraceToString(throwable, errorMsgMaxLength));
        }
        if (timelineEnable) {
            logInfo.setTimelineList(timeline.generateTimeLineList());
        }
        if (executeLog != null) {
            logInfo.setExecuteLogInfo(executeLog.transform());
        }
        logInfo.setCreateTime(new Date());
        return logInfo;
    }
}
