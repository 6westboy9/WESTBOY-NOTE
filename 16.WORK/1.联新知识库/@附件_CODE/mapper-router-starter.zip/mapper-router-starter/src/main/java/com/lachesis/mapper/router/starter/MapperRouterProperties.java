package com.lachesis.mapper.router.starter;

import com.lachesis.mapper.router.starter.constant.RouterMode;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Setter
@Getter
@ConfigurationProperties(prefix = "mapper-router")
public class MapperRouterProperties {

    /**
     * 路由策略
     */
    @Value("${mode:OLD}")
    private String mode;
    /**
     * 使用该组件的应用名称
     */
    @Value("${user:${spring.application.name:}}")
    private String user;
    /**
     * 执行超时时间，单位是毫秒，默认10分钟
     */
    @Value("${handler-timeout:600000}")
    private long handlerTimeout;
    /**
     * 核心线程数
     */
    @Value("${handler-core-pool-size:20}")
    private int handlerCorePoolSize;
    /**
     * 最大线程数
     */
    @Value("${handler-max-pool-size:100}")
    private int handlerMaxPoolSize;
    /**
     * 单位是毫秒
     */
    @Value("${handler-keep-alive-time:60000}")
    private long handlerKeepAliveTime;
    /**
     * 队列大小
     */
    @Value("${handler-queue-size:1000}")
    private int handlerQueueSize;
    /**
     * 在不知到出院时间的情况下，操作出院表时限，默认为最近2个月，包括当前月
     */
    @Value("${handler-unknown-recently-out-months:2}")
    private int handlerUnknownRecentlyOutMonths;
    /**
     * 监控开启
     */
    @Value("${monitor-enable:false}")
    private boolean monitorEnable;
    /**
     * 监控慢操作时间，单位：毫秒，超过配置的时间后，就会记录
     */
    @Value("${monitor-longtime:1000}")
    private long monitorLongtime;
    /**
     * 监控记录中是否包含操作时间线
     */
    @Value("${monitor-timeline-enable:true}")
    private boolean monitorTimelineEnable;
    /**
     * 监控记录错误日志字符最大长度
     */
    @Value("${monitor-error-msg-max-length:5000}")
    private int monitorErrorMsgMaxLength;

    public RouterMode getMode() {
        return RouterMode.valueOf(mode.toUpperCase());
    }

}
