package com.lachesis.mapper.router.starter.biz;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public class PatInfos {

    private final Map<String, PatInfo> map = new HashMap<>();

    private PatInfos() {
    }

    public static PatInfos newInstance() {
        return new PatInfos();
    }

    public void add(PatInfo patInfo) {
        map.put(patInfo.getInhosCode(), patInfo);
    }

    public PatInfo get(String inhosCode) {
        return map.get(inhosCode);
    }

    public boolean isEmpty() {
        return map.isEmpty();
    }

    public SplitResult splitByStatus() {
        SplitResult splitResult = new SplitResult();
        map.forEach((s, patInfo) -> {
            SimpleRecord afterRecord = patInfo.getTargetRecord();
            if (afterRecord.isOut()) {
                splitResult.addOut(patInfo);
            } else {
                splitResult.addIn(patInfo);
            }
        });
        return splitResult;
    }

    public int patNum() {
        return map.keySet().size();
    }
}
