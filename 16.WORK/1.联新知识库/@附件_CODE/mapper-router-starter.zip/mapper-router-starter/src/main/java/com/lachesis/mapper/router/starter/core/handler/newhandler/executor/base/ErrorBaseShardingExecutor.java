package com.lachesis.mapper.router.starter.core.handler.newhandler.executor.base;

import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteCase;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.ExecuteContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.executor.IBaseShardingExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ErrorBaseShardingExecutor implements IBaseShardingExecutor {

    @Override
    public ExecuteCase getCase() {
        return ExecuteCase.ERROR;
    }

    @Override
    public Object execute(ExecuteContext context) {
        return null;
    }
}
