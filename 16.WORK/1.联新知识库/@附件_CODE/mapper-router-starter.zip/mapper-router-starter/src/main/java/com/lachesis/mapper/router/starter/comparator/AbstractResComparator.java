package com.lachesis.mapper.router.starter.comparator;

import cn.hutool.core.thread.ThreadUtil;
import com.alibaba.ttl.threadpool.TtlExecutors;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.*;

@Slf4j
public abstract class AbstractResComparator<T> implements IResultComparator {

    private static final ExecutorService COMPARE_THREAD_POOL = TtlExecutors.getTtlExecutorService(
        new ThreadPoolExecutor(5, 50, 60, TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(1000),
            ThreadUtil.newNamedThreadFactory("MRComparator-", true), (r, executor) -> {
            log.info("比对异步任务饱和被拒绝由当前线程执行");
            r.run();
        }));

    @Override
    public CompareResult compare(MapperRouterContext context, @NonNull Object oldRes, @NonNull Object newRes) {
        T cloneOldRes = castAndClone(oldRes);
        T cloneNewRes = castAndClone(oldRes);
        return doCompare(context, cloneOldRes, cloneNewRes);
    }

    public abstract T castAndClone(Object res);

    /**
     * 在此方法内不可使用RoutingContextManager#get获取上下文对象了，在执行异步操作后，所属当前线程的上下文对象已经被移除
     *
     * @param oldRes 旧链路操作结果
     * @param newRes 新链路操作结果
     */
    public abstract CompareResult doCompare(MapperRouterContext context,@NonNull T oldRes, @NonNull T newRes);

    // private class ComparatorTask implements Callable<CompareResult> {
    //
    //     private final T oldRes;
    //     private final T newRes;
    //
    //     public ComparatorTask(T oldRes, T newRes) {
    //         this.oldRes = oldRes;
    //         this.newRes = newRes;
    //     }
    //
    //     @Override
    //     public CompareResult call() throws Exception {
    //         return doCompare(oldRes, newRes);
    //     }
    // }
}
