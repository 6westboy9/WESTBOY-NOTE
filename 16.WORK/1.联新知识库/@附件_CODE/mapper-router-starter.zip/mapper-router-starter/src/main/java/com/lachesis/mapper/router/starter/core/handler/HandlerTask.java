package com.lachesis.mapper.router.starter.core.handler;

import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import com.lachesis.mapper.router.starter.core.handler.newhandler.NewMapperHandler;
import com.lachesis.mapper.router.starter.core.handler.oldhandler.OldMapperHandler;
import com.lachesis.mapper.router.starter.monitor.Stage;
import lombok.Setter;

import java.util.concurrent.*;

public class HandlerTask implements Callable<Object> {

    private final IMapperHandler mapperHandler;
    private final MapperRouterContext context;
    @Setter
    private Future<Object> future;

    public HandlerTask(IMapperHandler mapperHandler, MapperRouterContext context) {
        this.mapperHandler = mapperHandler;
        this.context = context;
    }

    public static HandlerTask newTask(IMapperHandler mapperHandler, MapperRouterContext context) {
        return new HandlerTask(mapperHandler, context);
    }

    @Override
    public Object call() throws Exception {
        try {
            return mapperHandler.handle(context);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public Object getRes(long timeoutSec) {
        try {
            return future.get(timeoutSec, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            // 新链路
            if (mapperHandler instanceof NewMapperHandler) {
                context.error(Stage.HANDLE_WITH_NEW_MODE, e);
            } else if (mapperHandler instanceof OldMapperHandler) {
                context.error(Stage.HANDLE_WITH_OLD_MODE, e);
            }
            throw new RuntimeException(e);
        }
    }
}
