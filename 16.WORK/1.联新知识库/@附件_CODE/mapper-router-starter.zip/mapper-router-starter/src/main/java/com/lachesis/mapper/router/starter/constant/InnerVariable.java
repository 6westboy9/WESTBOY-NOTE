package com.lachesis.mapper.router.starter.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum InnerVariable {

    INHOS_CODE("_inhosCode", "null"),
    INHOS_CODES("_inhosCodes", "new java.util.ArrayList()"),
    IN_INHOS_CODES("_inInhosCodes", "new java.util.ArrayList()"),
    OUT_INHOS_CODES("_outInhosCodes", "new java.util.ArrayList()"),
    UNKNOWN_INHOS_CODES("_unknownInhosCodes", "new java.util.ArrayList()"),
    MIN_OUT_DATE("_minOutDate", "null"),
    MAX_OUT_DATE("_maxOutDate", "null"),
    OUT_DATE("_outDate", "null"),
    OUT_DATE_MAP("_outDateMap", "new java.util.HashMap()");

    private final String innerName;
    private final String spelDefaultValueExp;

    public String getExpName() {
        return "#" + innerName;
    }
}
