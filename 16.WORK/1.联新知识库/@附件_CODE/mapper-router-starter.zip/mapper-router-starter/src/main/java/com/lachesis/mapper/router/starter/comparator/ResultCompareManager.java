package com.lachesis.mapper.router.starter.comparator;

import cn.hutool.extra.spring.SpringUtil;
import com.lachesis.mapper.router.starter.constant.CompareErrEnum;
import com.lachesis.mapper.router.starter.core.MapperRouterInvocation;
import com.lachesis.mapper.router.starter.core.MapperRouterMethodAnno;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import com.lachesis.mapper.router.starter.monitor.Stage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ResultCompareManager {

    public void compare(MapperRouterContext context, Object oldRes, Object newRes) {
        CompareResult compareResult;
        context.begin(Stage.COMPARE);
        try {
            // 单表不进行比对，仅对分片表进行比对
            if (!context.isSharding()) {
                context.setCompareResult(CompareResult.newFail(CompareErrEnum.SINGLE_TABLE));
                context.end(Stage.COMPARE);
                return;
            }

            MapperRouterInvocation invocation = context.getInvocation();
            if (invocation.isVoid()) {
                context.setCompareResult(CompareResult.newFail(CompareErrEnum.RETURN_VOID));
                context.end(Stage.COMPARE);
                return;
            }

            // 结果返回为null
            if (oldRes == null && newRes == null) {
                context.setCompareResult(CompareResult.newFail(CompareErrEnum.ALL_IS_NULL));
                context.end(Stage.COMPARE);
                return;
            }

            MapperRouterMethodAnno methodAnno = context.getMethodAnno();
            Class<? extends IResultComparator> comparatorClass = methodAnno.getComparatorClass();
            IResultComparator comparator = SpringUtil.getBean(comparatorClass);

            if (oldRes == null) {
                compareResult = CompareResult.newFail(CompareErrEnum.OLD_IS_NULL);
            } else if (newRes == null) {
                compareResult = CompareResult.newFail(CompareErrEnum.NEW_IS_NULL);
            } else {
                compareResult = comparator.compare(context, oldRes, newRes);
            }
            context.setCompareResult(compareResult);
            context.end(Stage.COMPARE);
        } catch (Exception e) {
            context.setCompareResult(CompareResult.newFail(CompareErrEnum.UNKNOWN_EXP));
            context.error(Stage.COMPARE, e);
            throw e;
        }
    }
}
