package com.lachesis.mapper.router.starter.core.handler;


import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;

public interface IMapperHandler {

    Object handle(MapperRouterContext context) throws Throwable;

}
