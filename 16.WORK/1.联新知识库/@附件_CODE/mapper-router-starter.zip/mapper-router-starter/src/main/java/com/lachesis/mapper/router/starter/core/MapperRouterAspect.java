package com.lachesis.mapper.router.starter.core;

import com.lachesis.mapper.router.starter.MapperRouterProperties;
import com.lachesis.mapper.router.starter.core.context.MapperRouterContext;
import com.lachesis.mapper.router.starter.core.handler.RoutingMapperHandler;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Slf4j
@Aspect
@Order(1)
@Component
@AllArgsConstructor
public class MapperRouterAspect {

    private final MapperRouterProperties properties;
    private final RoutingMapperHandler routingMapperHandler;

    @Pointcut("@within(com.lachesis.mapper.router.starter.core.annotation.RoutingMapper)")
    public void pointCut() {
    }

    @Around("pointCut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        MapperRouterInvocation invocation = MapperRouterInvocation.newInstance(joinPoint);
        MapperRouterContext context = MapperRouterContext.newInstance(invocation, properties);
        try {
            context.init();
            context.createLog();
            return routingMapperHandler.handle(context);
        } catch (Throwable throwable) {
            log.error("执行异常", throwable);
            throw throwable;
        } finally {
            context.saveLog();
        }
    }
}
