package com.lachesis.mapper.router.starter.core.handler.newhandler.executor;

public interface IBaseShardingExecutor extends IShardingExecutor {

    ExecuteCase getCase();

}
