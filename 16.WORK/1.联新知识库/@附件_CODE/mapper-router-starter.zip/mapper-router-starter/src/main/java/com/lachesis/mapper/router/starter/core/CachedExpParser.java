package com.lachesis.mapper.router.starter.core;

import cn.hutool.extra.spring.SpringUtil;
import org.springframework.context.expression.AnnotatedElementKey;

public class CachedExpParser {

    private final EnhancedCachedExpEvaluator evaluator;
    private final AnnotatedElementKey elementKey;

    private CachedExpParser(MapperRouterInvocation invocation) {
        this.evaluator = SpringUtil.getBean(EnhancedCachedExpEvaluator.class);
        this.elementKey = invocation.getElementKey();
    }

    public static CachedExpParser newInstance(MapperRouterInvocation invocation) {
        return new CachedExpParser(invocation);
    }

    public Object parse(ExpEvalContext evalContext, String exp) {
        return evaluator.doParseExp(exp, elementKey, evalContext);
    }

    public <T> T parse(ExpEvalContext evalContext, String exp, Class<T> clazz) {
        return evaluator.doParseExp(exp, elementKey, evalContext, clazz);
    }

    public ExpEvalContext createEvalContext(MapperRouterInvocation invocation) {
        return evaluator.createEvalContext(invocation);
    }
}
