package com.lachesis.mapper.router.starter.transform;

import cn.hutool.core.collection.CollUtil;
import lombok.Data;

import java.util.List;

@Data
public class BatchResult<T> {

    private List<T> data;
    private Long maxSeqId;

    public static <T> BatchResult<T> newInstance(List<T> data, Long maxSeqId) {
        BatchResult<T> batchResult = new BatchResult<>();
        batchResult.setData(data);
        batchResult.setMaxSeqId(maxSeqId);
        return batchResult;
    }

    public boolean isEmpty() {
        return CollUtil.isEmpty(data);
    }
}
